<?php
/** Danish
 *
 * @ingroup Language
 * @file
 * @comment Deprecated code. Falls back to 'dk'.
 */

$fallback = 'da';
