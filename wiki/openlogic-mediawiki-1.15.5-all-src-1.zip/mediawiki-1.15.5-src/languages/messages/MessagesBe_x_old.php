<?php
/** Belarusian in Taraškievica orthography (Беларуская тарашкевіца)
 *
 * @ingroup Language
 * @file
 * @comment dummy language file. Falls back to 'be-tarask'. Backward compat.
 */

$fallback = 'be-tarask';
