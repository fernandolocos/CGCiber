<?php
/** Megleno-Romanian (Greek script) (Βλαεστε)
 *
 * @ingroup Language
 * @file
 *
 */

$fallback = 'el';
