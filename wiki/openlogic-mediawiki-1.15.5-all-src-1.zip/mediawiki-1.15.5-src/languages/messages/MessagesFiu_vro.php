<?php
/** Võro
 *
 * @ingroup Language
 * @file
 * @comment Deprecated language code. Falls back to 'vro'.
 */

$fallback = 'vro';
