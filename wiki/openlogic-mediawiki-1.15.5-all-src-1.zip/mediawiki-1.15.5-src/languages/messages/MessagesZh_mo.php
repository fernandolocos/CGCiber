<?php
/** ‪Chinese (Macau) (‪中文(澳門)‬)
 *
 * @ingroup Language
 * @file
 *
 */

# Inherit everything for now
$fallback = 'zh-hk';
