<?php
/** Kurdish (Kurdî / كوردی)
 *
 * @ingroup Language
 * @file
 *
 */

$fallback = 'ku-latn';
