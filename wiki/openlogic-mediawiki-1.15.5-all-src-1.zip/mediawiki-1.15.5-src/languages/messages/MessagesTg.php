<?php
/** Tajik (Тоҷикӣ)
 *
 * @ingroup Language
 * @file
 * @comment falls back to Tajik (Cyrillic)
 *
 */

$fallback = 'tg-cyrl';
