<?php
/** Uighur (Uyghurche‎ / ئۇيغۇرچە)
 *
 * @ingroup Language
 * @file
 * @comment falls back to Uyghurche‎ (Latin)
 */

$fallback = 'ug-latn';
