ALTER TABLE "user" RENAME TO mwuser;
