
CREATE TABLE updatelog (
  ul_key TEXT NOT NULL PRIMARY KEY
);
