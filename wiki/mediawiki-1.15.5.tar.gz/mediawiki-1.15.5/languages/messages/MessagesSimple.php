<?php
/** English
 *
 * @ingroup Language
 * @file
 * @comment dummy language file. Falls back to 'en'. Needed for http://simple.wikipedia.org.
 */

$fallback = 'en';
