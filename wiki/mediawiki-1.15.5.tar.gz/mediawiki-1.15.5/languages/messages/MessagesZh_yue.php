<?php
/** Cantonese (粵語/廣東話)
 *
 * @ingroup Language
 * @file
 *
 */

# Inherit everything for now
$fallback = 'yue';
