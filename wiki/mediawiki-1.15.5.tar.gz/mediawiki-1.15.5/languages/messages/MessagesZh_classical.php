<?php

/** Classical Chinese (文言)
 *
 * @ingroup Language
 * @file
 *
 */

# Inherit everything for now
$fallback = 'lzh';
