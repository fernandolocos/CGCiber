<?php
/** Ladin (Ladin)
 *
 * @ingroup Language
 * @file
 *
 */

$fallback = 'it';
