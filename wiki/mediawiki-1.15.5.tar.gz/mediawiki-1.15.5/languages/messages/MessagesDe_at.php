<?php
/** Austrian German (Österreichisches Deutsch)
 *
 * See MessagesQqq.php for message documentation incl. usage of parameters
 * To improve a translation please visit http://translatewiki.net
 *
 * @ingroup Language
 * @file
 *
 * @author Revolus
 */

$fallback = 'de';

$messages = array(
# Dates
'january' => 'Jänner',

);
