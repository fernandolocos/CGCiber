<?php
/** Norwegian Bokmål (‪Norsk (bokmål)‬)
 *
 * @ingroup Language
 * @file
 * @comment Correct code, but for historical reasons this started as 'no'. Falls back to 'no'. May be reversed some day.
 */

$fallback = 'no';
