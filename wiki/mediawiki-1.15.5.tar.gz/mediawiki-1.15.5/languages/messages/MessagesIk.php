<?php
/** Inupiaq (Iñupiak)
 *
 * See MessagesQqq.php for message documentation incl. usage of parameters
 * To improve a translation please visit http://translatewiki.net
 *
 * @ingroup Language
 * @file
 *
 */

$messages = array(
# All link text and link target definitions of links into project namespace that get used by other message strings, with the exception of user group pages (see grouppage) and the disambiguation template definition (see disambiguations).
'helppage'             => 'Help:anniqsuiruq',
'mainpage'             => 'Makpibaaq Kanna',
'mainpage-description' => 'Makpibaaq Kanna',
'portal-url'           => 'Project:qargi',

# Search results
'searchhelp-url' => 'Help:anniqsuiruq',

);
