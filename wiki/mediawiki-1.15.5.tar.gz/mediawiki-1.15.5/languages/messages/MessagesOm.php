<?php
/** Oromo (Oromoo)
 *
 * See MessagesQqq.php for message documentation incl. usage of parameters
 * To improve a translation please visit http://translatewiki.net
 *
 * @ingroup Language
 * @file
 *
 * @author Malafaya
 * @author Node ue
 */

$messages = array(
# Dates
'sunday'    => 'Dilbata',
'monday'    => 'Wiixata',
'tuesday'   => 'Qibxata',
'wednesday' => 'Roobii',
'thursday'  => 'Kamiisa',
'friday'    => 'Jimaata',
'saturday'  => 'Sanbata',
'sun'       => 'Dil',
'mon'       => 'Wix',
'tue'       => 'Qib',
'wed'       => 'Rob',
'thu'       => 'Kam',
'fri'       => 'Jim',
'sat'       => 'San',
'january'   => 'Amajjii',
'february'  => 'Guraandhala',
'march'     => 'Bitooteessa',
'april'     => 'Elba',
'may_long'  => 'Caamsa',
'june'      => 'Waxabajjii',
'july'      => 'Adooleessa',
'august'    => 'Hagayya',
'september' => 'Fuulbana',
'october'   => 'Onkololeessa',
'november'  => 'Sadaasa',
'december'  => 'Muddee',

# All link text and link target definitions of links into project namespace that get used by other message strings, with the exception of user group pages (see grouppage) and the disambiguation template definition (see disambiguations).
'mainpage'             => 'Fuula Dura',
'mainpage-description' => 'Fuula Dura',

);
