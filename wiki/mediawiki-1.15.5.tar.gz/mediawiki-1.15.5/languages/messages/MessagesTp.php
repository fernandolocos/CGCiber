<?php
/** Toki Pona
 *
 * @ingroup Language
 * @file
 * @comment not an official code. Falls back to 'tokipona'. Also see http://www.sil.org/iso639-3/cr_files/2007-011_tok.pdf
 */

$fallback = 'tokipona';
