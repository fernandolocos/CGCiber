<?php
/** Inuktitut (ᐃᓄᒃᑎᑐᑦ/inuktitut)
 *
 * @ingroup Language
 * @file
 * @comment Macro language; kept for backward compatibility
 *
 */

$fallback = 'ike-cans';
