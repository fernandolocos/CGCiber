<?php
/** Venda (Tshivenda)
 *
 * See MessagesQqq.php for message documentation incl. usage of parameters
 * To improve a translation please visit http://translatewiki.net
 *
 * @ingroup Language
 * @file
 *
 * @author Node ue
 */

$messages = array(
'search'       => 'Ṱolani',
'searchbutton' => 'Ṱolani',
'talk'         => 'Ambani',

# All link text and link target definitions of links into project namespace that get used by other message strings, with the exception of user group pages (see grouppage) and the disambiguation template definition (see disambiguations).
'mainpage'             => 'Hayani',
'mainpage-description' => 'Hayani',

# Short words for each namespace, by default used in the namespace tab in monobook
'nstab-mediawiki' => 'Mulaedza',

# General errors
'error' => 'Vhukhakhi',

# Login and logout pages
'yourname'     => 'Dzina ḽa mushumisi:',
'yourpassword' => 'Phasiwede:',
'username'     => 'Dzina ḽa mushumisi:',

# Preferences page
'changepassword' => 'Shandukisani phasiwede',

# Miscellaneous special pages
'newpages-username' => 'Dzina ḽa mushumisi:',

'exif-meteringmode-255' => 'Zwiṅwe',

# Special:Version
'version-other' => 'Zwiṅwe',

);
