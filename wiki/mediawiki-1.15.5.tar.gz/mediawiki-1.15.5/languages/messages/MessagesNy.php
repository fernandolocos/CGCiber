<?php
/** Nyanja (Chi-Chewa)
 *
 * See MessagesQqq.php for message documentation incl. usage of parameters
 * To improve a translation please visit http://translatewiki.net
 *
 * @ingroup Language
 * @file
 *
 */

$messages = array(
'help'          => 'Chithandizo',
'search'        => 'Fufuzani',
'searchbutton'  => 'Fufuzani',
'searcharticle' => 'Pitani',
'toolbox'       => 'zida',

# All link text and link target definitions of links into project namespace that get used by other message strings, with the exception of user group pages (see grouppage) and the disambiguation template definition (see disambiguations).
'mainpage'             => 'Tsamba Lalikulu',
'mainpage-description' => 'Tsamba Lalikulu',
'portal'               => 'Tsamba la anthu wonse',

'youhavenewmessagesmulti' => 'Muli ndi mauthenga atsopano ku $1',

# Recent changes
'recentchanges' => 'Kusintha kumene kwachitika posachedwa',

# Special:SpecialPages
'specialpages' => 'Masamba apadera',

);
