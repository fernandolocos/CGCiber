<?php
/** Kazakh (Қазақша)
 *
 * See MessagesQqq.php for message documentation incl. usage of parameters
 * To improve a translation please visit http://translatewiki.net
 *
 * @ingroup Language
 * @file
 *
 */

# Stub message file for converter code "kk"

$fallback = 'kk-cyrl';

$messages = array(
# Edit pages
'edittools' => '<!-- Мындағы мәтін өңдеу және қотару пішіндердің астында көрсетіледі. -->',

# Variants for Kazakh language
'variantname-kk-kz'   => 'disable',
'variantname-kk-tr'   => 'disable',
'variantname-kk-cn'   => 'disable',
'variantname-kk-cyrl' => 'Кирил',
'variantname-kk-latn' => 'Latın',
'variantname-kk-arab' => 'توتە',
'variantname-kk'      => 'disable',

);
