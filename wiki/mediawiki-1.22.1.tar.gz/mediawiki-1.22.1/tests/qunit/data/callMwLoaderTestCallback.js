mediaWiki.loader.testCallback();
