<?php
/** Northern Frisian (Nordfriisk)
 *
 * See MessagesQqq.php for message documentation incl. usage of parameters
 * To improve a translation please visit http://translatewiki.net
 *
 * @ingroup Language
 * @file
 *
 * @author Geitost
 * @author Inkowik
 * @author Maartenvdbent
 * @author Merlissimo
 * @author Murma174
 * @author Pyt
 */

$fallback = 'de';

$linkTrail = '/^([a-zäöüßåāđē]+)(.*)$/sDu';

$messages = array(
# User preference toggles
'tog-underline' => 'Ferwisangen onerstrik:',
'tog-justify' => 'Tekst üs blook saat',
'tog-hideminor' => 'Letj anrangen fersteeg',
'tog-hidepatrolled' => 'Letj anrangen fersteeg',
'tog-newpageshidepatrolled' => 'Kontroliaret sidjen bi a "Nei sidjen" fersteeg',
'tog-extendwatchlist' => "Ütjwidjet list faan sidjen, diar dü uun't uug behual wel",
'tog-usenewrc' => "Ütjwidjet uunwisin faan a ''Leetst feranrangen'' an bi a sidjen, diar dü ''Uun't uug behual'' wel",
'tog-numberheadings' => 'Auerskraften automaatisk numeriare',
'tog-showtoolbar' => 'Werktjüch tu bewerkin wise',
'tog-editondblclick' => 'Sidjen mä dobelklik bewerke',
'tog-editsection' => "Ferwisangen tu't bewerkin faan enkelt kirwer",
'tog-editsectiononrightclick' => 'Enkelt kirwer mä rochtsklik bewerke',
'tog-showtoc' => 'Üüb sidjen mä muar üs trii auerskraften en indeks uunwise',
'tog-rememberpassword' => 'Üüb diheer reegner üüb düür uunmelde (maksimaal för $1 {{PLURAL:$1|dai|daar}})',
'tog-watchcreations' => "Salew maaget sidjen an huuchlooset datein leewen uun't uug behual",
'tog-watchdefault' => "Salew feranert sidjen an datein leewen uun't uug behual",
'tog-watchmoves' => "Salew fersköwen sidjen an datein leewen uun't uug behual",
'tog-watchdeletion' => "Salew stregen sidjen an datein leewen uun't uug behual",
'tog-minordefault' => 'Aanj feranrangen üs "letjen" kääntiakne',
'tog-previewontop' => '"Iarst ans luke" boowen faan\'t wönang tu bewerkin',
'tog-previewonfirst' => 'Bi\'t iarst bewerkin "iarst ans luke" uunwise',
'tog-nocache' => 'Sidjencache faan di browser deaktiwiare',
'tog-enotifwatchlistpages' => "Schüür mi en e-mail, wan sidjen of datein feranert wurd, diar ik uun't uug behual wal",
'tog-enotifusertalkpages' => 'Bi feranrangen üüb min brüker-diskusjuunssidj en e-mail schüür',
'tog-enotifminoredits' => 'Schüür mi uk bi letj feranrangen faan sidjen an datein en e-mail',
'tog-enotifrevealaddr' => 'Min e-mail adres uun e-mail noorachten uunwise',
'tog-shownumberswatching' => "Taal faan brükern uunwise, diar det sidj uun't uug haa",
'tog-oldsig' => 'Aktuel signatuur:',
'tog-fancysig' => 'Signatuur üs wikitekst uunsä (saner ferwisangen)',
'tog-uselivepreview' => 'Live-föörskau funktjuun brük (eksperimentel)',
'tog-forceeditsummary' => "Wäärne, wan bi't seekrin nian tuupfaadang uunden woort",
'tog-watchlisthideown' => "Aanj feranrangen bi a sidjen, diar ik uun't uug behual wal, fersteeg",
'tog-watchlisthidebots' => "Feranrangen faan bots bi a sidjen, diar ik uun't uug behual wal, fersteeg",
'tog-watchlisthideminor' => "Letj feranrangen bi a sidjen, diar ik uun't uug behual wal, fersteeg",
'tog-watchlisthideliu' => "Feranrangen faan uunmeldet brükern bi sidjen, diar ik uun't uug behual wal, fersteeg",
'tog-watchlisthideanons' => "Feranrangen faan anonüüm brükern (IPs) bi sidjen, diar ik uun't uug behual wal, fersteeg",
'tog-watchlisthidepatrolled' => "Kontroliaret feranrangen bi a sidjen, diar ik uun't uug behual wal, fersteeg",
'tog-ccmeonemails' => 'Schüür mi kopiin faan e-mails, diar ik tu ööder brükern schüür',
'tog-diffonly' => 'Bi en werjuunsferglik bluas di ferskeel uunwise, ei det hialer sidj',
'tog-showhiddencats' => 'Ferbürgen kategoriin uunwise',
'tog-norollbackdiff' => "Ferskeel efter't turagsaaten fersteeg",
'tog-useeditwarning' => 'Waarskaue mi, wan en sidj slööden woort, huar noch ünseekert feranrangen maaget wurden san',
'tog-prefershttps' => 'Leewen en seeker ferbinjag brük, wan ik uunmeldet san.',

'underline-always' => 'Leewen',
'underline-never' => 'Nimer',
'underline-default' => 'Komt üüb dan browser uun',

# Font style option in Special:Preferences
'editfont-style' => "Skraftoort för di tekst uun't werkfial:",
'editfont-default' => 'Hinget faan browser-iinstelangen uf',
'editfont-monospace' => 'Skraft mä en fääst tiakenbreetje',
'editfont-sansserif' => 'Skraft saner seriifen (fiin onerstreger)',
'editfont-serif' => 'Skraft mä seriifen (fiin onerstreger)',

# Dates
'sunday' => 'Saandi',
'monday' => 'Moundi',
'tuesday' => 'Täisdi',
'wednesday' => 'Weensdi',
'thursday' => 'Törsdi',
'friday' => 'Fraidi',
'saturday' => 'Saneene',
'sun' => 'Sd',
'mon' => 'Mo',
'tue' => 'Tä',
'wed' => 'We',
'thu' => 'Tö',
'fri' => 'Fr',
'sat' => 'Se',
'january' => 'Januar',
'february' => 'Feebruar',
'march' => 'Marts',
'april' => 'April',
'may_long' => 'Moi',
'june' => 'Juuni',
'july' => 'Juuli',
'august' => 'August',
'september' => 'Septämber',
'october' => 'Oktoober',
'november' => 'Nowämber',
'december' => 'Detsämber',
'january-gen' => 'Januar',
'february-gen' => 'Feebruar',
'march-gen' => 'Marts',
'april-gen' => 'April',
'may-gen' => 'Moi',
'june-gen' => 'Juuni',
'july-gen' => 'Juuli',
'august-gen' => 'August',
'september-gen' => 'Septämber',
'october-gen' => 'Oktoober',
'november-gen' => 'Nowämber',
'december-gen' => 'Detsämber',
'jan' => 'Jan.',
'feb' => 'Feb.',
'mar' => 'Mar.',
'apr' => 'Apr.',
'may' => 'Moi',
'jun' => 'Jun.',
'jul' => 'Jul.',
'aug' => 'Aug.',
'sep' => 'Sep.',
'oct' => 'Okt.',
'nov' => 'Now.',
'dec' => 'Det.',
'january-date' => '$1. Janewoore',
'february-date' => '$1. Febrewoore',
'march-date' => '$1. Maarts',
'april-date' => '$1. April',
'may-date' => '$1. Mei',
'june-date' => '$1. Jüüne',
'july-date' => '$1. Jüüle',
'august-date' => '$1. August',
'september-date' => '$1. September',
'october-date' => '$1. Oktuuber',
'november-date' => '$1. Nofember',
'december-date' => '$1. Detsember',

# Categories related messages
'pagecategories' => '{{PLURAL:$1|Kategorii|Kategoriin}}',
'category_header' => 'Sidjen uun kategorii "$1"',
'subcategories' => 'Onerkategoriin',
'category-media-header' => 'Meedien uun kategorii "$1"',
'category-empty' => '"Uun detdiar kategorii san uun uugenblak nian sidjen of meedien."',
'hidden-categories' => '{{PLURAL:$1|Ferbürgen kategorii|Ferbürgen kategoriin}}',
'hidden-category-category' => 'Ferbürgen kategoriin',
'category-subcat-count' => "{{PLURAL:$2|Detdiar kategorii hää ian onerkategorii.|Uun detdiar kategorii {{PLURAL:$1|stäänt ian onerkategorii|stun $1 onerkategoriin}} faan $2 uun't gehial.}}",
'category-subcat-count-limited' => 'Detdiar kategorii hää {{PLURAL:$1|ian onerkategorii|$1 onerkategoriin}}:',
'category-article-count' => "{{PLURAL:$2|Uun detdiar kategorii stäänt ian sidj.|Uun detdiar kategorii {{PLURAL:$1|stäänt ian sidj|stun jodiar $1 sidjen}} faan $2 uun't gehial.}}",
'category-article-count-limited' => '{{PLURAL:$1|Detdiar sidj stäänt|Jodiar $1 sidjen stun}} uun detdiar kategorii.',
'category-file-count' => "{{PLURAL:$2|Uun detdiar kategorii stäänt ian datei.|Uun detdiar kategorii {{PLURAL:$1|stäänt ian datei|stun jodiar $1 datein}} faan $2 uun't gehial.}}",
'category-file-count-limited' => '{{PLURAL:$1|Detdiar datei stäänt|Jodiar $1 datein stun}} uun detdiar kategorii.',
'listingcontinuesabbrev' => '(gongt widjer)',
'index-category' => 'Indisiaret sidjen',
'noindex-category' => 'Ei indisiaret sidjen',
'broken-file-category' => 'Sid ma önjstöögne ferwisinge',

'about' => 'Auer',
'article' => 'Artiikel',
'newwindow' => '(woort uun en nei wönang eeben maaget)',
'cancel' => 'Ufbreeg',
'moredotdotdot' => 'Muar ...',
'morenotlisted' => 'Detdiar list as ei komplet.',
'mypage' => 'Sidj',
'mytalk' => 'Diskusjuun',
'anontalk' => 'Diskusjuunssidj faan detdiar IP',
'navigation' => 'Nawigatjuun',
'and' => '&#32;an',

# Cologne Blue skin
'qbfind' => 'Finj',
'qbbrowse' => 'Schük',
'qbedit' => 'Bewerke',
'qbpageoptions' => 'Detdiar sidj',
'qbmyoptions' => 'Min sidjen',
'qbspecialpages' => 'Spezial-sidjen',
'faq' => 'FAQ',
'faqpage' => 'Project:FAQ',

# Vector skin
'vector-action-addsection' => 'Nei kirew began',
'vector-action-delete' => 'Strik',
'vector-action-move' => 'Fersküüw',
'vector-action-protect' => 'Seekre',
'vector-action-undelete' => 'Weder iinstel',
'vector-action-unprotect' => 'Sidjenseekerhaid',
'vector-simplesearch-preference' => 'Ianfacher schüklist iinstel (bluas bi Vector)',
'vector-view-create' => 'Maage',
'vector-view-edit' => 'Bewerke',
'vector-view-history' => 'Ferluup uunluke',
'vector-view-view' => 'Lees',
'vector-view-viewsource' => 'Kweltekst uunluke',
'actions' => 'Aktjuunen',
'namespaces' => 'Nöömrümer',
'variants' => 'Warianten',

'navigation-heading' => 'Nawigatsjuun',
'errorpagetitle' => 'Diar as wat skiaf gingen',
'returnto' => 'Turag tu sidj $1.',
'tagline' => 'Faan {{SITENAME}}',
'help' => 'Halep',
'search' => 'Schük',
'searchbutton' => 'Schük',
'go' => 'Widjer',
'searcharticle' => 'Sidj',
'history' => 'Werjuunen',
'history_short' => 'Ferluup',
'updatedmarker' => 'feranert sant man leetst beschük',
'printableversion' => 'Ütjdrük maage',
'permalink' => 'Permanent link',
'print' => 'Drük',
'view' => 'Lees',
'edit' => 'Bewerke',
'create' => 'Maage',
'editthispage' => 'Sidj bewerke',
'create-this-page' => 'Nei sidj maage',
'delete' => 'Strik',
'deletethispage' => 'Detdiar sidj strik',
'undeletethispage' => 'Detdiar stregen sidj turaghaale',
'undelete_short' => '{{PLURAL:$1|1 werjuun|$1 werjuunen}} weder iinstel',
'viewdeleted_short' => '{{PLURAL:$1|Ian stregen werjuun|$1 stregen werjuunen}} uunluke',
'protect' => 'Seekre',
'protect_change' => 'feranre',
'protectthispage' => 'Sidj seekre',
'unprotect' => 'Sidjenseekerhaid',
'unprotectthispage' => 'Sääkering aphääwe',
'newpage' => 'Nei sidj',
'talkpage' => 'Detdiar sidj diskutiare',
'talkpagelinktext' => 'Diskusjuun',
'specialpage' => 'Spezial-sidj',
'personaltools' => 'Min werktjüügen',
'postcomment' => 'Nei kirew',
'articlepage' => 'Artiikel wise',
'talk' => 'Diskusjuun',
'views' => 'Uunsichten',
'toolbox' => 'Werktjüügen',
'userpage' => 'Brükersidj uunwise',
'projectpage' => 'Projektsidj wise',
'imagepage' => 'Dateisidj uunwise',
'mediawikipage' => 'Mädialangssidj uunwise',
'templatepage' => 'Föörlaagensidj uunwise',
'viewhelppage' => 'Halepsidj uunwise',
'categorypage' => 'Kategoriisidj uunwise',
'viewtalkpage' => 'Diskusjuun uunluke',
'otherlanguages' => 'Uun ööder spriaken',
'redirectedfrom' => '(Widjerfeerd faan $1)',
'redirectpagesub' => 'Widjerfeerang',
'lastmodifiedat' => 'Detdiar sidj as tuleetst di $1, am a klook $2 anert wurden.',
'viewcount' => 'Aw jüdeer sid as  {{PLURAL:$1|iinjsen|$1 tunge}} tugram wörden.',
'protectedpage' => 'Sääkerd sid',
'jumpto' => 'Waksle tu:',
'jumptonavigation' => 'Nawigatjuun',
'jumptosearch' => 'Schük',
'view-pool-error' => 'Det dää üs iarag, a servers san auerläästet.
Tuföl brükern ferschük, det sidj tu beschüken.
Wees so gud an teew en uugenblak, iar dü det noch ans ferschükst.

$1',
'pool-timeout' => "Tidj uflepen bi't teewen üüb't sperang",
'pool-queuefull' => 'Pool as auerläästet',
'pool-errorunknown' => 'Ünbekäänd feeler',

# All link text and link target definitions of links into project namespace that get used by other message strings, with the exception of user group pages (see grouppage).
'aboutsite' => 'Auer {{SITENAME}}',
'aboutpage' => 'Project:Auer',
'copyright' => 'Det stäänt oner det lisens $1.',
'copyrightpage' => '{{ns:project}}:Copyrights',
'currentevents' => 'Aktuels',
'currentevents-url' => 'Project:Aktuels',
'disclaimers' => 'Disclaimers',
'disclaimerpage' => 'Project:Disclaimers',
'edithelp' => "Halep bi't bewerkin",
'helppage' => 'Help:Auersicht',
'mainpage' => 'Hoodsidj',
'mainpage-description' => 'Hoodsidj',
'policy-url' => 'Project:Reegeln',
'portal' => 'Gemianskap',
'portal-url' => 'Project:Gemianskap',
'privacy' => 'Persöönelk dooten',
'privacypage' => 'Project:Persöönelk dooten',

'badaccess' => 'Brükerrochten ling ei',
'badaccess-group0' => 'För detdiar aktjuun heest dü ei nooch brükerrochten.',
'badaccess-groups' => 'Detdiar aktjuun mut bluas faan brükern uun {{PLURAL:$2|det skööl|ian faan jodiar sköölen}} „$1“ ütjfeerd wurd.',

'versionrequired' => 'Werjuun $1 faan MediaWiki woort brükt.',
'versionrequiredtext' => "Werjuun $1 faan MediaWiki woort brükt, am detdiar sidj tu brüken.
Luke efter bi't [[Special:Version|werjuunssidj]]",

'ok' => 'OK',
'pagetitle' => '$1 – {{SITENAME}}',
'pagetitle-view-mainpage' => '{{SITENAME}}',
'backlinksubtitle' => '← $1',
'retrievedfrom' => 'Faan „$1“',
'youhavenewmessages' => 'Dü heest $1 ($2).',
'newmessageslink' => 'nei bööd',
'newmessagesdifflink' => 'Leest änring',
'youhavenewmessagesfromusers' => 'Dü heest $1 faan {{PLURAL:$3|en öödern brüker|$3 ööder brükern}} ($2).',
'youhavenewmessagesmanyusers' => 'Dü heest $1 faan flook ööder brükern ($2).',
'newmessageslinkplural' => '{{PLURAL:$1|ian nei nooracht|nei noorachten}}',
'newmessagesdifflinkplural' => 'leetst {{PLURAL:$1|feranrang|feranrangen}}',
'youhavenewmessagesmulti' => 'Dü heest nei bööd üüb $1',
'editsection' => 'Bewerke',
'editold' => 'Bewerke',
'viewsourceold' => 'kweltekst uunwise',
'editlink' => 'bewerke',
'viewsourcelink' => 'kweltekst uunwise',
'editsectionhint' => 'Kirew bewerke: $1',
'toc' => 'Auersicht',
'showtoc' => 'Wise',
'hidetoc' => 'Fersteeg',
'collapsible-collapse' => 'Tuupdoble',
'collapsible-expand' => 'Wise',
'thisisdeleted' => '$1 uunluke of weder iinstel',
'viewdeleted' => '$1 uunluke?',
'restorelink' => '$1 {{PLURAL:$1|stregen werjuun|stregen werjuunen}}',
'feedlinks' => 'Feed:',
'feed-invalid' => 'Feed-abonement-typ as ferkiard.',
'feed-unavailable' => 'Diar san nian feeds.',
'site-rss-feed' => 'RSS-feed för $1',
'site-atom-feed' => 'Atom-feed för $1',
'page-rss-feed' => 'RSS-feed för „$1“',
'page-atom-feed' => 'Atom-feed för „$1“',
'feed-atom' => 'Atom',
'feed-rss' => 'RSS',
'red-link-title' => '$1 (sidj ei diar)',
'sort-descending' => 'Sortiare faan boowen tu onern',
'sort-ascending' => 'Sortiare faan onern tu boowen',

# Short words for each namespace, by default used in the namespace tab in monobook
'nstab-main' => 'Sidj',
'nstab-user' => 'Brükersidj',
'nstab-media' => 'Meediensidj',
'nstab-special' => 'Spezial-sidj',
'nstab-project' => 'Projektsidj',
'nstab-image' => 'Datei',
'nstab-mediawiki' => 'Bööd',
'nstab-template' => 'Föörlaag',
'nstab-help' => 'Halepsidj',
'nstab-category' => 'Kategorii',

# Main script and global functions
'nosuchaction' => 'Son aktjuun jaft at ei',
'nosuchactiontext' => 'Son aktjuun jaft at üüb MediaWiki ei.
Ferlicht heest dü det URL ferkiard apskrewen, of dü beest en ferkiard ferwisang fulagt.
Ferlicht as det uk en feeler uun det software faan {{SITENAME}}.',
'nosuchspecialpage' => 'Son spezial-sidj jaft at ei.',
'nospecialpagetext' => '<strong>Son spezial-sidj jaft at ei.</strong>

En list mä aal a spezial-sidjen fanjst dü üüb [[Special:SpecialPages|{{int:specialpages}}]].',

# General errors
'error' => 'Feeler',
'databaseerror' => 'Dootenbeenkfeeler',
'databaseerror-text' => "Bi't uunfraag tu a dootenbeenk as wat skiaf gingen.
Diar küd wat mä a software ferkiard wees.",
'databaseerror-textcl' => "Diar as en feeler bi't uunfraag tu a dootenbeenk föörkimen.",
'databaseerror-query' => 'Uunfraag: $1',
'databaseerror-function' => 'Funktjuun: $1',
'databaseerror-error' => 'Feeler: $1',
'laggedslavemode' => "'''Paase üüb:''' Ferlicht wiset detdiar sidj ei a leetst stant.",
'readonly' => 'Dootenbeenk speret.',
'enterlockreason' => 'Wees so gud an du en grünj uun, huaram det dootenbeenk speret wurd skal, an hü loong det (amanbi) speret wurd skal.',
'readonlytext' => "Det dootenbeenk as iarst ans speret för nei iindracher an feranrangen, woorskiinelk, auer diar jüst apredet woort. Ferschük det leeder man noch ans.

Grünj för't sperin: $1",
'missing-article' => "Di tekst för „$1“ $2 as ei fünjen wurden uun't dootenbeenk.

Ferlicht as det sidj stregen of fersköwen wurden.

Wan't det ei as, do heest dü ferlicht en feeler uun't software fünjen. Wees so gud an skriiw det tu en [[Special:ListUsers/sysop|administraator]] an fertel ham, am hün URL det gongt.",
'missingarticle-rev' => '(Werjuunsnumer: $1)',
'missingarticle-diff' => '(Ferskeel tesken $1 an $2)',
'readonly_lag' => 'Det dootenbeenk as speret wurden, amdat jo ferdiald dootenbeenken (slaves) jo mä di hoodserver (master) ufglik kön.',
'internalerror' => 'Süsteemfeeler',
'internalerror_info' => 'Süsteemfeeler: $1',
'fileappenderrorread' => '"$1" küd ei leesen wurd, auer diar jüst üüb skrewen woort.',
'fileappenderror' => '"$1" küd ei bi "$2" bihinget wurd.',
'filecopyerror' => 'Det datei $1 küd ei efter $2 kopiaret wurd.',
'filerenameerror' => 'Det datei $1 küd ei efter $2 amnäämd wurd.',
'filedeleteerror' => 'Det datei $1 küd ei stregen wurd.',
'directorycreateerror' => 'Det fertiaknis "$1" küd ei iinracht wurd.',
'filenotfound' => 'Det datei $1 küd ei fünjen wurd.',
'fileexistserror' => 'Uun det datei "$1" küd ei skrewen wurd: Hat as al diar.',
'unexpected' => 'Mä di wäärs stemet wat ei: "$1"="$2".',
'formerror' => 'Feeler: Di iindrach küd ei ferwerket wurd.',
'badarticleerror' => 'Son aktjuun koon üüb detdiar sidj ei föörnimen wurd.',
'cannotdelete' => 'Det sidj of datei "$1" küd ei stregen wurd.
Det as ferlicht al faan hoker ööders stregen wurden.',
'cannotdelete-title' => 'Sidj „$1“ koon ei stregen wurd.',
'delete-hook-aborted' => 'Det striken as faan en software-feranrang faan MediaWiki ferhanert wurden. Di grünj as ei bekäänd.',
'no-null-revision' => 'Det nul-werjuun för det sidj "$1" küd ei skrewen wurd.',
'badtitle' => 'Ferkiard tiitel',
'badtitletext' => 'Didiar sidjennööm gongt ei. Hi as ferlicht leesag of as en ferkiard ferwisang faan en ööder projekt.',
'perfcached' => 'Jodiar dooten kem faan a cache an san ferlicht ei muar aktuel. Ei muar üs {{PLURAL:$1|ian resultoot as|$1 resultooten san}} uun a cache.',
'perfcachedts' => 'Jodiar dooten kem faan a cache, leetst tooch nei: $1. Ei muar üs {{PLURAL:$4|ian resultoot as|$4 resultooten san}} uun a cache.',
'querypage-no-updates' => 'Dü könst detdiar sidj uun uugenblak ei aktualisiare. A dooten wurd iarst ans ei iinsteld.',
'wrong_wfQuery_params' => 'Ferkiard dooten för wfQuery()<br />
Funktjuun: $1<br />
Uffraag: $2',
'viewsource' => 'Kweltekst uunluke',
'viewsource-title' => 'Code faan sidj $1 uunluke',
'actionthrottled' => 'Taal faan aktjuunen limitiaret',
'actionthrottledtext' => 'Dü heest detdiar aktjuun tufölsis uun en kurten tidjrüm ütjfeerd.
Wees so gud an ferschük det glik noch ans weder.',
'protectedpagetext' => 'Detdiar sidj as seekert wurden, am dat diar näämen wat feranert.',
'viewsourcetext' => 'Dü könst di kweltekst faan det sidj uunluke an ham uk kopiare:',
'viewyourtext' => "Dü könst di code faan '''din feranrang''' faan detdiar sidj uunluke an kopiare:",
'protectedinterface' => 'Üüb detdiar sidj stäänt tekst för det software faan detheer wiki an as seekert wurden, am dat näämen diar wat feranert.
Dü könst [//translatewiki.net/ translatewiki.net] faan MediaWiki brük, am auersaatangen för ale wiki projekten tu maagin.',
'editinginterface' => "'''Paase üüb:''' Üüb detdiar sidj stäänt tekst, diar faan't MediaWiki software brükt woort. Wan dü diar wat feranerst, feranerst dü di skak faan't Nordfriisk Wikipedia.
Wan dü wat auersaat wel, maage det mä [//translatewiki.net/ translatewiki.net], det as det MediaWiki lokalisiarangsprojekt.",
'cascadeprotected' => 'Detdiar sidj koon ei bewerket wurd. Hat as uun {{PLURAL:$1|detdiar sidj|jodiar sidjen}}
iinbünjen, diar auer kaskaadenseekerhaid seekert {{PLURAL:$1|as|san}}:
$2',
'namespaceprotected' => "Dü heest ei det brükerrocht, am sidjen uun di nöömrüm '''$1''' tu bewerkin.",
'customcssprotected' => 'Dü mutst detheer CSS sidj ei bewerke, auer det hoker ööders hiart.',
'customjsprotected' => 'Dü mutst detheer JavaScript sidj ei bewerke, auer det hoker ööders hiart.',
'mycustomcssprotected' => 'Dü mutst detdiar CSS-sidj ei bewerke.',
'mycustomjsprotected' => 'Dü mutst detdiar JavaScript-sidj ei bewerke.',
'myprivateinfoprotected' => 'Dü heest ei det brükerrocht, am din priwoot dooten tu feranrin.',
'mypreferencesprotected' => 'Dü heest ei det brükerrocht, am din iinstelangen tu feranrin.',
'ns-specialprotected' => 'Spezial-sidjen kön ei bewerket wurd.',
'titleprotected' => 'En sidj mä didiar nööm koon ei uunlaanj wurd.
Di brüker [[User:$1|$1]] hää det sidj speret, an di grünj as: "\'\'$2\'\'".',
'filereadonlyerror' => 'Det datei „$1“ koon ei feranert wurd, auer uun det fertiaknis „$2“ bluas leesen wurd koon.
Di grünj faan di administraator as: „$3“.',
'invalidtitle-knownnamespace' => 'Ferkiard auerskraft uun di nöömrüm „$2“ an tekst „$3“',
'invalidtitle-unknownnamespace' => 'Ferkiard auerskraft uun di ünbekäänd nöömrüm „$1“ an tekst „$2“',
'exception-nologin' => 'Ei uunmeldet',
'exception-nologin-text' => 'Det könst dü bluas bewerke, wan dü uunmeldet beest.',

# Virus scanner
'virus-badscanner' => "Ferkiard iinstelang: Ünbekäänd wiirenscanner: ''$1''",
'virus-scanfailed' => 'scan ging skiaf (code $1)',
'virus-unknownscanner' => 'Ünbekäänd wiirenscanner:',

# Login and logout pages
'logouttext' => "'''Dü beest nü ufmeldet.'''

Enkelt sidjen wise ferlicht noch uun, dat dü uunmeldet beest, so loong dü dan browser-cache ei leesag maaget heest.",
'welcomeuser' => 'Welkimen, $1!',
'welcomecreation-msg' => 'Din brükerkonto as iinracht wurden.
Ferjid det ei, an aachte üüb din [[Special:Preferences|{{SITENAME}} iinstelangen]].',
'yourname' => 'Brükernööm:',
'userlogin-yourname' => 'Brükernööm',
'userlogin-yourname-ph' => 'Du dan Brükernööm iin',
'createacct-another-username-ph' => 'Brükernööm iindu',
'yourpassword' => 'Paaswurd:',
'userlogin-yourpassword' => 'Paaswurd',
'userlogin-yourpassword-ph' => 'Paaswurd iindu',
'createacct-yourpassword-ph' => 'Paaswurd iindu',
'yourpasswordagain' => 'Skriiw det paaswurd noch ans weder hen:',
'createacct-yourpasswordagain' => 'Paaswurd gudkään',
'createacct-yourpasswordagain-ph' => 'Du det paaswurd noch ans iin',
'remembermypassword' => 'Üüb diheer reegner üüb düür uunmelde (maksimaal för $1 {{PLURAL:$1|dai|daar}})',
'userlogin-remembermypassword' => 'Uunmeldet bliiw',
'userlogin-signwithsecure' => 'Seeker ferbinjang brük',
'yourdomainname' => 'Din domain:',
'password-change-forbidden' => 'Üüb detheer wiki könst dü nian paaswurden feranre.',
'externaldberror' => 'Deer läit en fäägel bai jü äkstärn autentifisiiring for, unti dü möist din äkstärn brükerkonto äi aktualisiire.',
'login' => 'Uunmelde',
'nav-login-createaccount' => 'Melde di uun of skriiw di iin',
'loginprompt' => "För't uunmeldin tu {{SITENAME}} skel bi dan browser cookies aktiwiaret wees.",
'userlogin' => 'Melde di uun of skriiw di iin',
'userloginnocreate' => 'Uunmelde',
'logout' => 'Ufmelde',
'userlogout' => 'Ufmelde',
'notloggedin' => 'Ei uunmeldet',
'userlogin-noaccount' => 'Dü heest noch nian brükerkonto ?',
'userlogin-joinproject' => 'Bi {{SITENAME}} mämaage',
'nologin' => 'Dü heest nian brükerkonto? $1.',
'nologinlink' => 'Nei brükerkonto iinracht',
'createaccount' => 'Brükerkonto iinracht',
'gotaccount' => "Dü hääst ål en brükerkonto? '''$1'''.",
'gotaccountlink' => 'Uunmelde',
'userlogin-resetlink' => 'Heest dü din login dooten ferjiden?',
'userlogin-resetpassword-link' => 'Paaswurd turagsaat',
'helplogin-url' => 'Help:Uunmelde',
'userlogin-helplink' => "[[{{MediaWiki:helplogin-url}}|Halep bi't uunmeldin]]",
'createacct-join' => 'Du oner din dooten iin.',
'createacct-another-join' => "Skriiw oner a dooten för't nei brükerkonto hen",
'createacct-emailrequired' => 'E-mail adres',
'createacct-emailoptional' => 'E-mail adres (optional)',
'createacct-email-ph' => 'Du din e-mail adres iin',
'createacct-another-email-ph' => 'E-Mail-adres uundu',
'createaccountmail' => 'E-mail tu detdiar adres ferschüür mä en tidjwiis tufelag paaswurd',
'createacct-realname' => 'Rocht nööm (optional)',
'createaccountreason' => 'Grünj:',
'createacct-reason' => 'Grünj',
'createacct-reason-ph' => 'Huaram dü en ööder brükerkonto iinrachtst',
'createacct-captcha' => 'Seekerhaidspreew',
'createacct-imgcaptcha-ph' => 'Skriiw di tekst, diar dü boowen schochst',
'createacct-submit' => 'Din brükerkonto iinracht',
'createacct-another-submit' => 'En ööder brükerkonto iinracht',
'createacct-benefit-heading' => '{{SITENAME}} woort faan lidj üs di maaget.',
'createacct-benefit-body1' => '{{PLURAL:$1|feranrang|feranrangen}}',
'createacct-benefit-body2' => '{{PLURAL:$1|sidj|sidjen}}',
'createacct-benefit-body3' => 'aktiif {{PLURAL:$1|skriiwer|skriiwern}}',
'badretype' => 'Jo tau paaswurden san ei likedenang.',
'userexists' => 'Dideer brükernoome as ål ferjääwen.
Wees sü gödj en kiis en ouderen.',
'loginerror' => "Bi't uunmeldin as wat skiaf gingen",
'createacct-error' => "Bi't iinrachten faan det brükerkonto as wat skiaf gingen",
'createaccounterror' => 'Brükerkonto küd ei iinracht wurd: $1',
'nocookiesnew' => 'Det brükerkonto as iinracht wurden, oober dü beest ei uunmeldet.
{{SITENAME}} brükt cookies för detdiar aktjuun.
Wees so gud an aktiwiare jo uun dan browser, an do melde di mä dan nei brükernööm an det nei paaswurd uun.',
'nocookieslogin' => "{{SITENAME}} brükt cookies för't uunmeldin faan brükern.
Dü heest cookies deaktiwiaret.
Wees so gud an aktiwiare jo uun dan browser, an do ferschük det noch ans.",
'nocookiesfornew' => 'Det brükerkonto as ei iinracht wurden, auer wi ei witj, huar a dooten faan kem.
Üüb dan kompjuuter skel cookies aktiwiaret wees. Do rep detheer sidj noch ans nei ap.',
'noname' => 'Dü skel en rochten brükernööm uundu.',
'loginsuccesstitle' => 'Uunmeldin hää loket.',
'loginsuccess' => "'''Dü beest nü üs „$1“ bi {{SITENAME}} uunmeldet.'''",
'nosuchuser' => 'Di brükernööm „$1“ jaft at ei. Aachte üüb det skriiwwiis (an uk üüb grat- an letjskriiwang), an do [[Special:UserLogin/signup|melde di nei uun]].',
'nosuchusershort' => 'Diar as nään brüker mä di nööm "$1".
Heest dü ham uk rocht skrewen?',
'nouserspecified' => 'Dü skel en brükernööm uundu.',
'login-userblocked' => 'Didiar brüker as speret wurden. Hi mut ham ei uunmelde.',
'wrongpassword' => 'Det paaswurd as ferkiard.
Wees so gud an ferschük det noch ans.',
'wrongpasswordempty' => 'Dü heest nian paaswurd iinden.
Ferschük det man noch ans.',
'passwordtooshort' => 'Paaswurden skel tumanst {{PLURAL:$1|1 tiaken|$1 tiakens}} lung wees.',
'password-name-match' => 'Dü könst dan brükernööm ei üs paaswurd nem.',
'password-login-forbidden' => 'Jüdeer brükernoome än paasuurd as ferbin.',
'mailmypassword' => 'Schüür mi en nei paaswurd.',
'passwordremindertitle' => 'Nei tidjwiis paaswurd för {{SITENAME}}',
'passwordremindertext' => 'En brüker (woorskiinelk dü, faan IP adres $1) hää am en nei paaswurd för {{SITENAME}} ($4) fraaget.
En nei paaswurd för di brüker "$2" as maaget wurden an het nü "$3".

Wan dü det würelk so haa wel, do melde di nü uun an feranere det paaswurd. Det nei paaswurd täält för {{PLURAL:$5|ään dai|$5 daar}}.

Wan dü ei salew am en nei paaswurd fraaget heest, do säärst dü di am niks widjer komre. Do könst dü din ual paaswurd widjer brük.',
'noemail' => 'Diar as nian e-mail adres bekäänd för di brüker "$1".',
'noemailcreate' => 'Dü skel en rocht e-mail adres uundu.',
'passwordsent' => 'En nei tidjwiis paaswurd as tu det e-mail-adres faan di brüker "$1" schüürd wurden.
Melde di diarmä uun, wan dü det füngen heest. Det ual paaswurd blaft iarst ans bestunen.',
'blocked-mailpassword' => 'Det IP-adres, wat dü brükst, as speret wurden. Am dat diar nian dom tjüch mä maaget woort, as uk det uffraagin faan paaswurden speret wurden.',
'eauthentsent' => 'Diar as en e-mail tu det uunjiwen adres schüürd wurden.

Iar en e-mail faan ööder brükern auer det e-mail-funktjuun uunnimen wurd koon, skal seeker steld wurd, dat det e-mail-adres uk würelk tu di brüker hiart. Wees so gud an befulge jo uunwisangen uun det e-mail, wat dü jüst füngen heest.',
'throttled-mailpassword' => 'Diar as uun a leetst {{PLURAL:$1|stünj|$1 stünj}} al ans am en nei paaswurd uunfraaget wurden. Am dat diar nään masbrük mä drewen woort, koon bluas {{PLURAL:$1|iansis per stünj|iansis per $1 stünj}} am en nei paaswurd uunfraaget wurd.',
'mailerror' => 'Fäägel bai dåt siinjen foon e e-mail: $1',
'acct_creation_throttle_hit' => 'Beschükern faan detheer wiki mä din IP-adres haa di leetst dai {{PLURAL:$1|1 brükerkonto|$1 brükerkontos}} iinracht. Muar san ei tuläät.

Beschükern mä detdiar IP-adres kön daalang nian brükerkontos muar iinracht.',
'emailauthenticated' => 'Din e-mail-adres as di $2 am a klook $3 gudkäänd wurden.',
'emailnotauthenticated' => 'Din e-mail-adres as noch ei gudkäänd. Jodiar e-mail-funktjuunen kön iarst brükt wurd, wan det adres gudkäänd wurden as.',
'noemailprefs' => 'Du en e-mail-adres uun din iinstelangen iin, amdat dü jodiar funktjuunen brük könst.',
'emailconfirmlink' => 'E-mail-adres gudkään',
'invalidemailaddress' => 'Jü E-mail adräs wörd ai aksäptiird, ouerdåt jü en üngülti formoot (ewentuäl üngültie tiikne) tu heewen scheent.
Wees sü gödj än jeef en koräkt adräs önj unti mäág dåt fäalj lääsi.',
'cannotchangeemail' => 'E-mail-adresen kön uun detheer wiki ei feranert wurd.',
'emaildisabled' => 'Fann detdiar sidj kön nian E-Mails fersjüürd wurd',
'accountcreated' => 'Brükerkonto as iinracht wurden',
'accountcreatedtext' => 'Det brükerkonto för [[{{ns:User}}:$1|$1]] ([[{{ns:User talk}}:$1|talk]]) as iinracht wurden.',
'createaccount-title' => 'En brükerkonto üüb {{SITENAME}} iinracht',
'createaccount-text' => 'Diar as mä din e-mail adres för di en brükerkonto "$2" üüb {{SITENAME}} ($4) maaget wurden. För "$2" as automaatisk det paaswurd "$3" iinracht wurden.
Dü skulst di nü uunmelde an det paaswurd anre.

Wan det brükerkonto ütj fersen uunlaanj wurden as, säärst dü niks widjer onernem.',
'usernamehasherror' => 'Uun brükernöömer mut nian rütjen föörkem.',
'login-throttled' => 'Dü heest tufölsis fersoocht, di uuntumeldin.
Wees so gud an teew $1, iar dü det noch ans ferschükst.',
'login-abort-generic' => 'Det uunmeldin hää ei loket - Ufbreegen',
'loginlanguagelabel' => 'Spriak: $1',
'suspicious-userlogout' => 'Din ufmeldang as ei föörnimen wurden, auer det uunfraag ferlicht faan en uunstakenen browser of faan en cache-proxy kaam.',
'createacct-another-realname-tip' => 'Stäänt tu wool. Wan dü dan rochten nööm uundääst, koon hi mä din feranrangen ferbünjen wurd.',

# Email sending
'php-mail-error-unknown' => 'Ünbekäänd feeler mä det funktsjuun mail() faan PHP.',
'user-mail-no-addy' => 'Küd nian e-mail schüür saner e-mail-adres.',
'user-mail-no-body' => 'Dü wulst en e-mail saner tekst wechsjüür.',

# Change password dialog
'resetpass' => 'Paaswurd feranre',
'resetpass_announce' => 'Dü heest di mä di code uunmeldet, di dü per e-mail tuschüürd füngen heest.
Am det uunmeldin uftuslütjen, skel dü en nei paaswurd iindu.',
'resetpass_header' => 'Paaswurd feranre',
'oldpassword' => 'Ual paaswurd:',
'newpassword' => 'Nei paaswurd:',
'retypenew' => 'Skriiw det paaswurd noch ans weder hen:',
'resetpass_submit' => 'Paaswurd saat an uunmelde',
'changepassword-success' => 'Din paaswurd as feranert wurden!',
'resetpass_forbidden' => 'Det paaswurd koon ei feranert wurd.',
'resetpass-no-info' => 'Dü skel di uunmelde, am üüb det sidj tutugripen.',
'resetpass-submit-loggedin' => 'Paaswurd feranre',
'resetpass-submit-cancel' => 'Ufbreeg',
'resetpass-wrong-oldpass' => 'Detdiar paaswurd docht niks.
Ferlicht heest dü jüst din paaswurd feranert
of am en nei paaswurd uunfraaget.',
'resetpass-temp-password' => 'Tidjwiis paaswurd:',
'resetpass-abort-generic' => 'Det paaswurd-anerang as ferhanert wurden.',

# Special:PasswordReset
'passwordreset' => 'Paaswurd turagsaat',
'passwordreset-text-one' => 'Fal detheer formulaar ütj, am din paaswurd turag tu saaten.',
'passwordreset-text-many' => '{{PLURAL:$1|Fal ian fial ütj, am din paaswurd turag tu saaten.}}',
'passwordreset-legend' => 'Paaswurd turagsaat',
'passwordreset-disabled' => 'Dü könst din paaswurd uun detdiar wiki ei turagsaat.',
'passwordreset-emaildisabled' => 'E-mail as üüb detheer Wiki ufknipset wurden.',
'passwordreset-username' => 'Brükernoome:',
'passwordreset-domain' => 'Domain:',
'passwordreset-capture' => 'Wel dü det e-mail nooracht uunluke?',
'passwordreset-capture-help' => 'Wan dü detheer kasje uunkrüsagst, woort det e-mail nooracht mä det nei paaswurd uunwiset an tu di brüker sjüürd.',
'passwordreset-email' => 'E-mail adres:',
'passwordreset-emailtitle' => 'Brükerkonto aw {{SITENAME}}',
'passwordreset-emailtext-ip' => 'Hoker mä det IP-Adres $1, woorskiinelk dü salew, wul hal brükerinformatsjuunen för {{SITENAME}} tusjüürd fu ($4). {{PLURAL:$3|Detdiar brükerkonto as|Jodiar brükerkontos san}} mä detdiar E-Mail-adres ferbünjen:

$2

{{PLURAL:$3|Detheer tidjwiis paaswurd lääpt|Joheer tidjwiis paaswurden luup}} efter {{PLURAL:$5|ään dai|$5 daar}} uf. 
Dü skulst di uunmelde an en nei paaswurd iinracht. Wan hoker ööders detheer uunfraag steld hää an dü din ual paaswurd käänst, do säärst dü niks widjer onernem. Melde di ianfach widjerhen mä din ual paaswurd uun.',
'passwordreset-emailtext-user' => 'Di brüker $1 üüb {{SITENAME}} hää am brükerinformatsjuunen för {{SITENAME}} uunfraaget ($4). {{PLURAL:$3|Detdiar brükerkonto as|Jodiar brükerkontos san}} mä detdiar E-Mail-Adres ferbünjen:

$2

{{PLURAL:$3|Detheer tidjwiis paaswurd lääpt|Joheer tidjwiis paaswurden luup}} efter {{PLURAL:$5|ään dai|$5 daar}} uf. Dü skulst di uunmelde an en nei paaswurd iinracht. Wan hoker ööders detheer uunfraag steld hää of dü din ual paaswurd käänst, säärst dü niks widjer onernem. Melde di ianfach mä din ual paaswurd uun.',
'passwordreset-emailelement' => 'Brükernoome: $1
Tidwis paasuurd: $2',
'passwordreset-emailsent' => 'Diar as en E-Mail tu di onerwais.',
'passwordreset-emailsent-capture' => 'Detdiar E-Mail, wat oner uunwiset woort, as tu di onerwais.',
'passwordreset-emailerror-capture' => 'Detdiar E-Mail, wat oner uunwiset woort, wiar tu di onerwais, oober küd ei tu di {{GENDER:$2|brüker}} ufsjüürd wurd: $1',

# Special:ChangeEmail
'changeemail' => 'Feranre det E-Mail-adres',
'changeemail-header' => 'Feranre det E-Mail-adres',
'changeemail-text' => 'Fal detdiar formulaar hialandaal ütj, am din E-Mail-adres tu feranrin. Diarför skel dü din paaswurd uundu.',
'changeemail-no-info' => 'Dü möist önjmälded weese am ju sid diräkt tu tu gripen.',
'changeemail-oldemail' => 'Aktuel e-mail adres',
'changeemail-newemail' => 'Nei e-mail adres',
'changeemail-none' => '(niin)',
'changeemail-password' => 'Din {{SITENAME}} paaswurd:',
'changeemail-submit' => 'E-mail adres feranre',
'changeemail-cancel' => 'Ufbreeg',

# Special:ResetTokens
'resettokens' => 'Tokens turagsaat',
'resettokens-text' => "Dü könst 'tokens' turagsaat, am priwoot dooten tu bewerkin, diar mä din brükerkonto ferbünjen san.",
'resettokens-no-tokens' => 'Diar san nian tokens turagtusaaten.',
'resettokens-legend' => 'Tokens turagsaat',
'resettokens-tokens' => 'Tokens:',
'resettokens-token-label' => '$1 (aktuel wäärs: $2)',
'resettokens-watchlist-token' => "Token för webfeed (Atom/RSS) mä [[Special:Watchlist|feranrangen faan sidjen, diar dü uun't uug behual wel]]",
'resettokens-done' => 'Tokems san turagsaat wurden.',
'resettokens-resetbutton' => 'Enkelt tokens turagsaat',

# Edit page toolbar
'bold_sample' => 'Fäät buksteewen',
'bold_tip' => 'Fäät buksteewen',
'italic_sample' => 'Kursiif buksteewen',
'italic_tip' => 'Kursiif buksteewen',
'link_sample' => 'Link-tekst',
'link_tip' => 'Intern ferwisang',
'extlink_sample' => 'http://www.example.com link-tekst',
'extlink_tip' => 'Ekstern ferwisang (seenk am http:// prefix)',
'headline_sample' => 'Auerskraft (grate 2)',
'headline_tip' => 'Auerskraft (grate 2)',
'nowiki_sample' => 'Ünformatiaret tekst diar tusaat.',
'nowiki_tip' => 'Ünformatiaret tekst',
'image_tip' => 'Iinbünjen datei',
'media_tip' => 'Meediendatei-link',
'sig_tip' => 'Din onerskraft mä tidjstempel',
'hr_tip' => 'Horisontaal streg (ei auerdriiw diarmä)',

# Edit pages
'summary' => 'Tuupfaadet:',
'subject' => 'Auerskraft:',
'minoredit' => 'Det as man en letj feranrang',
'watchthis' => "Detdiar sidj uun't uug behual",
'savearticle' => 'Sidj seekre',
'preview' => 'Iarst ans luke',
'showpreview' => 'Iarst ans luke',
'showlivepreview' => 'Glik uunluke',
'showdiff' => 'Feranrangen wise',
'anoneditwarning' => "'''Paase üüb:''' Dü bewerkest detdiar sidj anonüüm. Wan dü det seekerst, woort din aktuel IP-adres uun a ferluup aptiakent, an as diarmä '''för arken''' iintusen.",
'anonpreviewwarning' => '"Dü beest ei uunmeldet. Bi\'t seekrin woort din IP-adres uun a ferluup faan werjuunen aptiakent."',
'missingsummary' => "'''Paase üüb:''' Dü heest det ei tuupfaadet.
Wan dü det sidj seekerst, woort det saner en kurtfaadet beskriiwang auernimen.",
'missingcommenttext' => 'Faade det oner tuup.',
'missingcommentheader' => "'''Paase üüb:''' Dü heest nian auerskraft uunden.
Wan dü det sidj seekerst, woort det saner auerskraft auernimen.",
'summary-preview' => 'Föörskau faan det tuupfaadang:',
'subject-preview' => 'Föörskau faan det auerskraft:',
'blockedtitle' => 'Brüker as speret',
'blockedtext' => "'''Dan brükernööm of IP adres as speret wurden.'''

Det as maaget wurden faan $1.
Di grünj as ''$2''.

* Began: $8
* Aanj: $6
* Bedraapt: $7

Dü könst $1 kontaktiare of uk en [[{{MediaWiki:Grouppage-sysop}}|administraator]] am det tu diskutiarin.

Dü könst ei det E-Mail-funktsjuun 'E-mail tu dideere brüker' brük, so loong dü nian E-Mail-adres uun din [[Special:Preferences|brükerkonto iinstelangen]] uunden heest of wan det E-Mail-funktsjuun för di speret wurden as.

Uugenblakelk as din IP addres $3, an det sper ID as #$5.
För arke uunfraag wurd aal jo informatsjuunen boowen brükt.",
'autoblockedtext' => "'''Din IP adres as speret wurden, auer det faan en öödern spereten brüker brükt wurden as.'''

Di grünj as:
: ''$2''.

* Began: $8
* Aanj: $6
* Bedraapt: $7

Dü könst $1 kontaktiare of uk en [[{{MediaWiki:Grouppage-sysop}}|administraator]] am det tu diskutiarin.

Dü könst ei det E-Mail-funktsjuun 'E-mail tu dideere brüker' brük, so loong dü nian E-Mail-adres uun din [[Special:Preferences|brükerkonto iinstelangen]] uunden heest of wan det E-Mail-funktsjuun för di speret wurden as.

Uugenblakelk as din IP addres $3, an det sper ID as #$5.
För arke uunfraag wurd aal jo informatsjuunen boowen brükt.",
'blockednoreason' => 'nään grünj uunden',
'whitelistedittext' => 'Dü skel di $1, am sidjen tu bewerkin.',
'confirmedittext' => 'Dü skel iarst din e-mail-adres gudkään, iar dü began könst tu werkin. Maage det üüb det sidj mä din persöönelk [[Special:Preferences|iinstelangen]].',
'nosuchsectiontitle' => 'Kirew ei fünjen',
'nosuchsectiontext' => "Dü wulst en kirew feranre, diar't goorei jaft.
Ferlicht as det stregen of fersköwen wurden, jüst üs dü det sidj bewerke wulst.",
'loginreqtitle' => 'Dü skel di uunmelde.',
'loginreqlink' => 'Uunmelde',
'loginreqpagetext' => 'Dü skel di $1, am ööder sidjen uuntulukin.',
'accmailtitle' => 'Paaswurd as ferschüürd wurden.',
'accmailtext' => "En tufelag iinracht paaswurd för [[User talk:$1|$1]] as tu $2 ferschüürd wurden. Det koon üüb det spezial-sidj ''[[Special:ChangePassword|Paaswurd anre]]'' feranert wurd, wan dü uunmeldet beest.",
'newarticle' => '(Nei)',
'newarticletext' => "Dü beest en ferwisang tu en sidj fulagt, diar't noch ei jaft.
Am det sidj iinturachten, skriiw dan tekst uun det fial för't bewerkin iin.
Üüb det [[{{MediaWiki:Helppage}}|halepsidj]] fanjst dü halep.
Wan dü ütj fersen heer beest, trak ianfach üüb di '''turag'''-knoop faan dan browser.",
'anontalkpagetext' => "----''Üüb detheer sidj könst dü en ünbekäänden brüker en nooracht du. Det lääpt auer sin IP adres. IP adresen kön faan flook brükern brükt wurd. Wan dü mä detheer nooracht niks began könst, do as det ferlicht för hoker ööders mend weesen. Dü säärst niks widjer onernem. Wan dü en aanj [[Special:UserLogin/signup|brükerkonto iinrachst]] of di [[Special:UserLogin|uunmeldest]], komt sowat ei weder föör.",
'noarticletext' => 'Üüb detdiar sidj stäänt noch niks.
Dü könst didiar tiitel üüb ööder sidjen [[Special:Search/{{PAGENAME}}|schük]],
<span class="plainlinks">uun [{{fullurl:{{#special:Log}}|page={{FULLPAGENAMEE}}}} logbuken schük] of detdiar sidj [{{fullurl:{{FULLPAGENAME}}|action=edit}} bewerke]</span>.',
'noarticletext-nopermission' => 'Üüb detdiar sidj stäänt noch niks, oober dü mutst diar uk niks iinskriiw.
Dü könst diar üüb ööder sidjen efter [[Special:Search/{{PAGENAME}}|schük]] of a <span class="plainlinks">[{{fullurl:{{#special:Log}}|page={{FULLPAGENAME}}}} logbuken uunluke].</span>',
'missing-revision' => 'Det werjuun #$1 faan det sidj "{{PAGENAME}}" jaft at ei.

Det komt diar miast faan, dat en ual ferwisang stregen wurden as.
Dü könst det uun\'t [{{fullurl:{{#Special:Log}}/delete|page={{FULLPAGENAMEE}}}} logbuk faan stregen sidjen] efterlees.',
'userpage-userdoesnotexist' => "Det brükerkonto ''$1'' as ei diar.
Wel dü detdiar sidj würelk maage/bewerke?",
'userpage-userdoesnotexist-view' => 'Son brükerkonto "$1" jaft at ei.',
'blocked-notice-logextract' => "Didiar brüker as speret. Det stäänt uun't sper-logbuk:",
'clearyourcache' => "'''Beaachte:''' Maage di cache faan dan browser leesag, wan dü a feranrangen sä wel.
* '''Firefox / Safari:''' Hual ''Shift'' bi't aktualisiarin, of trak ''Strg an F5'' of ''Strg an R'' (''⌘an R'' üüb en Mac)
* '''Google Chrome:''' Trak ''Strg an Shift an R'' (''⌘an Shift an R'' üüb en Mac)
* '''Internet Explorer:''' Hual ''Strg'' bi't aktualisiarin, of trak ''Strg an F5''
* '''Opera:''' ''Extras - Internetspuren löschen - Individuelle Auswahl - Den kompletten Cache löschen''",
'usercssyoucanpreview' => "'''Tip:''' Brük di „{{int:showpreview}}“-knoop, am din nei CSS föör det seekrin tu testin.",
'userjsyoucanpreview' => "'''Tip:''' Brük di „{{int:showpreview}}“-knoop, am din nei JavaScript föör det seekrin tu testin.",
'usercsspreview' => "'''Seenk diaram, dat det bluas en föörskau faan din CSS as.'''
'''Det as noch ei seekert wurden!'''",
'userjspreview' => "'''Seenk diaram, dat det bluas en föörskau faan din JavaScript as.'''
'''Det as noch ei seekert wurden!'''",
'sitecsspreview' => "'''Påås aw dåt dü jüdeer CSS bloot forbekiikest.'''
'''Dåt as nuch ai spiikerd!'''",
'sitejspreview' => "'''Påås aw dåt dü jüdeer JavaScript code bloot forbekiikest.'''
'''Dåt as nuch ai spiikerd!'''",
'userinvalidcssjstitle' => "''Paase üüb:''' Skak \"\$1\" jaft at ei.
Seenk diaram, dat faan en brüker iinracht .css- an .js-sidjen mä en letjen buksteew began skel. Bispal:
''{{ns:user}}:Münsterkjarl/vector.css'' uunsteed faan ''{{ns:user}}:Münsterkjarl/Vector.css''.",
'updated' => '(Feranert)',
'note' => "'''Paase üüb:'''",
'previewnote' => "'''Heer könst dü sä, hü det sidj wurd skal.'''
Det sidj as oober noch ei seekert!",
'continue-editing' => "Gung tu't fial för't bewerkin",
'previewconflict' => 'Detdiar föörskau wiset di boowenst dial faan dan tekst. So schocht hi ütj, wan dü ham nü seekerst.',
'session_fail_preview' => "'''Din werk küd ei ufseekert wurd, diar as wat skiaf gingen.'''
Ferschük det man noch ans an trak do üüb ''Sidj seekre''.
Wan't do imer noch ei loket, [[Special:UserLogout|melde di uf]] an weder uun.",
'session_fail_preview_html' => "'''Din werk küd ei seekert wurd. Diar as wat skiaf gingen.'''

''Uun {{SITENAME}} as HTML aktiwiaret, an diaram as JavaScript deaktiwiaret wurden.''

Ferschük det man noch ans an trak do üüb ''Sidj seekre''.
Wan't do imer noch ei loket, [[Special:UserLogout|melde di uf]] an weder uun.",
'token_suffix_mismatch' => "'''Din werk küd ei ufseekert wurd, auer diar frääm tiaken uun san.'''

Det komt flooksis föör, wan Dan anonym Proxy-siinst ei rocht werket.",
'edit_form_incomplete' => "'''Enkelt dialen faan det formulaar san ei rocht uunkimen.'''
Wees so gud an kontroliare ales noch ans.",
'editing' => 'Bewerkin faan $1',
'creating' => 'Maage $1',
'editingsection' => 'Bewerke $1 (kirew)',
'editingcomment' => 'Bewerke $1 (nei kirew)',
'editconflict' => "Konflikt bi't bewerkin (BK): $1",
'explainconflict' => "Hoker ööders hää detheer sidj feranert, üs dü jüst diarmä uun a gang wiarst.
Boowen könst dü di aktuel stant sä. Oner stun din fernanrangen.
Bluas wat '''boowen''' stäänt, woort seekert. Diaram kopiare din feranrangen boowen iin.
An do trak „{{int:savearticle}}“.",
'yourtext' => 'Dan tekst',
'storedversion' => 'Seekert werjuun',
'nonunicodebrowser' => "'''Paase üüb:''' Dan browser komt ei mä unicode-tiakens turocht. Wees so gud an brük en öödern browser.",
'editingold' => "'''Paase üüb: Dü bewerkest en ual werjuun faan detdiar sidj.
Wan dü det seekerst, wurd aal a nei werjuunen auerskrewen.'''",
'yourdiff' => 'Ferskeeler',
'copyrightwarning' => "Seenk diaram, dat bidracher tu {{SITENAME}} oner det \$1 ütjden wurd (muar stäänt bi \$2).
Wan dü ei wel, dat öödern dan bidrach widjer bewerke, do trak ei üüb \"Seekre\".<br />
Dü ferspräächst, dat dü di tekst salew skrewen heest of dat diar nian kopiarrochten üüb lei.
'''Dü mutst nian werk mä kopiarrochten saner ferloof heer iinstel!'''",
'copyrightwarning2' => "Seenk diaram, dat det sidj {{SITENAME}} faan öödern bewerket, feranert of uk stregen wurd koon. Wan dü det ei wel, do skriiw heer niks iin! 

Wan dü heer wat iinskrafst, do beest dü diarmä iinferstenen an seekerst tu, dat dü det '''salew skrewen''' heest of faan en steed auernimen heest, huar '''nian rochten''' üüb lei. (Luke bi $1, wan dü muar wed wel.)

'''Auerdreeg nään frääm teksten an bilen saner ferloof!'''",
'longpageerror' => "'''Error: Dan tekst as {{PLURAL:$1|ian kilobyte|$1 kilobytes}} lung, hi mut oober ei linger wees üs {{PLURAL:$2|ian kilobyte|$2 kilobytes}}.'''Hi koon ei ufspiikerd wurd.",
'readonlywarning' => "'''Paase üüb: Dü könst uun uugenblak ei üüb det dootenbeenk tugrip. Din dooten kön ei seekert wurd.''' Wees so gud an seekre dan tekst iarst ans üüb dan reegner, an ferschük leederhen, ham tu auerdreegen.

Grünj för det sperin: $1",
'protectedpagewarning' => "'''Paase üüb: Detdiar sidj as speret wurden. Bluas administratooren kön det bewerke.'''
Uun't logbuk stäänt muar diartu:",
'semiprotectedpagewarning' => "'''Paase üüb: Detdiar sidj as dialwiis tu't bewerkin speret wurden. Bluas gudkäänd brükern kön det bewerke.'''
Uun't logbuk stäänt muar diartu:",
'cascadeprotectedwarning' => "'''Paase üüb:''' Detdiar sidj koon bluas faan administratooren bewerket wurd. Hat as uun {{PLURAL:$1|detdiar ööder sidj|jodiar ööder sidjen}} iinbünjen, diar troch en kaskaaden-optsjuun seekert {{PLURAL:$1|as|san}}:",
'titleprotectedwarning' => "'''Paase üüb: \"Detdiar sidj mä didiar nööm koon ei faan arken bewerket wurd. Bluas enkelt brükern mä [[Special:ListGroupRights|was brükerrochten]] kön detdiar sidj nei maage of bewerke.'''
Uun't logbuk stäänt muar diartu:",
'templatesused' => '{{PLURAL:$1|Detdiar föörlaag woort|Jodiar föörlaagen wurd}} üüb detdiar sidj brükt:',
'templatesusedpreview' => '{{PLURAL:$1|Detdiar föörlaag woort|Jodiar föörlaagen wurd}} uun detdiar sidjenföörskau brükt:',
'templatesusedsection' => '{{PLURAL:$1|Detdiar föörlaag woort|Jodiar föörlaagen wurd}} uun didiar kirew brükt:',
'template-protected' => '(seekert)',
'template-semiprotected' => '(hualew-seekert)',
'hiddencategories' => 'Detdiar sidj hiart tu {{PLURAL:$1|1 ferbürgen kategorii|$1 ferbürgen kategoriin}}:',
'nocreatetext' => 'Üüb {{SITENAME}} könst dü nian nei sidjen maage, oober dü könst sidjen feranre. [[Special:UserLogin|Melde di uun of racht en brükerkonto iin]].',
'nocreate-loggedin' => 'Dü mutst nian nei sidjen maage.',
'sectioneditnotsupported-title' => 'Det bewerkin faan enkelt kirwer as ei mögelk.',
'sectioneditnotsupported-text' => 'Det bewerkin faan enkelt kirwer gongt üüb detdiar sidj ei.',
'permissionserrors' => 'Brükerrochten ling ei',
'permissionserrorstext' => 'Dü heest diar ei a brükerrochten för. {{PLURAL:$1|Grünj|Grünjer}}:',
'permissionserrorstext-withaction' => 'Dü heest ei det rocht, $2.
{{PLURAL:$1|Grünj|Grünjer}}:',
'recreate-moveddeleted-warn' => "'''Paase üüb: Dü wel en artiikel maage, diar iar al ans stregen wurden as.'''
Auerlei di det gud, amdat dü niks ferkiard maagest.
Uun't logbuk stäänt muar diartu:",
'moveddeleted-notice' => "Detdiar sidj as stregen wurden.
Uun't strik- an fersküüw-logbuk oner stäänt muar diartu.",
'log-fulllog' => 'Logbuk-iindracher uunluke',
'edit-hook-aborted' => "Det bewerkin as faan't software ufbreegen wurden. Di grünj as ei bekäänd.",
'edit-gone-missing' => 'Detdiar sidj küd ei aktualisiaret wurd. Ferlicht as det stregen wurden.',
'edit-conflict' => "Konflikt bi't bewerkin (BK).",
'edit-no-change' => 'Din feranrang woort ei seekert, auer dü di tekst ei feranert heest.',
'postedit-confirmation' => 'Din feranrang as seekert wurden.',
'edit-already-exists' => 'Det nei sidj küd ei iinracht wurd. Son sidj as al diar.',
'defaultmessagetext' => 'Standard tekst',
'content-failed-to-parse' => "Parsing faan $2 för't model $1 ging skiaf: $3",
'invalid-content-data' => 'Diar stäänt wat uun, wat diar ei hen hiart',
'content-not-allowed-here' => '„$1“ mut ei skrewen wurd üüb sidj [[$2]]',
'editwarning-warning' => 'Wan dü detheer sidj slotst, kön feranrangen ferleesen gung.
Üs uunmeldet brüker könst dü detheer wäärnang bi din iinstelangen oner „Bewerke“ wechknipse.',

# Content models
'content-model-wikitext' => 'wikitekst',
'content-model-text' => 'normool tekst',
'content-model-javascript' => 'JavaScript',
'content-model-css' => 'CSS',

# Parser/template warnings
'expensive-parserfunction-warning' => "'''Paase üüb:''' Detdiar sidj brükt tuföl widjloftag server-funktjuunen.

Diar mut ei muar üs {{PLURAL:$2|1|$2}} brükt wurd. Nü {{PLURAL:$1|woort diar 1|wurd diar $1}} brükt.",
'expensive-parserfunction-category' => 'Sidjen mä tuföl parser-funktjuunen.',
'post-expand-template-inclusion-warning' => "'''Paase üüb:''' Enkelt föörlaagen san tu grat, jo kön ei uun det sidj iinbünjen wurd.",
'post-expand-template-inclusion-category' => 'Sidjen mä muar üs det maksimaal taal faan iinbünjen föörlaagen.',
'post-expand-template-argument-warning' => "'''Paase üüb:''' Üüb detdiar sidj stäänt tumanst ään iindrach för en föörlaag, diar tu grat as. Sok iindracher wurd ei ferwerket.",
'post-expand-template-argument-category' => 'Sidjen mä föörlaagen, huar ei arke iindrach brükt wurd koon.',
'parser-template-loop-warning' => 'Diar as en föörlaagensleuf: [[$1]]',
'parser-template-recursion-depth-warning' => 'Tuföl föörlaagen uun föörlaagen ($1)',
'language-converter-depth-warning' => 'Spriakenkonwerter auerläästet ($1)',
'node-count-exceeded-category' => 'Jodiar sidjen haa tuföl ferbinjangen (nodes)',
'node-count-exceeded-warning' => 'Detdiar sidj hää tuföl ferbinjangen (nodes)',
'expansion-depth-exceeded-category' => 'Jodiar sidjen haa tuföl ütjwidjangen (expansion)',
'expansion-depth-exceeded-warning' => 'Detdiar sidj hää tuföl ütjwidjangen (expansion)',
'parser-unstrip-loop-warning' => 'Diar as en jinsidjag ferwisang',
'parser-unstrip-recursion-limit' => 'Tuföl jinsidjag ferwisangen bi $1',
'converter-manual-rule-error' => "Bi't manuel reegel för't spriakferanrang lääpt wat skiaf.",

# "Undo" feature
'undo-success' => 'Detdiar feranrang koon turag nimen wurd. 
Luke oner, of dü det uk würelk du wel, an do seekre din feranrangen.',
'undo-failure' => 'Det feranrang küd ei stregen wurd, auer di kirew uuntesken feranert wurden as.',
'undo-norev' => 'Det feranrang küd ei turagsaat wurd, auer diar niks as of auer det sidj stregen wurden as.',
'undo-summary' => 'Feranrang $1 faan [[Special:Contributions/$2|$2]] ([[User talk:$2|Diskusjuun]]) turagsaat.',
'undo-summary-username-hidden' => 'Feranrang $1 faan en ferbürgenen brüker turagsaat',

# Account creation failure
'cantcreateaccounttitle' => 'Det brükerkonto koon ei iinracht wurd',
'cantcreateaccount-text' => "Det iinrachten faan en brükerkonto faan det IP-adres '''($1)''' as faan [[User:$3|$3]] speret wurden.

Grünj för det sper: ''$2''",

# History pages
'viewpagelogs' => 'Logbuken faan detdiar sidj uunwise',
'nohistory' => 'Detdiar sidj hää nään ferluup faan werjuunen.',
'currentrev' => 'Leetst werjuun',
'currentrev-asof' => 'Leetst werjuun faan di $2, am a klook $3',
'revisionasof' => 'Werjuun faan a $2, klook $3',
'revision-info' => 'Werjuun faan di $4 am a klook $5 faan $2',
'previousrevision' => '← Naistääler werjuun:',
'nextrevision' => 'Naistjonger werjuun →',
'currentrevisionlink' => 'Leetst werjuun',
'cur' => 'Aktuel',
'next' => 'Naist',
'last' => 'Leetst',
'page_first' => 'Began',
'page_last' => 'Aanj',
'histlegend' => "Am a feranrangen uuntuwisin, schük tau werjuunen ütj an trak üüb „{{int:compareselectedversions}}“.<br />
* '''({{int:cur}})''' = ferskeel tu't aktuel werjuun, '''({{int:last}})''' = ferskeel tu't leetst werjuun, '''{{int:minoreditletter}}''' = letj feranrang.",
'history-fieldset-title' => 'Schük uun a ferluup',
'history-show-deleted' => 'Bluas stregen werjuunen',
'histfirst' => 'Äälst',
'histlast' => 'Neist',
'historysize' => '({{PLURAL:$1|1 byte|$1 bytes}})',
'historyempty' => '(leesag)',

# Revision feed
'history-feed-title' => 'Ferluup faan werjuunen',
'history-feed-description' => 'Ferluup faan werjuunen faan detdiar sidj uun {{SITENAME}}',
'history-feed-item-nocomment' => '$1 di $3 am a klook $4',
'history-feed-empty' => 'Son sidj jaft at ei. Ferlicht as det stregen of fersköwen wurden. [[Special:Search|Schük]] üüb {{SITENAME}} efter nei sidjen, diar diartu paase.',

# Revision deletion
'rev-deleted-comment' => '(Tuupfaadet beskriiwang wechnimen)',
'rev-deleted-user' => '(Brükernööm stregen)',
'rev-deleted-event' => '(Logbuk-iindrach stregen)',
'rev-deleted-user-contribs' => '[Brükernööm of IP-adres wechnimen - Feranrangen uun bidracher ferbürgen]',
'rev-deleted-text-permission' => "Detdiar werjuun as '''stregen''' wurden.
Uun't [{{fullurl:{{#special:Log}}/delete|page={{FULLPAGENAMEE}}}} strik-logbuk] stäänt muar diartu.",
'rev-deleted-text-unhide' => "Detdiar werjuun as '''stregen''' wurden.
Uun't [{{fullurl:{{#special:Log}}/delete|page={{FULLPAGENAMEE}}}} strik-logbuk] stäänt muar diartu.
Dü könst [$1 detdiar werjuun uunluke], wan dü wel.",
'rev-suppressed-text-unhide' => "Detdiar werjuun as '''ferbürgen''' wurden.
Uun't [{{fullurl:{{#special:Log}}/suppress|page={{FULLPAGENAMEE}}}} fersteeg-logbuk] stäänt muar diartu.
Dü könst [$1 detdiar werjuun uunluke], wan dü wel.",
'rev-deleted-text-view' => "Detdiar werjuun as '''stregen''' wurden.
Dü könst det noch uunluke. Uun't [{{fullurl:{{#special:Log}}/delete|page={{FULLPAGENAMEE}}}} strik-logbuk] stäänt muar diartu.",
'rev-suppressed-text-view' => "Detdiar werjuun as '''ferbürgen''' wurden.
Dü könst det noch uunluke. Uun't [{{fullurl:{{#special:Log}}/suppress|page={{FULLPAGENAMEE}}}} fersteeg-logbuk] stäänt muar diartu.",
'rev-deleted-no-diff' => "Dü könst di ferskeel ei uunluke, auer ian werjuun '''stregen''' wurden as.
Wan dü muar wed wel, luke iin uun't [{{fullurl:{{#special:Log}}/delete|page={{FULLPAGENAMEE}}}} strik-logbuk].",
'rev-suppressed-no-diff' => "Dü könst di ferskeel ei uunluke, auer ian werjuun '''stregen''' wurden as.",
'rev-deleted-unhide-diff' => "Ian faan jodiar werjuunen as '''stregen''' wurden. Wan dü muar wed wel, luke iin uun't [{{fullurl:{{#special:Log}}/delete|page={{FULLPAGENAMEE}}}} strik-logbuk].
Dü könst [$1 di ferskeel uunluke], wan dü wel.",
'rev-suppressed-unhide-diff' => "Ian faan jodiar werjuunen as '''ferbürgen''' wurden. Wan dü muar wed wel, luke iin uun't [{{fullurl:{{#special:Log}}/delete|page={{FULLPAGENAMEE}}}} fersteeg-logbuk].
Dü könst [$1 di ferskeel uunluke], wan dü wel.",
'rev-deleted-diff-view' => "Ian faan jodiar werjuunen as '''stregen''' wurden.
Dü könst di ferskeel uunluke. Wan dü muar wed wel, luke iin uun't [{{fullurl:{{#Special:Log}}/delete|page={{FULLPAGENAMEE}}}} strik-logbuk].",
'rev-suppressed-diff-view' => "Ian faan jodiar werjuunen as '''ferbürgen''' wurden. Dü könst di ferskeel uunluke. Wan dü muar wed wel, luke iin uun't [{{fullurl:{{#Special:Log}}/suppress|page={{FULLPAGENAMEE}}}} fersteeg-logbuk].",
'rev-delundel' => 'wise/fersteeg',
'rev-showdeleted' => 'wise',
'revisiondelete' => 'Werjuunen strik of weder iinstel',
'revdelete-nooldid-title' => 'Nian werjuun uunden',
'revdelete-nooldid-text' => 'Dü heest nian werjuun för detheer aktjuun uunden, of det werjuun jaft at ei, of dü ferschükst, en aktuel werjuun tu striken.',
'revdelete-nologtype-title' => 'Nian log-typ uunden',
'revdelete-nologtype-text' => 'Dü heest nään log-typ för detdiar aktjuun uunden.',
'revdelete-nologid-title' => 'Ferkiard log-iindrach',
'revdelete-nologid-text' => 'Dü heest nään log-typ uunden of di log-typ as ferkiard.',
'revdelete-no-file' => 'Son dateinööm as ei diar.',
'revdelete-show-file-confirm' => 'Wel dü würelk det stregen werjuun faan det datei „<nowiki>$1</nowiki>“ faan di $2, am a klook $3 uunluke?',
'revdelete-show-file-submit' => 'Ja',
'revdelete-selected' => "'''{{PLURAL:$2|Ütjsoocht werjuun|Ütjsoocht werjuunen}} faan [[:$1]]:'''",
'logdelete-selected' => "'''{{PLURAL:$1|Ütjsoocht logbukiindrach|Ütjsoocht logbukiindracher}}:'''",
'revdelete-text' => "'''Stregen werjuunen an aktjuunen bliiw uun di ferluup an uun a logbuken, man det koon ei arken efterlees.'''

Ööder administratooren üüb {{SITENAME}} kön oober üüb di ferbürgen ferluup tugrip an tu nuad en ual werjuun weder iinstel.",
'revdelete-confirm' => 'Ferseekre noch ans, dat dü det würelk du wel, dat dü witjst, wat dü dääst, an dat det mä a [[{{MediaWiki:Policy-url}}|bestemangen]] auerian stemet.',
'revdelete-suppress-text' => "Det skul '''bluas''' onertrakt wurd bi:
* Persöönelk informatsjuunen, diar näämen wat uungung
*: ''Adresen, Tilefoonnumern, Ferseekerangsnumern an sowat''",
'revdelete-legend' => 'Iinstelangen, hüföl tu sen wees skal',
'revdelete-hide-text' => 'Tekst faan det werjuun fersteeg',
'revdelete-hide-image' => 'Fersteeg, wat uun det datei stäänt',
'revdelete-hide-name' => 'Logbuk-aktjuun fersteeg',
'revdelete-hide-comment' => 'Tuupfaadet beskriiwang fersteeg',
'revdelete-hide-user' => 'Brükernööm/IP-adres faan di brüker fersteeg',
'revdelete-hide-restricted' => 'Dooten uk för administratooren an öödern fersteeg',
'revdelete-radio-same' => '(ei feranre)',
'revdelete-radio-set' => 'Ja',
'revdelete-radio-unset' => 'Naan',
'revdelete-suppress' => "Grünj för't striken uk för administratooren an öödern fersteeg",
'revdelete-unsuppress' => 'Weder iinsteld werjuunen luasmaage',
'revdelete-log' => 'Grünj:',
'revdelete-submit' => 'Widjer för {{PLURAL:$1|ütjsoocht werjuun|ütjsoocht werjuunen}}',
'revdelete-success' => "'''Det werjuunsuunsicht as aktualisiaret wurden.'''",
'revdelete-failure' => "'''Jü färsjoonsönjsicht köö ai aktualisiird wårde:'''
$1",
'logdelete-success' => "'''Logbukuunsicht as aktualisiaret wurden.'''",
'logdelete-failure' => "'''Det logbukuunsicht küd ei feranert wurd:'''
$1",
'revdel-restore' => 'Feranre, wat tu sen wees skal',
'revdel-restore-deleted' => 'stregen werjuunen',
'revdel-restore-visible' => 'sichtboor werjuunen',
'pagehist' => 'Ferluup faan werjuunen',
'deletedhist' => 'Stregen werjuunen',
'revdelete-hide-current' => 'Di iindrach faan $1, klook $2 koon ei ferbürgen wurd. Det as det aktuel werjuun.',
'revdelete-show-no-access' => 'Bi\'t bewerkin di $1, am a klook $2 as wat skiaf gingen: Didiar iindrach as üs "hualew klaar" markiaret.
Dü könst diar ei üüb tugrip.',
'revdelete-modify-no-access' => 'Bi\'t bewerkin di $1, am a klook $2 as wat skiaf gingen: Diheer iindrach as üs "hualew klaar" markiaret. Dü könst diar ei üüb tugrip.',
'revdelete-modify-missing' => "Bi't bewerkin faan ID $1 as wat skiaf gingen: At waant uun a dootenbeenk!",
'revdelete-no-change' => "'''Waarskau:''' Di iindrach faan di $1, am a klook $2 hää al jodiar iinstelangen.",
'revdelete-concurrent-change' => "Bi't bewerkin faan di iindrach di $1, am a klook $2 as wat skiaf gingen: At schocht so ütj, üs wan hoker ööders det bewerket hää, iar dü det bewerke wulst. Luke iin uun a logbuken.",
'revdelete-only-restricted' => "Bi't fersteegen faan di iindrach di $1, am a klook $2 as wat skiaf gingen: Dü könst di iindrach ei föör administratooren fersteeg, saner ööder iinstelangen tu feranrin.",
'revdelete-reason-dropdown' => "*Grünjer för't striken san miast
** Copyright woort ei iinhäälen
** Persöönelk informatsjuunen, diar näämen wat uungung
** Brükernööm as ei tuläät
** Fülk informatsjuunen",
'revdelete-otherreason' => 'Ööder/noch en grünj:',
'revdelete-reasonotherlist' => 'Ööder grünj',
'revdelete-edit-reasonlist' => "Grünjer för't striken bewerke",
'revdelete-offender' => 'Skriiwer faan detdiar werjuun:',

# Suppression log
'suppressionlog' => 'Oversight-logbuk',
'suppressionlogtext' => 'Detheer as det logbuk faan oversighter aktsjuunen.
Luke bi [[Special:BlockList|List faan speret IP-adresen an brükernöömer]] för aktuel sperangen.',

# History merging
'mergehistory' => 'Ferluup faan werjuunen tuupfeer',
'mergehistory-header' => 'Mä detdiar spezial-sidj könst dü di werjuunsferluup faan ian sidj mä di ferluup faan en ööder sidj tuupfeer.
Aachte diarüüb, dat di ferluup faan det sidj uk rocht as.',
'mergehistory-box' => 'Ferluup faan tau sidjen tuupfeer:',
'mergehistory-from' => 'Iarst sidj:',
'mergehistory-into' => 'Ööder sidj:',
'mergehistory-list' => 'Werjuunen, diar tuupfeerd wurd kön.',
'mergehistory-merge' => 'Jodiar werjuunen faan „[[:$1]]“ kön efter „[[:$2]]“ auerdraanj wurd.
Kääntiakne det wersjuun, wat üs leetst mä auerdraanj wurd skal.
A nawigatjuun links saat ales weder turag üüb di ual stant.',
'mergehistory-go' => 'Wise werjuunen, diar tuupfeerd wurd kön.',
'mergehistory-submit' => 'Werjuunen tuupfeer',
'mergehistory-empty' => 'Nian werjuunen kön tuupfeerd wurd.',
'mergehistory-success' => '$3 {{PLURAL:$3|werjuun|werjuunen}} faan [[:$1]] tuupfeerd tu [[:$2]].',
'mergehistory-fail' => 'Werjuunen kön ei tuupfeerd wurd. Luke noch ans efter at sidj an a tidjen.',
'mergehistory-no-source' => 'Det iarst sidj "$1" as ai diar.',
'mergehistory-no-destination' => 'Det ööder sidj „$1“ as ei diar.',
'mergehistory-invalid-source' => 'Jurtkamstsid mötj en gülti sidnoome heewe.',
'mergehistory-invalid-destination' => 'Müüljsid mötj en gülti sidnoome weese.',
'mergehistory-autocomment' => '„[[:$1]]“ feriind eefter „[[:$2]]“',
'mergehistory-comment' => '„[[:$1]]“ tuupfeerd tu „[[:$2]]“: $3',
'mergehistory-same-destination' => 'Det iarst an det ööder sidj mut ei detsalew wees',
'mergehistory-reason' => 'Grünj:',

# Merge log
'mergelog' => 'Feriin-logbök',
'pagemerge-logentry' => '[[$1]] efter [[$2]] tuupfeerd (werjuunen bit $3)',
'revertmerge' => 'Det tuupfeeren turagsaat',
'mergelogpagetext' => 'Diar as det logbuk faan a tuupfeerd sidjen.',

# Diffs
'history-title' => '$1: Ferluup faan a werjuunen',
'difference-title' => 'Ferskeel tesken a werjuunen faan "$1"',
'difference-title-multipage' => 'Ferskeel tesken a sidjen "$1" an "$2"',
'difference-multipage' => '(Ferskeel tesken sidjen)',
'lineno' => 'Rä $1:',
'compareselectedversions' => 'Werjuunen ferglik',
'showhideselectedversions' => 'Werjuunen wise of fersteeg',
'editundo' => 'turagsaat',
'diff-empty' => '(nään ferskeel)',
'diff-multi' => '({{PLURAL:$1|Ian werjuun diartesken|$1 werjuunen diartesken}} faan {{PLURAL:$2|ään brüker|$2 brükern}} {{PLURAL:$1|woort|wurd}} ei uunwiset)',
'diff-multi-manyusers' => '({{PLURAL:$1|Ian werjuun diartesken|$1 werjuunen diartesken}} faan muar üs $2 {{PLURAL:$2|brüker|brükern}} wurd ei uunwiset)',
'difference-missing-revision' => "{{PLURAL:$2|Ian werjuun|$2 werjuunen}} faan di ferskeel ($1) {{PLURAL:$2|as|san}} ei fünjen wurden.

Det komt diar miast faan, dat en ual ferwisang stregen wurden as.
Dü könst det uun't [{{fullurl:{{#Special:Log}}/delete|page={{FULLPAGENAMEE}}}} logbuk faan stregen sidjen] efterlees.",

# Search results
'searchresults' => 'Fünjen sidjen',
'searchresults-title' => 'Fünjen sidjen för „$1“',
'searchresulttext' => "Wan dü muar auer't schüken uun {{SITENAME}} wed wel, luke efter bi [[{{MediaWiki:Helppage}}|{{int:help}}]].",
'searchsubtitle' => 'Din uunfraag: „[[:$1|$1]]“ ([[Special:Prefixindex/$1|sidjen, diar mä „$1“ began]]{{int:pipe-separator}}[[Special:WhatLinksHere/$1|sidjen, diar efter „$1“ ferwise]])',
'searchsubtitleinvalid' => 'Din uunfraag: "$1".',
'toomanymatches' => 'Diar kaam tuföl resultaaten üüb din uunfraag. Ferschük det ööders.',
'titlematches' => 'Auerianstemangen mä sidjennöömer',
'notitlematches' => 'Nian auerianstemangen mä sidjennöömer',
'textmatches' => 'Auerianstemangen mä teksten',
'notextmatches' => 'Nian auerianstemangen mä teksten',
'prevn' => '{{PLURAL:$1|leetst|leetst $1}}',
'nextn' => '{{PLURAL:$1|naist|naist $1}}',
'prevn-title' => 'Leetst $1 {{PLURAL:$1|resultaat|resultaaten}}',
'nextn-title' => 'Naist $1 {{PLURAL:$1|resultaat|resultaaten}}',
'shown-title' => 'Wise $1 {{PLURAL:$1|resultaat|resultaaten}} per sidj',
'viewprevnext' => 'Wise ($1 {{int:pipe-separator}} $2) ($3)',
'searchmenu-legend' => 'Säkmöölikhäide',
'searchmenu-exists' => "'''Deer as en sid nååmd \"[[:\$1]]\" önj jüdeer Wiki'''",
'searchmenu-new' => "'''Maage det sidj „[[:$1]]“ uun detheer wiki.'''",
'searchmenu-prefix' => '[[Special:PrefixIndex/$1|Wise aal jo sidjen, diar so began]]',
'searchprofile-articles' => 'Artiikler',
'searchprofile-project' => 'Halep- an Projektsidjen',
'searchprofile-images' => 'Multimedia',
'searchprofile-everything' => 'Ales',
'searchprofile-advanced' => 'Ütjwidjet',
'searchprofile-articles-tooltip' => 'Schük uun $1',
'searchprofile-project-tooltip' => 'Schük uun $1',
'searchprofile-images-tooltip' => 'Bilen schük',
'searchprofile-everything-tooltip' => 'Schük aueraal (uk diskusjuunssidjen)',
'searchprofile-advanced-tooltip' => 'Uun ööder nöömrümer schük',
'search-result-size' => '$1 ({{PLURAL:$2|1 wurd|$2 wurden}})',
'search-result-category-size' => '{{PLURAL:$1|1 sidj|$1 sidjen}} ({{PLURAL:$2|1 onerkategorii|$2 onerkategoriin}}, {{PLURAL:$3|1 datei|$3 datein}})',
'search-result-score' => 'Relewans: $1 %',
'search-redirect' => '(widjerfeerd faan „$1“)',
'search-section' => '(kirew $1)',
'search-suggest' => 'Mendst dü „$1“?',
'search-interwiki-caption' => 'Saster-projekten',
'search-interwiki-default' => '$1 resultaaten:',
'search-interwiki-more' => '(muar)',
'search-relatedarticle' => 'Ferbünjen',
'mwsuggest-disable' => "Föörslacher för't schüken deaktiwiare",
'searcheverything-enable' => 'Uun arke nöömrüm schük',
'searchrelated' => 'ferbünjen',
'searchall' => 'aaltumaal',
'showingresults' => "Heer {{PLURAL:$1|as '''1''' resultaat|san '''$1''' resultaaten}}, jo began mä numer '''$2.'''",
'showingresultsnum' => "Heer {{PLURAL:$3|as '''1''' resultaat|san '''$3''' resultaaten}}, jo began mä numer '''$2.'''",
'showingresultsheader' => "{{PLURAL:$5|resultaat '''$1''' faan '''$3'''|resultaaten '''$1-$2''' faan '''$3'''}}, för '''$4.'''",
'nonefound' => "'''Paase üüb:''' Diar wurd man enkelt nöömrümer trochsoocht. Wan dü ''all:'' föör din wurd skraft, do woort uk uun aal a nöömrümer (datein, kategoriin, föörlaagen asw.) soocht. Dü könst uk en wasen nöömrüm föörwechstel.",
'search-nonefound' => 'För din uunfraag san nian resultaaten fünjen wurden.',
'powersearch' => 'Ütjwidjet schüken',
'powersearch-legend' => 'Ütjwidjet schüken',
'powersearch-ns' => 'Schük uun nöömrümer:',
'powersearch-redir' => 'Widjerfeerangen uunwise',
'powersearch-field' => 'Schük efter:',
'powersearch-togglelabel' => 'Schük uun:',
'powersearch-toggleall' => 'Aaltumaal',
'powersearch-togglenone' => 'Nianen',
'search-external' => 'Schük ekstern',
'searchdisabled' => 'Det schüken üüb {{SITENAME}} as ei aktiif. Dü könst uuntesken mä Google schük. Seenk diaram, dat Google sin steegwurden miast ei üüb a leetst stant san.',
'search-error' => "Diar as wat skiaf gingen bi't schüken: $1",

# Preferences page
'preferences' => 'Iinstelangen',
'mypreferences' => 'Iinstelangen',
'prefs-edits' => 'Taal faan feranrangen:',
'prefsnologin' => 'Ei uunmeldet',
'prefsnologintext' => 'Dü skel <span class="plainlinks">[{{fullurl:{{#special:UserLogin}}|returnto=$1}} uunmeldet]</span> wees, am din iinstelangen tu feranrin.',
'changepassword' => 'Paaswurd feranre',
'prefs-skin' => 'Skak',
'skin-preview' => 'Föörskau',
'datedefault' => 'Föör-iinstelang',
'prefs-beta' => 'Beta mögelkhaiden',
'prefs-datetime' => 'Dai an klooktidj',
'prefs-labs' => 'Alpha mögelkhaiden',
'prefs-user-pages' => 'Brükersidjen',
'prefs-personal' => 'Brüker dooten',
'prefs-rc' => 'Leetst feranrangen',
'prefs-watchlist' => "Uun't uug behual",
'prefs-watchlist-days' => "So föl daar uun't uug behual:",
'prefs-watchlist-days-max' => 'Ei muar üs {{PLURAL:$1|ään dai|$1 daar}}',
'prefs-watchlist-edits' => 'Ei muar feranrangen üs:',
'prefs-watchlist-edits-max' => 'Ai mör as 1000',
'prefs-watchlist-token' => "Token för uun't uug behualen:",
'prefs-misc' => 'Dit an dat',
'prefs-resetpass' => 'Paaswurd feranre',
'prefs-changeemail' => 'Feranre det E-Mail-adres',
'prefs-setemail' => 'E-Mail-adres fäästlei:',
'prefs-email' => 'E-Mail iinstelangen',
'prefs-rendering' => 'Skak',
'saveprefs' => 'Iinstelangen seekre',
'resetprefs' => 'Wech diarmä',
'restoreprefs' => 'Normool iinstelangen weder haale (uun arke kirew)',
'prefs-editing' => 'Bewerke',
'rows' => 'Räen:',
'columns' => 'Spleder:',
'searchresultshead' => 'Schük',
'resultsperpage' => 'So fölsis komt det föör per sidj:',
'stub-threshold' => 'Formatiarang faan links <a href="#" class="stub">för letj sidjen</a> (uun Byte):',
'stub-threshold-disabled' => 'Ufsteld',
'recentchangesdays' => 'Soföl daar skel a „leetst feranrangen“ uunwise:',
'recentchangesdays-max' => 'Ei muar üs {{PLURAL:$1|ään dai|$1 daar}}',
'recentchangescount' => 'Soföl feranrangen skel uunwiset wurd:',
'prefs-help-recentchangescount' => 'Det san a leetst feranrangen, werjuunen an logbuken.',
'prefs-help-watchlist-token2' => "Detdiar as di hiamelk kai för't webfeed mä sidjen, diar dü uun't uug behual wel.
Mä didiar kai koon arken jodiar sidjen beluke, diaram skulst dü ham ei widjerdu.
[[Special:ResetTokens|Trak diar]], wan dü ham turagsaat wel.",
'savedprefs' => 'Din iinstelangen san seekert wurden.',
'timezonelegend' => 'Tidjsoon:',
'localtime' => 'Lokaal tidj:',
'timezoneuseserverdefault' => 'Wiki standard tidj brük ($1)',
'timezoneuseoffset' => 'Öödern (ferskeel uundu)',
'timezoneoffset' => 'Ferskeel¹:',
'servertime' => 'Server klooktidj:',
'guesstimezone' => 'Faan a browser auernem',
'timezoneregion-africa' => 'Afrikaa',
'timezoneregion-america' => 'Ameerikaa',
'timezoneregion-antarctica' => 'Antarktikaa',
'timezoneregion-arctic' => 'Arktis',
'timezoneregion-asia' => 'Aasien',
'timezoneregion-atlantic' => 'Atlantik',
'timezoneregion-australia' => 'Austraalien',
'timezoneregion-europe' => 'Euroopa',
'timezoneregion-indian' => 'Indik',
'timezoneregion-pacific' => 'Pasiifik',
'allowemail' => 'E-mail faan ööder brükern tuläät',
'prefs-searchoptions' => 'Schük',
'prefs-namespaces' => 'Nöömrümer',
'defaultns' => 'Ööders schük uun jodiar nöömrümer:',
'default' => 'Fööriinstelang',
'prefs-files' => 'Datein',
'prefs-custom-css' => 'Salew maaget CSS',
'prefs-custom-js' => 'Salew maaget JavaScript',
'prefs-common-css-js' => 'CSS / JavaScript för arke skak:',
'prefs-reset-intro' => 'Üüb detdiar sidj könst dü weder a normool iinstelangen iinracht.
Do san jo ual iinstelangen wech.',
'prefs-emailconfirm-label' => 'E-Mail gudkäänd:',
'youremail' => 'E-mail:',
'username' => '{{GENDER:$1|Brükernööm}}:',
'uid' => '{{GENDER:$1|Brükerkäänang}}:',
'prefs-memberingroups' => '{{GENDER:$2|Lasmoot}} faan {{PLURAL:$1|brükerskööl|brükersköölen}}:',
'prefs-registration' => 'Uunmelde-tidj',
'yourrealname' => 'Rocht nööm:',
'yourlanguage' => 'Spriak:',
'yourvariant' => 'Spriak:',
'prefs-help-variant' => 'Uun hün skriiwwiis skel a sidjen uunwiset wurd:',
'yournick' => 'Nei signatuur:',
'prefs-help-signature' => 'Wees so gud an onerskriiw üüb diskusjuunssidjen mä „<nowiki>~~~~</nowiki>“. Diar komt do dan brükernööm an det klooktidj bi ütj.',
'badsig' => "Diar stemet wat ei mä't signatuur. Preewe at HTML.",
'badsiglength' => 'Din signatuur mut ei muar üs $1 {{PLURAL:$1|tiaken|tiakens}} haa.',
'yourgender' => 'Hü wel dü betiakent wurd?',
'gender-unknown' => 'Wal ik ei sai',
'gender-male' => 'Hi bewerket wiki-sidjen',
'gender-female' => 'Hat bewerket wiki-sidjen',
'prefs-help-gender' => 'Stäänt tu wool.
Det software werket diarmä, am di salew an jinauer öödern rocht uuntuspreegen.
Arken koon det lees.',
'email' => 'E-mail',
'prefs-help-realname' => 'Stäänt tu wool. Wan dü dan rochten nööm uundääst, koon hi mä din feranrangen ferbünjen wurd.',
'prefs-help-email' => 'Dü säärst din e-mail-adres ei uundu, oober do könst dü uk nian mädialangen fu, wan dü ans din paaswurd ferjiden heest.',
'prefs-help-email-others' => 'Mä ööder brükern könst dü uk auer hör an din brükersidj kontakt apnem. Diarför woort din e-mail-adres ei brükt.',
'prefs-help-email-required' => 'Du en rocht E-Mail-adres uun.',
'prefs-info' => 'Baasisdooten',
'prefs-i18n' => 'Spriak',
'prefs-signature' => 'Signatuur',
'prefs-dateformat' => "Formaat faan't dootem",
'prefs-timeoffset' => 'Ferskeel faan a klooktidj',
'prefs-advancedediting' => 'Algemian',
'prefs-editor' => 'Skriiwer',
'prefs-preview' => 'Föörskau',
'prefs-advancedrc' => 'Ütjwidjet mögelkhaiden',
'prefs-advancedrendering' => 'Ütjwidjet mögelkhaiden',
'prefs-advancedsearchoptions' => 'Ütjwidjet mögelkhaiden',
'prefs-advancedwatchlist' => 'Ütjwidjet mögelkhaiden',
'prefs-displayrc' => "Mögelkhaiden för't uunwisin",
'prefs-displaysearchoptions' => "Mögelkhaiden för't uunwisin",
'prefs-displaywatchlist' => "Mögelkhaiden för't uunwisin",
'prefs-tokenwatchlist' => 'Token',
'prefs-diffs' => 'Ferskeel',
'prefs-help-prefershttps' => 'Detdiar iinstelang täält, wan dü di naist tooch uunmeldest.',

# User preference: email validation using jQuery
'email-address-validity-valid' => 'Detdiar E-Mail-adres schocht gud ütj.',
'email-address-validity-invalid' => 'Du en echt E-Mail-adres uun.',

# User rights
'userrights' => 'Brükerrochten bewerke',
'userrights-lookup-user' => 'Brükersköölen bewerke',
'userrights-user-editname' => 'Brükernööm:',
'editusergroup' => 'Brükersköölen bewerke',
'editinguser' => "Brükerrochten faan '''[[User:$1|$1]]''' $2 feranre",
'userrights-editusergroup' => 'Lasmootskap tu brükersköölen bewerke',
'saveusergroups' => 'Brükersköölen seekre',
'userrights-groupsmember' => 'Lasmoot faan:',
'userrights-groupsmember-auto' => 'Faan salew lasmoot faan:',
'userrights-groups-help' => 'Dü könst feranre, tu hün brükerskööl di brüker hiirt:
* En uunkrüsagt kasche ment, di brüker hiirt diartu.
* En ei uunkrüsagt kasche ment, di brüker hiart ei diartu.
* En * ment, dat dü det brükerrocht ei weder wechnem könst (of amkiard).',
'userrights-reason' => 'Grünj:',
'userrights-no-interwiki' => 'Dü heest ei det rocht, am brükerrochten uun ööder wikis tu feranrin.',
'userrights-nodatabase' => 'Det dootenbeenk $1 jaft at ei, tumanst ei lokaal.',
'userrights-nologin' => 'Dü mutst di mä en administraator-brükerkonto [[Special:UserLogin|uunmelde]], wan dü brükerrochten feranre wel.',
'userrights-notallowed' => 'Dü heest ei det rocht, am brükerrochten tu feranrin.',
'userrights-changeable-col' => 'Lasmootskapen, diar dü feranre könst',
'userrights-unchangeable-col' => 'Lasmootskapen, diar dü ei feranre könst',
'userrights-conflict' => "Konflikt bi't feranrin faan brükerrochten! Du din feranrangen noch ans iin.",
'userrights-removed-self' => 'Dü heest din aanj brükerrochtem stregen. Dü könst nü ei muar üüb det sidj tugrip.',

# Groups
'group' => 'Skööl:',
'group-user' => 'Brükern',
'group-autoconfirmed' => 'Registriaret brükern',
'group-bot' => 'Bots',
'group-sysop' => 'Administratooren',
'group-bureaucrat' => 'Bürokraaten',
'group-suppress' => 'Oversighter',
'group-all' => '(Aaltumaal)',

'group-user-member' => '{{GENDER:$1|Brüker}}',
'group-autoconfirmed-member' => '{{GENDER:$1|Registriaret brüker}}',
'group-bot-member' => '{{GENDER:$1|Bot}}',
'group-sysop-member' => '{{GENDER:$1|Administraator}}',
'group-bureaucrat-member' => '{{GENDER:$1|Bürokraat}}',
'group-suppress-member' => '{{GENDER:$1|Oversighter}}',

'grouppage-user' => '{{ns:project}}:Brükern',
'grouppage-autoconfirmed' => '{{ns:project}}:Registriaret brükern',
'grouppage-bot' => '{{ns:project}}:Bots',
'grouppage-sysop' => '{{ns:project}}:Administratooren',
'grouppage-bureaucrat' => '{{ns:project}}:Bürokraaten',
'grouppage-suppress' => '{{ns:project}}:Oversighter',

# Rights
'right-read' => 'Sidjen lees',
'right-edit' => 'Sidjen bewerke',
'right-createpage' => 'Sidjen maage (saner diskusjuunssidjen)',
'right-createtalk' => 'Diskusjuunssidjen maage',
'right-createaccount' => 'Brükerkonto iinracht',
'right-minoredit' => 'Feranrangen üs letj kääntiakne',
'right-move' => 'Sidjen fersküüw',
'right-move-subpages' => 'Sidjen mä onersidjen fersküüw',
'right-move-rootuserpages' => 'Hood-brükersidj fersküüw',
'right-movefile' => 'Datein fersküüw',
'right-suppressredirect' => "Bi't fersküüwen nian widjerfeerang iinracht",
'right-upload' => 'Datein huuchschüür',
'right-reupload' => 'Datein auerskriiw',
'right-reupload-own' => 'En datei auerskriiw, diar dü salew huuchschüürd heest',
'right-reupload-shared' => 'En datei auerskriiw, diar uun en gemiansoom archiif leit',
'right-upload_by_url' => 'Datein faan en URL-adres huuchschüür',
'right-purge' => 'Sidjen-cache leesag maage saner efterfraagin',
'right-autoconfirmed' => 'Ei troch IP-limits beskäären',
'right-bot' => 'Automatisiaret bewerke',
'right-nominornewtalk' => 'Letj feranrangen üüb diskusjuunssidjen wurd ei üs „nei noorachten“ uunwiset.',
'right-apihighlimits' => 'Huuger taalen für API-uunfraagen brük',
'right-writeapi' => 'Write-API brük',
'right-delete' => 'Sidjen strik',
'right-bigdelete' => 'Sidjen mä föl werjuunen strik',
'right-deletelogentry' => 'Enkelt werjuunen faan en logbuk-iindrach strik of turaghaale',
'right-deleterevision' => 'Enkelt werjuunen faan en sidj strik of turaghaale',
'right-deletedhistory' => 'Stregen iindracher uun a ferluup uunluke, saner di tekst, di diartu hiart',
'right-deletedtext' => 'Stregen tekst an feranrangen tesken stregen werjuunen uunluke',
'right-browsearchive' => 'Schük stregen sidjen',
'right-undelete' => 'Stregen sidjen turaghaale',
'right-suppressrevision' => 'Werjuunen uunluke an turaghaale, diar uk för administratooren ei tu sen san',
'right-suppressionlog' => 'Priwoot logbuken uunluke',
'right-block' => "Brükern spere (för't skriiwen)",
'right-blockemail' => "Brüker spere för't e-mail schüüren",
'right-hideuser' => 'Brükernööm spere an fersteeg',
'right-ipblock-exempt' => 'Ütjnoom faan IP-speren, automaatisk speren an range-speren',
'right-proxyunbannable' => 'Ütjnoom faan automaatisk proxy-speren',
'right-unblockself' => 'Sper apheew för ään salew',
'right-protect' => 'Sidjenseekerhaid feranre an kaskaaden-seekert sidjen bewerke',
'right-editprotected' => 'Sidjen bewerke, diar mä „{{int:protect-level-sysop}}“ seekert san.',
'right-editsemiprotected' => 'Sidjen bewerke, diar mä „{{int:protect-level-autoconfirmed}}“ seekert san.',
'right-editinterface' => 'Brüker-skak bewerke',
'right-editusercssjs' => 'CSS- an JavaScript-datein faan ööder brükern bewerke',
'right-editusercss' => 'CSS-datein faan ööder brükern bewerke',
'right-edituserjs' => 'JavaScript-datein faan ööder brükern bewerke',
'right-editmyusercss' => 'Aanj CSS-datein bewerke',
'right-editmyuserjs' => 'Aanj JavaScript-datein bewerke',
'right-viewmywatchlist' => "Sidjen uunluke, diar ik uun't uug behual wal",
'right-editmywatchlist' => "Sidjen bewerke, diar dü uun't uug behual wel. Enkelt aktjuunen kön diar wat saner din dun feranre.",
'right-viewmyprivateinfo' => 'Aanj priwoot dooten uunluke (t.b. e-mail-adres, rocht nööm)',
'right-editmyprivateinfo' => 'Aanj priwoot dooten bewerke (t.b. e-mail-adres, rocht nööm)',
'right-editmyoptions' => 'Aanj iinstelangen bewerke',
'right-rollback' => 'Feranrangen faan di leetst brüker gau turagsaat',
'right-markbotedits' => 'Gau turagsaatangen üs bot-iindracher kääntiakne',
'right-noratelimit' => 'Ei troch limits beskäären',
'right-import' => 'Bilen faan ööder Wikis importiare',
'right-importupload' => 'Sidjen auer det huuchschüüren faan datein importiare',
'right-patrol' => 'Werk faan ööder brükern üs kontroliaret kääntiakne',
'right-autopatrol' => 'Aanj werk aleewen üs kontroliaret kääntiakne',
'right-patrolmarks' => 'Kontrolkääntiaken uun a leetst feranrangen uunwise',
'right-unwatchedpages' => 'List faan sidjen uunluke, diar näämen üüb aachtet',
'right-mergehistory' => 'Ferluup faan sidjen tuupfeer',
'right-userrights' => 'Brükerrochten bewerke',
'right-userrights-interwiki' => 'Brükerrochten uun ööder Wikis bewerke',
'right-siteadmin' => 'Dootenbeenk spere an eebenmaage',
'right-override-export-depth' => 'Sidjen an onersidjen bit tu en jipde faan 5 eksportiare',
'right-sendemail' => 'E-mails tu ööder brükern schüür',
'right-passwordreset' => 'Paaswurd faan en brüker turagsaat an det e-mail diartu uunluke',

# Special:Log/newusers
'newuserlogpage' => 'Neiuunmeldangs-logbuk',
'newuserlogpagetext' => 'Detheer as en logbuk faan nei iinracht brükerkonten.',

# User rights log
'rightslog' => 'Brükerrochten-logbuk',
'rightslogtext' => 'Det as det logbuk auer feranrangen faan brükerrochten.',

# Associated actions - in the sentence "You do not have permission to X"
'action-read' => 'jüdeer sid leese',
'action-edit' => 'detdiar sidj tu bewerkin',
'action-createpage' => 'nei sidjen tu maagin',
'action-createtalk' => 'diskusjuunssidjen maage',
'action-createaccount' => 'jüdeer brükerkonto mååge',
'action-minoredit' => 'detdiar feranrang üs letj kääntiakne',
'action-move' => 'jüdeer sid ferschüwe',
'action-move-subpages' => 'jüdeer sid än unerside ferschüwe',
'action-move-rootuserpages' => 'hood-brükersidj fersküüw',
'action-movefile' => 'jüdeer sid ferschüwe',
'action-upload' => 'Datein huuchschüür',
'action-reupload' => 'det datei auerskriiw',
'action-reupload-shared' => 'det datei auerskriiw, diar uun en gemiansoom archiif leit',
'action-upload_by_url' => 'detdiar datei faan en URL-adres huuchtusjüüren',
'action-writeapi' => 'iin uun det API tu skriiwen',
'action-delete' => 'detdiar sidj strik',
'action-deleterevision' => 'werjuunen tu striken',
'action-deletedhistory' => 'det list mä stregen werjuunen uuntulukin',
'action-browsearchive' => 'schük stregen sidjen',
'action-undelete' => 'detdiar sidj weder iinstel',
'action-suppressrevision' => 'det ferbürgen werjuun uuntulukin an weder turagtuhaalin',
'action-suppressionlog' => 'iin uun det priwoot logbuk tu lukin',
'action-block' => 'di brüker tu sperin',
'action-protect' => 'det seekerhaid faan sidjen tu feranrin',
'action-rollback' => 'feranrangen faan di leetst brüker gau turagtusaaten',
'action-import' => 'sidjen faan en ööder Wiki tu importiarin',
'action-importupload' => 'sidjen auer det huuchschüüren faan datein tu importiarin',
'action-patrol' => 'det werk faan ööder brükern üs kontroliaret tu kääntiaknin',
'action-autopatrol' => 'aanj feranrangen üs kontroliaret tu kääntiaknin',
'action-unwatchedpages' => 'det list faan sidjen uuntulukin, diar näämen üüb aachtet',
'action-mergehistory' => 'werjuunshistoorin faan sidjen tuuptufeeren',
'action-userrights' => 'brükerrochten tu bewerkin',
'action-userrights-interwiki' => 'brükerrochten uun ööder Wikis tu bewerkin',
'action-siteadmin' => 'det dootenbeenk tu sperin an eebentumaagin',
'action-sendemail' => 'e-mails tu schüüren',
'action-editmywatchlist' => "sidjen, diar dü uun't uug behual wel, tu bewerkin",
'action-viewmywatchlist' => "sidjen uuntulukin, diar dü uun't uug behual wel",
'action-viewmyprivateinfo' => 'din priwoot dooten uuntulukin',
'action-editmyprivateinfo' => 'din priwoot dooten tu bewerkin',

# Recent changes
'nchanges' => '$1 {{PLURAL:$1|feranrang|feranrangen}}',
'enhancedrc-since-last-visit' => '$1 {{PLURAL:$1|sant dan leetst beschük}}',
'enhancedrc-history' => 'Ferluup',
'recentchanges' => 'Leetst feranrangen',
'recentchanges-legend' => "Iinstelangen för't uunwisin",
'recentchanges-summary' => "Üüb detdiar sidj könst dü a leetst feranrangen faan't Nordfriisk Wikipedia ferfulge.",
'recentchanges-noresult' => 'Uun di uunjiwen tidjrüm san sok feranrangen ei föörnimen wurden.',
'recentchanges-feed-description' => "Mä didiar feed könst dü a leetst feranrangen faan't Nordfriisk Wikipedia ferfulge.",
'recentchanges-label-newpage' => 'Nei sidj uunlaanj',
'recentchanges-label-minor' => 'Letj feranrang',
'recentchanges-label-bot' => 'Feranrang faan en bot',
'recentchanges-label-unpatrolled' => 'Detdiar feranrang as noch ei efterluket wurden',
'rcnote' => "Diar {{PLURAL:$1|stäänt det leetst feranrang|stun a leetst '''$1''' feranrangen}} faan a leetst {{PLURAL:$2|dai|'''$2''' daar}}. Stant: $4, am a klook $5.",
'rcnotefrom' => "Diar wurd a feranrangen sant '''$2'''uunwiset (ei muar üs '''$1''' feranrangen).",
'rclistfrom' => 'Bluas feranrangen sant $1 wise.',
'rcshowhideminor' => '$1 letj feranrangen',
'rcshowhidebots' => '$1 bots',
'rcshowhideliu' => '$1 uunmeldet brükern',
'rcshowhideanons' => '$1 anonüüm brükern',
'rcshowhidepatr' => '$1 efterluket feranrangen',
'rcshowhidemine' => '$1 min bidracher',
'rclinks' => 'Wise a leetst $1 feranrangen faan a leetst $2 daar.<br />$3',
'diff' => 'ferskeel',
'hist' => 'werjuunen',
'hide' => 'Fersteeg',
'show' => 'Wise',
'minoreditletter' => 'L',
'newpageletter' => 'N',
'boteditletter' => 'B',
'number_of_watching_users_pageview' => '[$1 {{PLURAL:$1|brüker|brükern}}, diar tuluke]',
'rc_categories' => 'Bluas sidjen ütj jo kategoriin (apdiald mä „|“):',
'rc_categories_any' => 'Arke',
'rc-change-size-new' => "$1 {{PLURAL:$1|byte|bytes}} efter't feranrin",
'newsectionsummary' => 'Nei kirew /* $1 */',
'rc-enhanced-expand' => 'Enkelthaiden wise',
'rc-enhanced-hide' => 'Enkelthaiden fersteeg',
'rc-old-title' => 'tuiarst maaget üs „$1“',

# Recent changes linked
'recentchangeslinked' => 'Feranrangen bi ferlinket sidjen',
'recentchangeslinked-feed' => 'Feranrangen bi ferlinket sidjen',
'recentchangeslinked-toolbox' => 'Feranrangen bi ferlinket sidjen',
'recentchangeslinked-title' => 'Feranrangen bi sidjen, huar faan "$1" üüb ferwiset woort',
'recentchangeslinked-summary' => "Detdiar spezial-sidj wiset a leetst feranrangen faan ferwiset sidjen (of faan sidjen uun en was kategorii). Sidjen, diar dü [[Special:Watchlist|uun't uug behual]] wel, san '''fäät''' skrewen.",
'recentchangeslinked-page' => 'Sidjennööm:',
'recentchangeslinked-to' => 'Wise feranrangen üüb sidjen, diar heerhen ferwise.',

# Upload
'upload' => 'Datei huuchschüür',
'uploadbtn' => 'Datei huuchsjüür',
'reuploaddesc' => "Ufbreeg an turag tu't sidj för't huuchschüüren",
'upload-tryagain' => 'Feranert dateibeskriiwang ufsjüür',
'uploadnologin' => 'Ei uunmeldet',
'uploadnologintext' => 'Dü skel di $1, amdat dü datein huuchschüür könst.',
'upload_directory_missing' => 'Det archiif-fertiaknis ($1) as ei diar, an küd faan di webserver uk ei iinracht wurd.',
'upload_directory_read_only' => 'Uun det archiif-fertiaknis ($1) küd faan di webserver ei skrewen wurd.',
'uploaderror' => "Bi't huuchschüüren as wat skiaf gingen",
'upload-recreate-warning' => "'''Paase üüb: En datei mä didiar nööm as al ans stregen of fersköwen wurden.'''

Wat nü komt, as ütj det logbuk för't striken an fersküüwen faan detdiar datei.",
'uploadtext' => "Brük detdiar formulaar, am nei datein huuchtuschüüren.

Gung tu det [[Special:FileList|list faan huuchschüürd datein]], am datein tu schüken of uuntuwisin. Luke uk iin uun't logbuk för't [[Special:Log/upload|huuchschüüren]] of [[Special:Log/delete|striken]] faan datein.

Am en '''bil''' uun en artiikel tu brüken, brük en link faan det furem:
* '''<code><nowiki>[[</nowiki>{{ns:file}}<nowiki>:Datei.jpg]]</nowiki></code>''' – för en grat bil
* '''<code><nowiki>[[</nowiki>{{ns:file}}<nowiki>:Datei.png|200px|thumb|left|alternatiif tekst]]</nowiki></code>''' – för en 200px briad bil uun en box, mä „alternatiif tekst“ üs beskriiwang faan det bil
*'''<code><nowiki>[[</nowiki>{{ns:media}}<nowiki>:Datei.ogg]]</nowiki></code>''' – för en direkt ferwisang üüb det datei, saner det datei uuntuwisin",
'upload-permitted' => 'Tuläät slacher faan datein: $1.',
'upload-preferred' => 'Slacher faan datein, diar dü brük skulst: $1.',
'upload-prohibited' => 'Ei tuläät slacher faan datein: $1.',
'uploadlog' => 'datei logbuk',
'uploadlogpage' => 'Datei-logbuk',
'uploadlogpagetext' => 'Detheer as det logbuk för huuchschüürd datein. Dü könst uk det [[Special:NewFiles|galerii faan nei datein]] uunluke.',
'filename' => 'Dateinööm',
'filedesc' => 'Beskriiwang',
'fileuploadsummary' => 'Beskriiwang',
'filereuploadsummary' => 'Feranrangen faan det datei:',
'filestatus' => 'Copyright-Status:',
'filesource' => 'Kwel',
'uploadedfiles' => 'Huuchschüürd datein',
'ignorewarning' => 'Ei üüb wäärnangen aachte an det datei seekre',
'ignorewarnings' => 'Ei am wäärnangen komre',
'minlength1' => 'Dateinöömer skel tumanst ään buksteew lung wees.',
'illegalfilename' => 'Uun di dateinööm „$1“ stäänt tumanst ian tiaken, wat dü ei brük mutst. Wees so gud an du det datei en öödern nööm.',
'filename-toolong' => 'Dateinöömer mut ei linger üs 240 bytes wees.',
'badfilename' => 'Det datei hää en neien nööm füngen an het nü „$1“.',
'filetype-mime-mismatch' => 'Det dateiaanj „.$1“ paaset ei tu di MIME-Typ ($2).',
'filetype-badmime' => 'Datein faan di MIME-Typ „$1“ mut ei huuchschüürd wurd.',
'filetype-bad-ie-mime' => 'Detdiar datei koon ei huuchsjüürd wurd, auer di Internet Explorer det för en „$1“ häält, an di slach as ei tuläät, auer hi gefeerelk wees küd.',
'filetype-unwanted-type' => "'''„.$1“''' as üs dateiformaat ei tuläät. Tuläät {{PLURAL:$3|as detdiar formaat|san jodiar formaaten}}: $2.",
'filetype-banned-type' => "'''„.$1“''' {{PLURAL:$4|as nään tuläät slach faan datein|san nian tuläät slacher faan datein}}.
{{PLURAL:$3|En tuläät slach as|Tuläät slacher san}} $2.",
'filetype-missing' => 'Det datei, wat dü huuchsjüür wel, hää nian aanj (t.b. „.jpg“).',
'empty-file' => 'Det datei, wat dü huuchsjüürd heest, as leesag.',
'file-too-large' => 'Det datei, wat dü huuchsjüürd heest, as tu grat.',
'filename-tooshort' => 'Di dateinööm as tu kurt.',
'filetype-banned' => 'Son slach faan datei as ei tuläät.',
'verification-error' => 'Det datei hää det seekerhaidspreew ei bestenen.',
'hookaborted' => 'Det feranrang, wat dü maage wulst, as faan en ütjwidjet software-funktjuun ufbreegen wurden.',
'illegal-filename' => 'Didiar dateinööm as ei tuläät.',
'overwrite' => 'Dü könst nian datei auerskriiw, wat al diar as.',
'unknown-error' => 'Diar as irgentwat skiaf gingen.',
'tmp-create-error' => 'Det tidjwiis datei küd ei maaget wurd.',
'tmp-write-error' => "Bi't skriiwen faan det tidjwiis datei as wat skiaf gingen.",
'large-file' => 'Datein skul ei grater wees üs $1, wan mögelk. Detdiar datei as $2 grat.',
'largefileserver' => 'Detdiar datei as grater, üs di server üüb iinsteld as.',
'emptyfile' => 'Det datei, wat dü huuchsjüürd heest, as leesag. Ferlicht heest dü di ferskrewen. Luke noch ans, of dü würelk detdiar datei huuchsjüür wel.',
'windows-nonascii-filename' => 'Detheer Wiki läät nian dateinöömer mä sondertiaken tu.',
'fileexists' => 'En datei mä didiar nööm jaft at al. Luke noch ans efter <strong>[[:$1]]</strong>, wan dü ei gans seeker beest, of dü det anre wel.
[[$1|thumb]]',
'filepageexists' => "En beskriiwangssidj för <strong>[[:$1]]</strong> as al diar, oober nian datei. Din beskriiwang woort ei apnimen. Det beskriiwangssidj mut do man efter't huuchschüüren noch ans efterluket wurd.
[[$1|thumb]]",
'fileexists-extension' => 'Diar as al en datei mä di nööm: [[$2|thumb]]
* Nööm faan det nei datei: <strong>[[:$1]]</strong>
* Nööm faan det ual datei: <strong>[[:$2]]</strong>
Wees so gud an nem en öödern nööm.',
'fileexists-thumbnail-yes' => "Detdiar datei as was en letjer maaget bil ''(thumbnail)''. [[$1|thumb]]
Luke di det datei <strong>[[:$1]]</strong> noch ans uun.
Wan det det originaal bil as, säärst dü nään letjer maaget bil huuchsjüür.",
'file-thumbnail-no' => "Di dateinööm begant mä <strong>$1</strong>. Det as was en letjer maaget bil ''(thumbnail)''.
Luke noch ans efter, of dü det bil uun fol grate diar heest, an do schüür det huuch.",
'fileexists-forbidden' => 'En datei mä didiar nööm jaft at al an koon ei auerskrewen wurd.
Gung noch ans turag an schüür det datei mä en öödern nööm huuch.
[[File:$1|thumb|center|$1]]',
'fileexists-shared-forbidden' => "En datei mä didiar nööm stäänt al uun't gemiansoom archiif. Wan dü det bil likes huuchsjüür wel, gung turag nem en öödern nööm.
[[File:$1|thumb|center|$1]]",
'file-exists-duplicate' => 'Detdiar datei as en duplikaat faan {{PLURAL:$1|detdiar datei|$1 datein}}:',
'file-deleted-duplicate' => "En duplikaat faan detdiar datei ([[:$1]]) as al ans stregen wurden. Luke iin uun logbuk för't striken, iar dü det noch ans huuchsjüürst.",
'uploadwarning' => 'Wäärnang',
'uploadwarning-text' => 'Feranre det datei-beskriiwang an fersjük det noch ans nei.',
'savefile' => 'Datei seekre',
'uploadedimage' => 'hää "[[$1]]" huuchschüürd',
'overwroteimage' => 'hää en nei werjuun faan „[[$1]]“ huuchsjüürd',
'uploaddisabled' => 'Huuchschüüren as ei aktiwiaret',
'copyuploaddisabled' => 'Huuchschüüren faan URLs as ei aktiwiaret.',
'uploadfromurl-queued' => 'Din huuchsjüürd datei teewt.',
'uploaddisabledtext' => 'Det huuchschüüren faan datein as ei aktiwiaret.',
'php-uploaddisabledtext' => 'Det huuchschüüren faan datein as uun PHP ei aktiwiaret.
Luke di det iinstelang faan <code>file_uploads</code> uun.',
'uploadscripted' => 'Uun detdiar datei stäänt HTML- of Scriptcode, an küd ütj fersen faan en browser ütjfeerd wurd.',
'uploadvirus' => 'Uun detdiar datei as en wiirus! Details: $1',
'uploadjava' => 'Detdiar as en ZIP-datei mä en CLASS-datei faan Java.
Java-datein kön ei tuläät wurd, auer jo det seekerhaid uun fraag stel küd.',
'upload-source' => 'Kweldatei',
'sourcefilename' => 'Kweldateinööm:',
'sourceurl' => 'Kwel-URL:',
'destfilename' => 'Nei dateinööm:',
'upload-maxfilesize' => 'Datei ei grater üs: $1',
'upload-description' => 'Dateibeskriiwang',
'upload-options' => "Iinstelangen för't huuchschüüren",
'watchthisupload' => 'Luke efter detdiar datei',
'filewasdeleted' => 'En datei mä didiar nööm as al ans huuchsjüürd an leederhen weder stregen wurden. Luke iarst ans iin uun $1, iar dü det datei würelk seekerst.',
'filename-bad-prefix' => "Di dateinööm begant mä '''„$1“'''. Sok nöömer kem miast faan digitaalkameras an sai ei föl ütj.
Nem en beedern nööm för det datei.",
'upload-success-subj' => 'Det huuchschüüren hää loket.',
'upload-success-msg' => 'Det huuchschüüren faan [$2] hää loket an stäänt nü diar: [[:{{ns:file}}:$1]]',
'upload-failure-subj' => "Bi't huuchschüüren as wat skiaf gingen.",
'upload-failure-msg' => "Diar as wat skiaf gingen bi't huuchschüüren faan [$2]:

$1",
'upload-warning-subj' => 'Wäärnang',
'upload-warning-msg' => "Diar as wat skiaf gingen bi't huuchschüüren faan [$2]. Gung turag tu't  [[Special:Upload/stash/$1|sidj för't huuchschüüren]], am det üüb a rä tu fun.",

'upload-proto-error' => 'Ferkiard protokol',
'upload-proto-error-text' => 'Det URL skal mä <code>http://</code> of <code>ftp://</code> began.',
'upload-file-error' => 'Diar as wat skiaf gingen',
'upload-file-error-text' => "Bi't maagin faan det tidjwiis datei as wat skiaf gingen. Wees so gud an skriiw det tu en [[Special:ListUsers/sysop|administraator]].",
'upload-misc-error' => "Bi't huuchschüüren as wat skiaf gingen.",
'upload-misc-error-text' => "Bi't huuchschüüren as wat skiaf gingen. Luke di det URL noch ans uun, an of det sidj uk würelk diar as.
Wan det goorei wal, do skriiw tu en [[Special:ListUsers/sysop|administraator]].",
'upload-too-many-redirects' => 'Det URL hää tuföl widjerfeerangen.',
'upload-unknown-size' => 'Ünbekäänd grate',
'upload-http-error' => 'Diar as en HTTP-feeler mä: $1',
'upload-copy-upload-invalid-domain' => 'Kopiin faan datein kön faan detdiar domeen ei huuchschüürd wurd.',

# File backend
'backend-fail-stream' => 'Det datei $1 küd ei auerdraanj wurd.',
'backend-fail-backup' => 'Det datei $1 küd ei seekert wurd.',
'backend-fail-notexists' => 'Det datei $1 jaft at ei.',
'backend-fail-hashes' => 'Küd nään hash-wäärs tu fergliken finj.',
'backend-fail-notsame' => 'Diar as al en ööder datei mä di nööm $1.',
'backend-fail-invalidpath' => '$1 as nian tuläät steed tu seekrin.',
'backend-fail-delete' => 'Det datei $1 küd ei stregen wurd.',
'backend-fail-describe' => 'A metadooten för det datei „$1“ küd ei anert wurd.',
'backend-fail-alreadyexists' => 'Det sidj $1 jaft at al.',
'backend-fail-store' => 'Det datei $1 küd ei oner $2 seekert wurd.',
'backend-fail-copy' => 'Det datei $1 küd ei efter $2 kopiaret wurd.',
'backend-fail-move' => 'Det datei $1 küd ei efter $2 fersköwen wurd.',
'backend-fail-opentemp' => 'Det tidjwiis datei küd ei eeben maaget wurd.',
'backend-fail-writetemp' => 'Det tidjwiis datei küd ei skrewen wurd.',
'backend-fail-closetemp' => 'Det tidjwiis datei küd ei sacht maaget wurd.',
'backend-fail-read' => 'Det datei $1 küd ei leesen wurd.',
'backend-fail-create' => 'Det datei $1 küd ei seekert wurd.',
'backend-fail-maxsize' => 'Det datei $1 küd ei seekert wurd, auer det grater üs {{PLURAL:$2|1 byte|$2 bytes}} as.',
'backend-fail-readonly' => 'Det süsteem „$1“ koon uun uugenblak bluas lees. Di grünj as: „$2“',
'backend-fail-synced' => "Det datei „$1“ woort jüst faan't süsteem bewerket.",
'backend-fail-connect' => "Küd ei mä't süsteem „$1“ ferbinj.",
'backend-fail-internal' => "Uun't süsteem „$1“ as wat skiaf gingen.",
'backend-fail-contenttype' => "Di slach faan det datei uun't steed „$1“ küd ei bestemet wurd.",
'backend-fail-batchsize' => "En batch uun't süsteem koon ei {{PLURAL:$1|1 apgoow|$1 apgoowen}} bewerke. Det mut ei muar üs {{PLURAL:$2|1 apgoow|$2 apgowen}} tu tidj wees.",
'backend-fail-usable' => 'Det datei „$1“ küd ei ufrepen of seekert wurd, auer diar eder det fertiaknis waant of a brükerrochten ei ling.',

# File journal errors
'filejournal-fail-dbconnect' => "Küd ei ferbinj mä't jurnaal-dootenbeenk uun't süsteem „$1“.",
'filejournal-fail-dbquery' => "Det jurnaal-dootenbeenk faan't süsteem „$1“ küd ei aktualisiaret wurd.",

# Lock manager
'lockmanager-notlocked' => 'Küd det sper faan „$1“ ei apliase, auer diar goor nian sper wiar.',
'lockmanager-fail-closelock' => 'Det sperdatei för „$1“ küd ei slööden wurd.',
'lockmanager-fail-deletelock' => 'Det sperdatei för „$1“ küd ei stregen wurd.',
'lockmanager-fail-acquirelock' => 'Det sper för „$1“ küd ei ufrepen  wurd.',
'lockmanager-fail-openlock' => 'Det sperdatei för „$1“ küd ei eeben maaget wurd.',
'lockmanager-fail-releaselock' => 'Det sper för „$1“ küd ei apliaset wurd.',
'lockmanager-fail-db-bucket' => 'Mä $1 küd ei nooch ferbinjangen tu sperdootenbeenken iinracht wurd.',
'lockmanager-fail-db-release' => "A speren uun't dootenbeenk $1 küd ei apliaset wurd.",
'lockmanager-fail-svr-acquire' => 'A speren üüb server $1 küd ei ufrepen wurd.',
'lockmanager-fail-svr-release' => 'A speren üüb server $1 küd ei apliaset wurd.',

# ZipDirectoryReader
'zip-file-open-error' => "Diar as wat skiaf gingen bi't leesen faan det datei tu't ZIP-preew.",
'zip-wrong-format' => 'Detdiar datei as nian ZIP-datei.',
'zip-bad' => 'Det ZIP-datei as uunstaken of koon ütj irgent en öödern grünj ei leesen wurd. Diaram koon det uk ei üüb seekerhaid preewet wurd.',
'zip-unsupported' => 'Detdiar ZIP-datei as faan en slach, diar MediaWiki ei lees koon. Diaram koon det uk ei üüb seekerhaid preewet wurd.',

# Special:UploadStash
'uploadstash' => "Teskenseekerang bi't huuchschüüren",
'uploadstash-summary' => 'Üüb detdiar sidj kem datein föör, diar man jüst huuchschüürd wurden san. Bluas, hoker jo huuchschüürd hää, koon jo sä.',
'uploadstash-clear' => 'Teskenseekert datein wechnem',
'uploadstash-nofiles' => 'Diar san nian teskenseekert datein.',
'uploadstash-badtoken' => 'Teskenseekert datein küd ei wechnimen wurd. Ferlicht beest dü ei muar uunmeldet. Ferschük det man noch ans.',
'uploadstash-errclear' => 'Teskenseekert datein küd ei wechnimen wurd.',
'uploadstash-refresh' => 'List mä datein aktualisiare.',
'invalid-chunk-offset' => 'Di began as diar ei tuläät.',

# img_auth script messages
'img-auth-accessdenied' => 'Tugrip ei mögelk',
'img-auth-nopathinfo' => 'Diar as nään PATH_INFO.
Di server koon detdiar informatjuun ei widjerdu.
Ferlicht as det uun CGI iinbünjen an komt diaram uk ei mä „img_auth“ turocht.
Üüb det sidj https://www.mediawiki.org/wiki/Manual:Image_Authorization (ingelsk) stäänt diar muar auer.',
'img-auth-notindir' => 'Detdiar fertiaknis as ei föörsen tu huuchschüüren.',
'img-auth-badtitle' => 'Mä „$1“ küd nään tiitel maaget wurd.',
'img-auth-nologinnWL' => "Dü beest ei uunmeldet, an „$1“ stäänt ei uun't whitelist.",
'img-auth-nofile' => 'Diar as nään datei „$1“.',
'img-auth-isdir' => 'Dü wel üüb en fertiaknis „$1“ tugrip. Dü mutst bluas üüb datein tugrip.',
'img-auth-streaming' => '„$1“ woort iinleesen.',
'img-auth-public' => 'Mä img_auth.php wurd datein faan en priwoot Wiki ütjden.
Detheer as oober en öfentelk Wiki.
För a seekerhaid as img_auth.php ei aktiwiaret.',
'img-auth-noread' => 'Di brüker hää nian rocht, „$1“ tu leesen.',
'img-auth-bad-query-string' => 'Uun det URL san ei tuläät uffraagtiakens.',

# HTTP errors
'http-invalid-url' => 'Ei tuläät URL: $1',
'http-invalid-scheme' => 'URLs mä det münster „$1“ kön ei brükt wurd.',
'http-request-error' => "HTTP-feeler bi't uffraagin.",
'http-read-error' => "HTTP-feeler bi't leesen.",
'http-timed-out' => 'Det HTTP-uffraag hää tu loong düüret (time-out).',
'http-curl-error' => "Feeler bi't ufrepen faan det URL: $1",
'http-bad-status' => "Feeler bi't HTTP-uffraag: $1 $2",

# Some likely curl errors. More could be added from <http://curl.haxx.se/libcurl/c/libcurl-errors.html>
'upload-curl-error6' => 'URL küd ei fünjen wurd',
'upload-curl-error6-text' => 'Det URL küd ei fünjen wurd. Luke di det URL noch ans uun, an of det sidj uk würelk diar as.',
'upload-curl-error28' => 'Det huuchschüüren hää tu loong düüret (time-out).',
'upload-curl-error28-text' => 'Det sidj hää tu loong ei swaaret (time-out). Luke noch ans efter, of det sidj uk würelk diar as. Fersjük det beeder leeder noch ans weder.',

'license' => 'Lisens:',
'license-header' => 'Lisens',
'nolicense' => 'Nian ütjwool',
'license-nopreview' => '(Diar as noch niks tu sen)',
'upload_source_url' => '(en tuläät URL)',
'upload_source_file' => '(en datei üüb dan computer)',

# Special:ListFiles
'listfiles-summary' => 'Üüb detdiar spezialsidj wurd aal a huuchschüürd datein uunwiset.',
'listfiles_search_for' => 'Schük efter det datei:',
'imgfile' => 'datei',
'listfiles' => 'List faan datein',
'listfiles_thumb' => 'Letjer bil',
'listfiles_date' => 'Dootem',
'listfiles_name' => 'Nööm',
'listfiles_user' => 'Brüker',
'listfiles_size' => 'Grate',
'listfiles_description' => 'Beskriiwang',
'listfiles_count' => 'Werjuunen',
'listfiles-show-all' => 'Ual bilwerjuunen mä iinslütj',
'listfiles-latestversion' => 'Aktuel werjuun',
'listfiles-latestversion-no' => 'Naan',

# File description page
'file-anchor-link' => 'Datei',
'filehist' => 'Dateiwerjuunen',
'filehist-help' => 'Klike üüb en tidjponkt, am detdiar werjuun uuntulukin.',
'filehist-deleteall' => 'aal a werjuunen strik',
'filehist-deleteone' => 'detdiar werjuun strik',
'filehist-revert' => 'turagsaat',
'filehist-current' => 'aktuel',
'filehist-datetime' => 'Werjuun faan a',
'filehist-thumb' => 'Föörskaubil',
'filehist-thumbtext' => 'Föörskau för det werjuun faan $2, klook $3',
'filehist-nothumb' => 'Diar as nian föörskaubil',
'filehist-user' => 'Brüker',
'filehist-dimensions' => 'Miaten',
'filehist-filesize' => 'Dateigrate',
'filehist-comment' => 'Komentaar',
'filehist-missing' => 'Datei ei diar',
'imagelinks' => 'Hü det datei brükt woort',
'linkstoimage' => '{{PLURAL:$1|Detdiar sidj brükt|Jodiar $1 sidjen brük}} detdiar datei:',
'linkstoimage-more' => 'Muar üs $1 {{PLURAL:$1|sidj ferwiset|sidjen ferwise}} üüb detdiar datei.
Det list wiset {{PLURAL:$1|at iarst ferwisang|a iarst $1 ferwisangen}} üüb detdiar datei.
Dü könst uk det [[Special:WhatLinksHere/$2|hial list]] uunluke.',
'nolinkstoimage' => 'Nään artiikel brükt detheer datei',
'morelinkstoimage' => 'Dü könst [[Special:WhatLinksHere/$1|muar ferwisangen]] üüb detdiar datei uunwise läät.',
'linkstoimage-redirect' => '$1 (widjerfeerang) $2',
'duplicatesoffile' => '{{PLURAL:$1|Detdiar datei as en kopii|$1 datein san kopiin}} faan det datei ([[Special:FileDuplicateSearch/$2|muar diartu]]):',
'sharedupload' => 'Detdiar datei komt faan $1 an mut uk för ööder projekten brükt wurd.',
'sharedupload-desc-there' => 'Detdiar datei as faan $1 an koon faan ööder projekten brükt wurd.
Üüb det [$2 beskriiwangssidj] stäänt muar diartu.',
'sharedupload-desc-here' => "Detheer bil as faan $1 an koon faan ööder projekten brükt wurd. 
Det beskriiwang faan't [$2 beskriiwangssidj] woort oner uunwiset.",
'sharedupload-desc-edit' => 'Detdiar datei as faan $1 an koon faan ööder projekten brükt wurd.
Ferlicht wel dü det [$2 beskriiwangssidj] feranre.',
'sharedupload-desc-create' => 'Detdiar datei as faan $1 an koon faan ööder projekten brükt wurd.
Ferlicht wel dü det [$2 beskriiwangssidj] feranre.',
'filepage-nofile' => 'En datei mä didiar nööm jaft at ei.',
'filepage-nofile-link' => 'En datei mä didiar nööm jaft at ei, man dü könst det [$1 huuchsjüür].',
'uploadnewversion-linktext' => 'En nei werjuun faan detdiar datei huuchschüür',
'shared-repo-from' => 'foon $1',
'shared-repo' => 'en gemiansoom archiif',
'upload-disallowed-here' => 'Dü könst detdiar datei ei auerskriiw.',

# File reversion
'filerevert' => '"$1" turagsaat',
'filerevert-legend' => 'Datei turagsaat',
'filerevert-intro' => "Dü saatst det datei '''[[Media:$1|$1]]''' üüb det [$4 werjuun faan $2, klook $3] turag.",
'filerevert-comment' => 'Grünj:',
'filerevert-defaultcomment' => 'Turagsaat üüb det werjuun faan $1, klook $2',
'filerevert-submit' => 'Turagsaat',
'filerevert-success' => "'''[[Media:$1|$1]]''' as üüb det [$4 werjuun faan $3, klook $2] turagsaat wurden.",
'filerevert-badversion' => 'Diar as nään werjuun faan detdiar datei tu didiar tidjponkt.',

# File deletion
'filedelete' => 'Strik "$1"',
'filedelete-legend' => 'Strik datei',
'filedelete-intro' => "Dü strikst det datei '''„[[Media:$1|$1]]“''' an uk aal a werjuunen.",
'filedelete-intro-old' => "Dü strikst faan det datei '''[[Media:$1|$1]]''' det [$4 werjuun faan $2, klook $3].",
'filedelete-comment' => 'Grünj:',
'filedelete-submit' => 'Strik',
'filedelete-success' => "'''„$1“''' as stregen wurden.",
'filedelete-success-old' => "Faan det datei '''„[[Media:$1|$1]]“''' as det werjuun faan $2, klook $3 stregen wurden.",
'filedelete-nofile' => "'''$1''' jaft at ei.",
'filedelete-nofile-old' => "Diar as nian werjuun faan '''$1''' mä sok kääntiaken uun't archiif.",
'filedelete-otherreason' => 'Ööder/noch en grünj:',
'filedelete-reason-otherlist' => 'Ööder grünj:',
'filedelete-reason-dropdown' => "*Grünjer för't striken
** Kopiarrochten ei beaachtet
** Kopii faan en datei",
'filedelete-edit-reasonlist' => "Grünjer för't striken bewerke",
'filedelete-maintenance' => 'Det striken of turaghaalin faan datein gongt uun uugenblak ei.',
'filedelete-maintenance-title' => 'Det datei koon ei stregen wurd',

# MIME search
'mimesearch' => 'Efter MIME-Typ schük',
'mimesearch-summary' => 'Üüb detheer sidj könst dü datein efter hör MIME-Typ filtre.
Det formoot as leewen slach/onerslach üs uun det bispal: <code>image/jpeg</code>.',
'mimetype' => 'MIME-Typ:',
'download' => 'Deelloose',

# Unwatched pages
'unwatchedpages' => "Sidjen, diar näämen uun't uug hää",

# List redirects
'listredirects' => 'Widjerfeerangen',

# Unused templates
'unusedtemplates' => 'Ei iinbünjen föörlaagen',
'unusedtemplatestext' => 'Sidjen uun a {{ns:template}}-nöömrüm, diar ei uun ööder sidjen iinbünjen san.
Iar dü ian strikst, stel seeker, dat diar nian ferwisangen üüb detdetdiar föörlag saan.',
'unusedtemplateswlh' => 'Ööder ferwisangen',

# Random page
'randompage' => 'Tufelag sidj',
'randompage-nopages' => 'Diar san nian sidjen uun {{PLURAL:$2|nöömrüm|nöömrümer}}: $1.',

# Random page in category
'randomincategory' => "Tufelag sidj uun't kategorii",
'randomincategory-invalidcategory' => '"$1" as üs kategoriinööm ei tuläät.',
'randomincategory-nopages' => 'Diar san nian sidjen uun [[:Category:$1]].',
'randomincategory-selectcategory' => "Tufelag sidj uun't kategorii: $1 $2.",
'randomincategory-selectcategory-submit' => 'Widjer',

# Random redirect
'randomredirect' => 'Tufelag widjerfeerang',
'randomredirect-nopages' => 'Uun di nöömrüm „$1“ san nian widjerfeerangen.',

# Statistics
'statistics' => 'Statistik',
'statistics-header-pages' => 'Sidjenstatistik',
'statistics-header-edits' => 'Statistik faan feranrangen',
'statistics-header-views' => 'Statistik faan kliks üüb sidjen',
'statistics-header-users' => 'Brükerstatistik',
'statistics-header-hooks' => 'Ööder statistiken',
'statistics-articles' => 'Artiikler',
'statistics-pages' => 'Sidjen',
'statistics-pages-desc' => 'Aal a sidjen uun det wiki, mä diskusjuunssidjen, widjerfeerangen asw.',
'statistics-files' => 'Huuchschüürd datein',
'statistics-edits' => 'Feranrangen, sant {{SITENAME}} maaget wurden as',
'statistics-edits-average' => "Feranrangen per sidj uun't madel",
'statistics-views-total' => 'Kliks üüb det sidj',
'statistics-views-total-desc' => 'Kliks üüb sidjen, diar\'t goorei jaft of "Spezial-"sidjen wurd ei mätääld.',
'statistics-views-peredit' => 'Kliks per feranrang',
'statistics-users' => 'Registriaret [[Special:ListUsers|brükern]]',
'statistics-users-active' => 'Aktiif brükern',
'statistics-users-active-desc' => 'Brükern, diar wat bewerket haa uun a leetst {{PLURAL:$1|dai|$1 daar}}',
'statistics-mostpopular' => 'Sidjen mä a miast kliks',

'pageswithprop' => 'Sidjen mä en sidjeneegenoort',
'pageswithprop-legend' => 'Sidjen mä en sidjeneegenoort',
'pageswithprop-text' => 'Detheer Spezial-sidj feert sidjen mä was sidjeneegenoorten ap.',
'pageswithprop-prop' => 'Sidjeneegenoort:',
'pageswithprop-submit' => 'Widjer',
'pageswithprop-prophidden-long' => 'Eegenskapswäärs för lung tekster ferbürgen ($1)',
'pageswithprop-prophidden-binary' => 'Binär eegenskapswäärs ferbürgen ($1)',

'doubleredirects' => 'Dobelt widjerfeerangen',
'doubleredirectstext' => "Detheer list feert widjerfeerangen ap, diar üüb widjerfeerangen widjer feer.
Uun arke rä stun ferwisangen tu't iarst an ööder widjerfeerang an uk tu det sidj, huar det ööder widjerfeerang üüb ferwiset. <del>Trochstregen</del> iindracher san al bewerket wurden.",
'double-redirect-fixed-move' => '[[$1]] as fersköwen wurden an feert nü widjer tu [[$2]].',
'double-redirect-fixed-maintenance' => 'Dobelt widjerfeerang faan [[$1]] tu [[$2]] as apredet wurden.',
'double-redirect-fixer' => 'Bot för widjerfeerangen',

'brokenredirects' => 'Uunstaken widjerfeerangen',
'brokenredirectstext' => "Jodiar widjerfeerangen ferwise üüb en sidj, diar't goorei jaft:",
'brokenredirects-edit' => 'bewerke',
'brokenredirects-delete' => 'strik',

'withoutinterwiki' => 'Sidjen saner ferwisangen tu ööder spriaken',
'withoutinterwiki-summary' => 'Jodiar sidjen haa nian ferwisangen tu ööder spriaken.',
'withoutinterwiki-legend' => 'Prefix',
'withoutinterwiki-submit' => 'Wise',

'fewestrevisions' => 'Sidjen mä manst feranrangen',

# Miscellaneous special pages
'nbytes' => '$1 {{PLURAL:$1|byte|bytes}}',
'ncategories' => '{{PLURAL:$1|kategorii|kategoriie}}',
'ninterwikis' => '$1 {{PLURAL:$1|interwiki|interwikis}}',
'nlinks' => '$1 {{PLURAL:$1|link|links}}',
'nmembers' => '{{PLURAL:$1|1 iindrach|$1 iindracher}}',
'nrevisions' => '$1 {{PLURAL:$1|feranrang|feranrangen}}',
'nviews' => '$1 {{PLURAL:$1|klik|kliks}}',
'nimagelinks' => 'Brükt üüb $1 {{PLURAL:$1|sidj|sidjen}}',
'ntransclusions' => 'brükt üüb $1 {{PLURAL:$1|sidj|sidjen}}',
'specialpage-empty' => 'Diar san tu tidj nian iindracher.',
'lonelypages' => 'Sidjen, diar ei üüb ferwiset woort',
'lonelypagestext' => 'Jodiar sidjen san ei uun ööder sidjen iinbünjen an diar woort uun {{SITENAME}} uk ei üüb ferwiset.',
'uncategorizedpages' => 'Sidjen saner kategorii',
'uncategorizedcategories' => 'Kategoriin saner kategorii',
'uncategorizedimages' => 'Datein saner kategorii',
'uncategorizedtemplates' => 'Föörlaagen saner kategorii',
'unusedcategories' => 'Kategoriin, diar ei brükt wurd',
'unusedimages' => 'Datein, diar ei brükt wurd',
'popularpages' => 'Miats uunluket sidjen',
'wantedcategories' => 'Kategoriin, diar brükt wurd',
'wantedpages' => 'Sidjen, diar brükt wurd',
'wantedpages-badtitle' => 'Diar as en artiikelnööm ei tuläät uun: $1',
'wantedfiles' => 'Datein, diar brükt wurd',
'wantedfiletext-cat' => 'Jodiar datein wurd brükt, oober san ei diar. Datein faan ööder archiiwen wurd apfeerd, san oober <del>trochstregen</del>. An jo sidjen, diar sok datein brük, stun uun  [[:$1]].',
'wantedfiletext-nocat' => 'Jodiar datein wurd brükt, oober san ei diar. Datein faan ööder archiiwen wurd apfeerd, san oober <del>trochstregen</del>.',
'wantedtemplates' => 'Föörlaagen, diar brükt wurd',
'mostlinked' => 'Sidjen, huar a miast ööder sidjen üüb ferwise',
'mostlinkedcategories' => 'Miast brükt kategoriin',
'mostlinkedtemplates' => 'Miast brükt föörlaagen',
'mostcategories' => 'Sidjen mä a miast kategoriin',
'mostimages' => 'Datein, huar a miast sidjen üüb ferwise',
'mostinterwikis' => 'Sidjen mä a miast ferwisangen tu ööder spriaken',
'mostrevisions' => 'Sidjen mä miast feranrangen',
'prefixindex' => 'Aal a sidjen (mä prefix)',
'prefixindex-namespace' => 'Aal a sidjen mä prefix (nöömrüm $1)',
'prefixindex-strip' => 'Prefix uun det list ei uunwise',
'shortpages' => 'Kurt sidjen',
'longpages' => 'Lung sidjen',
'deadendpages' => 'Sidjen saner ferwisangen',
'deadendpagestext' => 'Jodiar sidjen ferwise ei üüb ööder sidjen uun {{SITENAME}}.',
'protectedpages' => 'Seekert sidjen',
'protectedpages-indef' => 'Bluas permanent seekert sidjen uunwise',
'protectedpages-cascade' => 'Bluas sidjen mä kaskaaden-seekerhaid',
'protectedpagestext' => 'Jodiar spezial-sidjen san jin feranrin an fersküüwen seekert.',
'protectedpagesempty' => 'Uun uugenblak san sok sidjen ei seekert.',
'protectedtitles' => 'Seekert sidjennöömer',
'protectedtitlestext' => 'Jodiar sidjennöömer kön ei brükt wurd.',
'protectedtitlesempty' => 'Uun uugenblak san sok sidjen ei speret.',
'listusers' => 'Brükerfertiaknis',
'listusers-editsonly' => 'Wise bluas aktiif brükern',
'listusers-creationsort' => 'Sortiare efter dootem',
'usereditcount' => '{{PLURAL:$1|feranrang|$1 feranrangen}}',
'usercreated' => '{{GENDER:$3|Maaget}} di $1 am a klook $2',
'newpages' => 'Nei sidjen',
'newpages-username' => 'Brükernoome:',
'ancientpages' => 'Al loong ei muar bewerket sidjen',
'move' => 'Fersküüw',
'movethispage' => 'Detdiar sidj fersküüw',
'unusedimagestext' => "Jodiar datein san uun nään artiikel iinbünjen. Det koon oober lacht wees, dat ööder wääbsidjen diarüüb ferwise. Sodenang wurd jo heer apfeerd, uk wan's huarööders brükt wurd.",
'unusedcategoriestext' => "Jodiar kategorii-sidjen san diar, likes dat's leesag san an uun uugenblak ei brükt wurd.",
'notargettitle' => 'Nian sidj uunden',
'notargettext' => 'Dü heest nian sidj uunden, huar det funktjuun werke skal.',
'nopagetitle' => 'Kwelsidj as ei diar',
'nopagetext' => 'Det sidj, wat fersköwen wurd skal, as ei diar.',
'pager-newer-n' => '{{PLURAL:$1|1 neier|$1 neier}}',
'pager-older-n' => '{{PLURAL:$1|1 ääler|$1 ääler}}',
'suppress' => 'Oversight',
'querypage-disabled' => 'Detdiar spezial-sidj as ei aktiif, am det süsteem ei tu auerläästin.',

# Book sources
'booksources' => 'Schük efter ISBN-numer',
'booksources-search-legend' => 'Schük efter bukloodens',
'booksources-go' => 'Widjer',
'booksources-text' => 'Detdiar list ferwiset üüb wääbsteeden, diar nei an brükt buken ferkuupe. Diar feist dü uk muar tu weden. {{SITENAME}} hää mo jodiar kuuplidj oober niks tu dun.',
'booksources-invalid-isbn' => 'Detdiar ISBN as woorskiinelk ferkiard. Luke noch ans efter, of det rocht auerdraanj wurden as.',

# Special:Log
'specialloguserlabel' => 'Brüker:',
'speciallogtitlelabel' => 'Mual (sidjennööm of brüker):',
'log' => 'Logbuken',
'all-logs-page' => 'Aal a öfentelk logbuken',
'alllogstext' => 'Diar wurd aal a logbuken faan {{SITENAME}} uunwiset.
Det woort efter logbukslach, brüker of sidjennööm uunwiset. Grat- an letjskriiwang skel beaachtet wurd.',
'logempty' => 'Diar as niks uun.',
'log-title-wildcard' => 'Sidjennööm begant mä ...',
'showhideselectedlogentries' => 'Wise/fersteeg jodiar logbukiindracher',

# Special:AllPages
'allpages' => 'Aal a sidjen',
'alphaindexline' => '$1 bit $2',
'nextpage' => 'Naist sidj ($1)',
'prevpage' => 'Leetst sidj ($1)',
'allpagesfrom' => 'Sidjen wise sant:',
'allpagesto' => 'Sidjen wise bit:',
'allarticles' => 'Aal a sidjen',
'allinnamespace' => 'Aal a sidjen (nöömrüm: $1)',
'allnotinnamespace' => 'Aal a sidjen (saner nöömrüm $1)',
'allpagesprev' => 'Leest',
'allpagesnext' => 'Naist',
'allpagessubmit' => 'Widjer',
'allpagesprefix' => 'Sidjen uunwise mä prefix:',
'allpagesbadtitle' => 'Didiar sidjennööm gongt ei. Hi hed ferlicht en spriak-prefix of diar san ei tuläät tiakens uun.',
'allpages-bad-ns' => 'Di nöömrüm „$1“ komt uun {{SITENAME}} ei föör.',
'allpages-hide-redirects' => 'Widjerfeerangen fersteeg',

# SpecialCachedPage
'cachedspecial-viewing-cached-ttl' => 'Dü lukest en werjuun uun a cache uun. Det koon al $1 ual wees.',
'cachedspecial-viewing-cached-ts' => 'Dü lukest en werjuun uun a cache uun. Det as ferlicht ei üüb a leetst stant.',
'cachedspecial-refresh-now' => 'Neist werjuun uunluke.',

# Special:Categories
'categories' => 'Kategoriin',
'categoriespagetext' => '{{PLURAL:$1|Detdiar kategorii häält|Jodiar kategoriin hual}} sidjen of datein.
[[Special:UnusedCategories|Leesag kategoriin]] wurd heer ei uunwiset.
Luke uk bi det list faan [[Special:WantedCategories|nuadag kategoriin]].',
'categoriesfrom' => 'Wise kategoriin mä began üüb:',
'special-categories-sort-count' => 'Efter taalen sortiaret',
'special-categories-sort-abc' => "Efter't alfabeet sortiaret",

# Special:DeletedContributions
'deletedcontributions' => 'Stregen bidracher',
'deletedcontributions-title' => 'Stregen bidracher',
'sp-deletedcontributions-contribs' => 'Bidracher',

# Special:LinkSearch
'linksearch' => "Schük efter ferwisangen uun't näät",
'linksearch-pat' => 'Schükmünster:',
'linksearch-ns' => 'Nöömrüm:',
'linksearch-ok' => 'Schük',
'linksearch-text' => 'Diar kön wariaabeln üs t.b. "*.bispal.de" brükt wurd. Tumanst ian TLD üs t.b. "*.org" skal uunden wurd.<br />{{PLURAL:$2|Protokol|Protokolen}}: <code>$1</code> (Diar woort http nimen, wan niks ööders uunden as.)',
'linksearch-line' => '$2 ferwiset üüb $1',
'linksearch-error' => 'Wariaabeln ("*") mut bluas bi a began faan en URL uunden wurd.',

# Special:ListUsers
'listusersfrom' => 'Wise brükern mä began üüb:',
'listusers-submit' => 'Wise',
'listusers-noresult' => 'Nään brüker fünjen.',
'listusers-blocked' => '(speret)',

# Special:ActiveUsers
'activeusers' => 'Aktiif brükern',
'activeusers-intro' => 'Jodiar brükern wiar {{PLURAL:$1|di leetst dai| a leetst $1 daar}} aktiif.',
'activeusers-count' => '$1 {{PLURAL:$1|aktjuun|aktjuunen}} uun a {{PLURAL:$3|leetst 24 stünj|leetst $3 daar}}',
'activeusers-from' => 'Wise brükern mä began üüb:',
'activeusers-hidebots' => 'Bots fersteeg',
'activeusers-hidesysops' => 'Administratooren fersteeg',
'activeusers-noresult' => 'Nään brükern fünjen.',

# Special:ListGroupRights
'listgrouprights' => 'Brükersköölrochten',
'listgrouprights-summary' => 'Jodiar brükersköölen an hör rochten san uun detheer Wiki fäästlaanj wurden.
Muar diartu fanjst dü üüb  [[{{MediaWiki:Listgrouprights-helppage}}|detdiar sidj]].',
'listgrouprights-key' => 'Bedüüdang:
* <span class="listgrouprights-granted">Tugestenen rocht</span>
* <span class="listgrouprights-revoked">Wechnimen rocht</span>',
'listgrouprights-group' => 'Skööl',
'listgrouprights-rights' => 'Rochten',
'listgrouprights-helppage' => 'Help:Brükersköölrochten',
'listgrouprights-members' => '(lasmooten)',
'listgrouprights-addgroup' => 'Brüker tu {{PLURAL:$2|detdiar skööl|jodiar sköölen}} tuwise: $1',
'listgrouprights-removegroup' => 'Brüker ütj {{PLURAL:$2|detdiar skööl|jodiar sköölen}} ütjnem: $1',
'listgrouprights-addgroup-all' => 'Brüker tu aal a sköölen tuwise',
'listgrouprights-removegroup-all' => 'Brüker ütj aal a sköölen wechnem',
'listgrouprights-addgroup-self' => 'Aanj brükerkonto tu {{PLURAL:$2|detdiar skööl|jodiar sköölen}} tuwise: $1',
'listgrouprights-removegroup-self' => 'Aanj brükerkonto faan {{PLURAL:$2|detdiar skööl|jodiar sköölen}} wechnem: $1',
'listgrouprights-addgroup-self-all' => "Koon aal a sköölen tu't aanj brükerkonto tuwise",
'listgrouprights-removegroup-self-all' => "Koon aal a sköölen faan't aanj brükerkonto wechnem",

# Email user
'mailnologin' => "Bi't e-mail ferschüüren as wat skiaf gingen",
'mailnologintext' => 'Dü skel [[Special:UserLogin|uunmeldet wees]] an en gudkäänd e-mail-adres uun din [[Special:Preferences|iinstelangen]] haa, am dat dü ööder brükern en e-mail schüür könst.',
'emailuser' => 'E-mail tu didiar brüker',
'emailuser-title-target' => 'E-mail tu {{GENDER:$1|didiar brüker|detdiar brükerin}} schüür',
'emailuser-title-notarget' => 'E-mail tu brüker',
'emailpage' => 'E-mail tu brüker',
'emailpagetext' => 'Dü könst {{GENDER:$1|di brüker|det brükerin}} mä det formulaar en e-mail schüür.
Din aanj e-mail adres faan din [[Special:Preferences|iinstelangen]] woort uunwiset, so dat {{GENDER:$1|di brüker|det brükerin}} di saner amwai swaare koon.',
'usermailererror' => 'Det e-mail objekt wiset en feeler uun.',
'defemailsubject' => '{{SITENAME}} e-mail faan brüker „$1“',
'usermaildisabled' => 'E-mail fun as ei aktiif',
'usermaildisabledtext' => 'Dü könst nian e-mail tu ööder brükern schüür.',
'noemailtitle' => 'Nian e-mail adres',
'noemailtext' => 'Didiar brüker hää nian gudkäänd e-mail adres uunden.',
'nowikiemailtitle' => 'E-mail koon ei sjüürd wurd',
'nowikiemailtext' => 'Didiar brüker maad nian e-mails faan ööder brükern fu.',
'emailnotarget' => 'Didiar brükernööm as ei bekäänd of ei gudkäänd, am ham en e-mail tu schüüren',
'emailtarget' => 'Brükernööm faan di ööder brüker iindu',
'emailusername' => 'Brükernööm:',
'emailusernamesubmit' => 'Widjer',
'email-legend' => 'E-mail tu en öödern {{SITENAME}}-brüker schüür',
'emailfrom' => 'Faan:',
'emailto' => 'Tu:',
'emailsubject' => 'Teemo:',
'emailmessage' => 'Mädialang:',
'emailsend' => 'Schüür',
'emailccme' => 'Schüür mi en kopii faan det e-mail.',
'emailccsubject' => 'Kopii faan din mädialang tu $1: $2',
'emailsent' => 'E-mail as wechschüürd wurden',
'emailsenttext' => 'Din e-mail as wechsjüürd wurden.',
'emailuserfooter' => 'Detdiar e-mail as faan di {{SITENAME}}-brüker „$1“ tu „$2“ schüürd wurden.',

# User Messenger
'usermessage-summary' => 'Süsteemnooracht seekert.',
'usermessage-editor' => 'Süsteemnoorachten siinst',

# Watchlist
'watchlist' => "Uun't uug behual",
'mywatchlist' => "Uun't uug behual",
'watchlistfor2' => 'Foon $1 $2',
'nowatchlist' => "Diar as nään iindrach, diar dü uun't uug behual wel.",
'watchlistanontext' => "Dü skel di $1, am iindracher tu leesen of tu bewerkin, diar dü uun't uug behual wel.",
'watchnologin' => 'Ei uunmeldet',
'watchnologintext' => "Dü skel [[Special:UserLogin|uunmeldet]] wees, am iindracher tu bewerkin, diar dü uun't uug behual wel.",
'addwatch' => "Uk uun't uug behual",
'addedwatchtext' => "Det sidj „[[:$1]]“ wel dü [[Special:Watchlist|uun't uug behual]].
Feranrangen faan detdiar sidj wurd üüb detdiar list fäästhäälen.",
'removewatch' => "Ei muar uun't uug behual",
'removedwatchtext' => "Det sidj „[[:$1]]“ as faan a sidjen, diar dü [[Special:Watchlist|uun't uug behual]] wel, wechnimen wurden.",
'watch' => "Uun't uug behual",
'watchthispage' => "Detdiar sidj uun't uug behual",
'unwatch' => "Ei muar uun't uug behual",
'unwatchthispage' => "Ei muar uun't uug behual",
'notanarticle' => 'Nään artiikel',
'notvisiblerev' => 'Det werjuun faan en öödern brüker as stregen wurden.',
'watchlist-details' => "Dü heest {{PLURAL:$1|1 sidj|$1 sidjen}} uun't uug.",
'wlheader-enotif' => 'Di e-mail siinst as aktiif.',
'wlheader-showupdated' => "Nei feranert sidjen wurd '''fäät''' uunwiset.",
'watchmethod-recent' => "Leetst feranrangen faan sidjen, diar dü uun't uug heest",
'watchmethod-list' => "Sidjen, diar dü uun't uug heest, am a leetst feranrangen beluke",
'watchlistcontains' => "Dü häälst $1 {{PLURAL:$1|sidj|sidjen}} uun't uug.",
'iteminvalidname' => 'Mä di iindrach „$1“ stemet wat ei, di nööm as ferkiard.',
'wlnote' => "Diar {{PLURAL:$1|stäänt det leetst feranrang|stun a leetst '''$1''' feranrangen}} faan a leetst {{PLURAL:$2|stünj|'''$2''' stünjen}}. Stant: $3, klook $4.",
'wlshowlast' => 'Wise a feranrangen faan leetst $1 stünjen, $2 daar of $3.',
'watchlist-options' => "Iinstelangen för't uunwisin",

# Displayed when you click the "watch" button and it is in the process of watching
'watching' => "Uun't uug behual ...",
'unwatching' => "Ei uun't uug behual ...",
'watcherrortext' => "Bi't anrin faan iinstelangen för „$1“ as wat skiaf gingen.",

'enotif_mailer' => '{{SITENAME}}-e-mail-noorachten siinst',
'enotif_reset' => 'Aal a sidjen üs besoocht kääntiakne',
'enotif_impersonal_salutation' => '{{SITENAME}}-brüker',
'enotif_subject_deleted' => '{{SITENAME}}-sidj $1 as faan {{GENDER:$2|$2}} stregen wurden.',
'enotif_subject_created' => '{{SITENAME}}-sidj $1 as faan {{GENDER:$2|$2}} nei maaget wurden',
'enotif_subject_moved' => '{{SITENAME}}-sidj $1 as faan {{GENDER:$2|$2}} fersköwen wurden.',
'enotif_subject_restored' => '{{SITENAME}}-sidj $1 as faan {{GENDER:$2|$2}} turaghaalet wurden',
'enotif_subject_changed' => '{{SITENAME}}-sidj $1 as faan {{GENDER:$2|$2}} feranert wurden',
'enotif_body_intro_deleted' => 'Det {{SITENAME}}-sidj $1 as di $PAGEEDITDATE faan {{GENDER:$2|$2}} stregen wurden. Luke uk bi $3.',
'enotif_body_intro_created' => 'Det {{SITENAME}}-sidj $1 as di $PAGEEDITDATE faan {{GENDER:$2|$2}} nei maaget wurden. Luke uk bi $3 am en nei werjuun.',
'enotif_body_intro_moved' => 'Det {{SITENAME}}-sidj $1 as di $PAGEEDITDATE faan {{GENDER:$2|$2}} fersköwen wurden. Luke uk bi $3 am en nei werjuun.',
'enotif_body_intro_restored' => 'Det {{SITENAME}}-sidj $1 as di $PAGEEDITDATE faan {{GENDER:$2|$2}} turaghaalet wurden. Luke uk bi $3 am en nei werjuun.',
'enotif_body_intro_changed' => 'Det {{SITENAME}}-sidj $1 as di $PAGEEDITDATE faan {{GENDER:$2|$2}} feranert wurden. Luke uk bi $3 am en nei werjuun.',
'enotif_lastvisited' => 'Luke bi $1 am aal a feranrangen sant dan leetst beschük.',
'enotif_lastdiff' => 'Luke bi $1 am det feranrang.',
'enotif_anon_editor' => 'Anonüüm brüker $1',
'enotif_body' => 'Gud dai $WATCHINGUSERNAME,

$PAGEINTRO $NEWPAGE

Tuupfaadet faan: $PAGESUMMARY $PAGEMINOREDIT

Kontakt tu di bewerker:
E-mail: $PAGEEDITOR_EMAIL
Wiki: $PAGEEDITOR_WIKI

Di wurd iarst ans nian e-mails muar tu detdiar sidj schüürd, bit dü det sidj weder beschükst. Üüb din list faan sidjen, diar dü uun\'t uug behual wel, könst dü a noorachtenkääntiaken weder turagsaat.

Dan frinjelk {{SITENAME}}-noorachten siinst

--
Am iinstelangen tu e-mail noorachten tu feranrin, gung tu {{canonicalurl:{{#special:Preferences}}}}.

Am iinstelangen am sidjen, diar dü uun\'t uug behual wel, gung tu {{canonicalurl:{{#special:EditWatchlist}}}}.

Am det sidj ei linger uun\'t uug tu behualen, gung tu $UNWATCHURL.

Halep an muar diartu: {{canonicalurl:{{MediaWiki:Helppage}}}}',
'created' => 'maaget',
'changed' => 'feranert',

# Delete
'deletepage' => 'Sidj strik',
'confirm' => 'Gudkään',
'excontent' => 'diar sted: „$1“',
'excontentauthor' => 'diar sted: „$1“ (iansagst bewerker: [[Special:Contributions/$2|$2]])',
'exbeforeblank' => "diar sted föör't leesag maagin: „$1“",
'exblank' => 'sidj wiar leesag',
'delete-confirm' => 'Strik "$1"',
'delete-legend' => 'Strike',
'historywarning' => "'''Paase üüb:''' Det sidj, wat dü strik wel, hää amanbi $1 {{PLURAL:$1|werjuun|werjuunen}}:",
'confirmdeletetext' => 'Dü wel en sidj mä aal sin werjuunen strik. Dü skel gudkään, dat dü witjst, wat dü dääst an dat din dun mä a [[{{MediaWiki:Policy-url}}|brükerreegeln]] auerian stemet.',
'actioncomplete' => 'Klaar',
'actionfailed' => 'Diar ging wat skiaf',
'deletedtext' => "„$1“ as stregen wurden. Uun't $2 fanjst dü a sidjen, diar tuleetst stregen wurden san.",
'dellogpage' => 'Strik-logbuk',
'dellogpagetext' => 'Diar stun a leetst stregen sidjen an datein.',
'deletionlog' => "logbuk faan't striken",
'reverted' => 'Üüb en ual werjuun turagsaat',
'deletecomment' => 'Grünj:',
'deleteotherreason' => 'Ööder/noch en grünj:',
'deletereasonotherlist' => 'Ööder grünj',
'deletereason-dropdown' => "*Algemian grünjer för't striken
** Di skriiwer wul det so
** Copyright as ei beaachtet
** Wandaalen onerwais",
'delete-edit-reasonlist' => "Grünjer för't striken bewerke",
'delete-toobig' => 'Detdiar sidj hää muar üs $1 {{PLURAL:$1|werjuun|werjuunen}} . Sok sidjen kön ei so gau stregen wurd, ööders san a servers plaat.',
'delete-warning-toobig' => "Detdiar sidj hää muar üs $1 {{PLURAL:$1|werjuun|werjuunen}} . Det striken koon komer maage bi't dootenbeenk.",

# Rollback
'rollback' => 'Feranrangen turagsaat',
'rollback_short' => 'Turagsaat',
'rollbacklink' => 'turagsaat',
'rollbacklinkcount' => '$1 {{PLURAL:$1|feranrang|feranrangen}} turagsaat',
'rollbacklinkcount-morethan' => 'Muar üs $1 {{PLURAL:$1|werjuun|werjuunen}} turagsaat',
'rollbackfailed' => "Bi't turagsaaten as wat skiaf gingen.",
'cantrollback' => 'Det feranrang koon ei turagsaat wurd, diar san nian ööder skriiwern weesen.',
'alreadyrolled' => 'A anrangen faan [[User:$2|$2]] ([[User talk:$2|Diskusjuun]]{{int:pipe-separator}}[[Special:Contributions/$2|{{int:contribslink}}]]) bi [[:$1]] kön ei turagsaat wurd. Diar hää uuntesken en öödern brüker det sidj feranert.

Det leetst feranrang as faan [[User:$3|$3]] ([[User talk:$3|Diskusjuun]]{{int:pipe-separator}}[[Special:Contributions/$3|{{int:contribslink}}]]).',
'editcomment' => "Tuupfaadet feranrang: ''„$1“''.",
'revertpage' => 'Feranrangen faan [[Special:Contributions/$2|$2]] ([[User talk:$2|Diskusjuun]]) san üüb di leetst stant faan [[User:$1|$1]] turagsaat wurden.',
'revertpage-nouser' => 'Feranrangen faan en ferbürgenen brüker turagsaat an det leetst werjuun faan [[User:$1|$1]] weder iinsteld.',
'rollback-success' => 'Feranrangen faan $1 turagsaat an det leetst werjuun faan $2 weder iinsteld.',

# Edit tokens
'sessionfailure-title' => 'session feeler',
'sessionfailure' => "Diar as wat skiaf gingen bi't auerdreegen faan din brükerdooten.
Am dat diar ei noch muar skiaf gongt, as det aktjuun ufbreegen wurden.
Gung turag, an began faan föören.",

# Protect
'protectlogpage' => 'Sidjenseekerangs-logbuk',
'protectlogtext' => 'Detheer as det logbuk mä seekert sidjen.
Üüb [[Special:ProtectedPages|detdiar list]] stun a seekert sidjen.',
'protectedarticle' => 'hää „[[$1]]“ seekert.',
'modifiedarticleprotection' => 'hää det seekerhaid faan "[[$1]]" feranert',
'unprotectedarticle' => 'Seekerang faan „[[$1]]“ apheewen',
'movedarticleprotection' => 'hää det seekerang faan „[[$2]]“ üüb „[[$1]]“ auerdraanj',
'protect-title' => 'Seekerang feranre för „$1“',
'protect-title-notallowed' => 'Seekerang uunluke för „$1“',
'prot_1movedto2' => 'hää „[[$1]]“ efter „[[$2]]“ fersköwen',
'protect-badnamespace-title' => 'Nöömrüm koon ei seekert wurd',
'protect-badnamespace-text' => 'Sidjen uun didiar nöömrüm kön ei seekert wurd.',
'protect-norestrictiontypes-text' => 'Detdiar sidj koon ei seekert wurd, auer diar nian mögelkhaiden san.',
'protect-norestrictiontypes-title' => 'Sidj koon ei seekert wurd',
'protect-legend' => 'Sidjenseekerang feranre',
'protectcomment' => 'Grünj:',
'protectexpiry' => 'Sperdüür:',
'protect_expiry_invalid' => 'Didiar tidjrüm gongt ei.',
'protect_expiry_old' => 'Det spertidj leit uun a jütidj.',
'protect-unchain-permissions' => 'Separaat speren aktiwiare',
'protect-text' => 'Heer könst dü det seekerhaid faan "$1" uunluke an feranre.',
'protect-locked-blocked' => "Dü könst det sidjenseekerang ei feranre, auer din brükerkonto speret as. So as det sidj '''„$1“:''' seekert wurden.",
'protect-locked-dblock' => "Det dootenbeenk as speret, det sidjenseekerang koon ei feranert wurd. So as det sidj '''„$1“:''' seekert wurden.",
'protect-locked-access' => "Dü heest ei det brükerrocht, am det sidjenseekerhaid tu feranrin.
Det sidj '''„$1“:''' as sodenang seekert wurden:",
'protect-cascadeon' => 'Detdiar sidj as auer en kaskaadensper seekert wurden. Hat as uun {{PLURAL:$1|detdiar seekert sidj|jodiar seekert sidjen}} iinbünjen.
Dü könst det seekerhaid feranre, det feranert oober ei det seekerhaid faan jo ööder sidjen.',
'protect-default' => 'Arke brüker',
'protect-fallback' => 'Ferloof bluas för brükern mä "$1"-rochten.',
'protect-level-autoconfirmed' => 'Ferloof bluas för registriaret brükern.',
'protect-level-sysop' => 'Ferloof bluas för administratooren.',
'protect-summary-cascade' => 'kaskadiirin',
'protect-expiring' => 'bit $2, am a klook $3 (UTC)',
'protect-expiring-local' => 'bit $1',
'protect-expiry-indefinite' => 'saner aanj',
'protect-cascade' => 'Kaskaadensper - aal a föörlaagen faan detdiar sidj wurd uk speret',
'protect-cantedit' => 'Dü könst det sper faan detdiar sidj ei feranre, auer dü det sidj ei bewerke mutst.',
'protect-othertime' => 'Ööder sperdüür:',
'protect-othertime-op' => 'ööder sperdüür',
'protect-existing-expiry' => 'Sidjenseekerang lääpt uf: $2, klook $3',
'protect-otherreason' => 'Ööder/noch en grünj:',
'protect-otherreason-op' => 'Ööder grünj:',
'protect-dropdown' => '* Miast brükt grünjer
** Edit-War
** Wandaalen onerwais
** Tuföl rekloome
** Flooksis brükt föörlaag
** Sidj mä föl beschük',
'protect-edit-reasonlist' => "Grünjer för't seekrin bewerke",
'protect-expiry-options' => '1 stünj:1 hour,1 dai:1 day,1 weg:1 week,2 wegen:2 weeks,1 muun:1 month,3 muuner:3 months,6 muuner:6 months,1 juar:1 year,saner aanj:infinite',
'restriction-type' => 'Seekerhaidsiinstelangen:',
'restriction-level' => 'Seekerhaidspeegel:',
'minimum-size' => 'Minimaal grate:',
'maximum-size' => 'Maksimaal grate:',
'pagesize' => '(bytes)',

# Restrictions (nouns)
'restriction-edit' => 'Bewerke',
'restriction-move' => 'Fersküüw',
'restriction-create' => 'Maage',
'restriction-upload' => 'Huuchsjüür',

# Restriction levels
'restriction-level-sysop' => 'seekert (bluas för administratooren)',
'restriction-level-autoconfirmed' => 'hualew-seekert (bluas för gudkäänd brükern)',
'restriction-level-all' => 'aaltumaal',

# Undelete
'undelete' => 'Stregen sidjen uunwise',
'undeletepage' => 'Stregen sidjen uunwise an weder iinstel',
'undeletepagetitle' => "'''Detdiar wiset a stregen werjuunen faan [[:$1|$1]]'''.",
'viewdeletedpage' => 'Stregen sidjen uunwise',
'undeletepagetext' => "{{PLURAL:$1|Detdiar sidj as stregen wurden, oober koon|Jodiar $1 sidjen san stregen wurden, oober kön}} faan administratooren weder iinsteld wurd, wan jo noch uun't archiif san.",
'undelete-fieldset-title' => 'Weder iinstel',
'undeleteextrahelp' => '* Am det sidj mä aal jo werjuunen weder iintustelen, schük nian enkelt werjuun ütj, du en grünj uun an trak do üüb „{{int:undeletebtn}}“.*
* Am en was werjuun weder iintustelen, schük det werjuun ütj, du en grünj uun an trak do üüb „{{int:undeletebtn}}“.',
'undeleterevisions' => '{{PLURAL:$1|1 werjuun|$1 werjuunen}} archiwiaret',
'undeletehistory' => 'Wan dü detdiar sidj weder iinstelst, wurd uk jo ual werjuunen weder iinsteld. 
Wan sant det striken en nei sidj mä di salew nööm iinsteld wurden as, wurd jo ual werjuunen bi det nei sidj mä iinwerket.',
'undeleterevdel' => 'Det woort ei weder iinsteld, wan det leetst werjuun ferbürgen as.
Wan det so as, skal det leetst werjuun iarst weder üüb normool steld wurd.',
'undeletehistorynoadmin' => 'Detdiar sidj as stregen wurden.
Oner könst dü sä, hoker det maaget hää an huaram.
Di tekst faan det stregen sidj fu bluas administratooren uunwiset.',
'undelete-revision' => 'Stregen werjuun faan $1 (di $4 am a klook $5 ), $3:',
'undeleterevision-missing' => 'Mä detdiar werjuun stemet wat ei. Ferlicht as di link ferkiard of det werjuun as ei muar diar.',
'undelete-nodiff' => 'Nian föörgunger-werjuun diar.',
'undeletebtn' => 'Weder iinstel',
'undeletelink' => 'wise / weder iinstel',
'undeleteviewlink' => 'Uunluke',
'undeletereset' => 'Turagsaat',
'undeleteinvert' => 'Ütjwool amdrei',
'undeletecomment' => 'Grünj:',
'undeletedrevisions' => '{{PLURAL:$1|1 werjuun|$1 werjuunen}} weder iinsteld',
'undeletedrevisions-files' => '{{PLURAL:$1|1 werjuun|$1 werjuunen}} an {{PLURAL:$2|1 datei|$2 datein}} weder iinsteld',
'undeletedfiles' => '{{PLURAL:$1|1 datei|$1 datein }} weder iinsteld',
'cannotundelete' => 'Weder iinstelen hää ei loket:
$1',
'undeletedpage' => "'''„$1“''' as weder iinsteld wurden.
Uun't [[Special:Log/delete|logbuk faan stregen sidjen]] stun a stregen an weder iinsteld sidjen.",
'undelete-header' => "Luke uun't [[Special:Log/delete|logbuk för stregen sidjen]] efter stregen sidjen faan a leetst tidj.",
'undelete-search-title' => 'Schük stregen sidjen',
'undelete-search-box' => 'Schük stregen sidjen',
'undelete-search-prefix' => 'Schük sidjen, diar began mä:',
'undelete-search-submit' => 'Schük',
'undelete-no-results' => "Uun't archiif wiar nian paasen sidjen.",
'undelete-filename-mismatch' => 'Det werjuun faan $1 koon ei weder iinsteld wurd. Di dateinööm paaset ei.',
'undelete-bad-store-key' => "Det dateiwersjuun faan $1 koon ei weder iinsteld wurd. Det datei wiar al föör't striken ei muar diar.",
'undelete-cleanup-error' => 'Det ei brükt archiif-werjuun $1 küd ei stregen wurd.',
'undelete-missing-filearchive' => "Det datei mä det archiif-ID $1 koon ei weder iinsteld wurd, auer hat ei uun't dootenbeenk as. Ferlicht as't al ans weder iinsteld wurden?",
'undelete-error' => "Bi't weder iinstelen faan det sidj as wat skiaf gingen.",
'undelete-error-short' => "Bi't weder iinstelen faan det datei $1 as wat skiaf gingen.",
'undelete-error-long' => "Bi't weder iinstelen faan en datei as wat skiaf gingen:

$1",
'undelete-show-file-confirm' => 'Wel dü würelk det stregen werjuun faan det datei „<nowiki>$1</nowiki>“ faan di $2, am a klook $3 uunluke?',
'undelete-show-file-submit' => 'Ja',

# Namespace form on various pages
'namespace' => 'Nöömrüm:',
'invert' => 'Ütjwool amkiir',
'tooltip-invert' => 'Saat diar en tiaken, am feranrangen faan sidjen uun didiar nöömrüm ei uuntuwisin.',
'namespace_association' => 'Ferbünjen nöömrüm',
'tooltip-namespace_association' => 'Saat diar en tiaken, am di ferbünjen nöömrüm of diskusjuunsnöömrüm mä iintubetjin.',
'blanknamespace' => '(Sidjen)',

# Contributions
'contributions' => '{{GENDER:$1|Brüker}} bidracher',
'contributions-title' => 'Brükerbidracher för "$1"',
'mycontris' => 'Bidracher',
'contribsub2' => 'För $1 ($2)',
'nocontribs' => 'Diar wiar nian paasin brükerbidracher',
'uctop' => '(aktuel)',
'month' => 'faan muun (of iarer):',
'year' => 'faan juar (of iarer):',

'sp-contributions-newbies' => 'Wise bluas bidracher faan nei brükern',
'sp-contributions-newbies-sub' => 'Faan nei brükern',
'sp-contributions-newbies-title' => 'Brükerbidracher faan nei brükern',
'sp-contributions-blocklog' => 'Sper-logbuk',
'sp-contributions-deleted' => 'Stregen bidracher',
'sp-contributions-uploads' => 'Huuchschüürd bilen',
'sp-contributions-logs' => 'Logbuken',
'sp-contributions-talk' => 'Diskusjuun',
'sp-contributions-userrights' => 'Brükerrochten',
'sp-contributions-blocked-notice' => "Didiar brüker as speret. Det stäänt uun't sperlogbuk:",
'sp-contributions-blocked-notice-anon' => "Detdiar IP-adres as speret. Det stäänt uun't sperlogbuk:",
'sp-contributions-search' => 'Schük efter brükerbidracher',
'sp-contributions-username' => 'IP-adres of brükernööm:',
'sp-contributions-toponly' => 'Bluas aktuel werjuunen wise',
'sp-contributions-submit' => 'Schük',

# What links here
'whatlinkshere' => 'Ferwisangen üüb detdiar sidj',
'whatlinkshere-title' => 'Sidjen, diar üüb "$1" ferwise',
'whatlinkshere-page' => 'Sidj:',
'linkshere' => "Jodiar sidjen ferwise üüb '''„[[:$1]]“''':",
'nolinkshere' => 'Nian sidj ferwiset üüb [[:$1]]',
'nolinkshere-ns' => "Nian sidj ferwiset üüb '''„[[:$1]]“''' uun di ütjsoocht nöömrüm.",
'isredirect' => 'widjerfeerang',
'istemplate' => 'iinbünjen föörlaagen',
'isimage' => 'Dateilink',
'whatlinkshere-prev' => '{{PLURAL:$1|leetst|leetst $1}}',
'whatlinkshere-next' => '{{PLURAL:$1|naist|naist $1}}',
'whatlinkshere-links' => '← ferwisangen',
'whatlinkshere-hideredirs' => '$1 widjerfeerangen',
'whatlinkshere-hidetrans' => '$1 iinbünjen föörlaagen',
'whatlinkshere-hidelinks' => '$1 ferwisangen',
'whatlinkshere-hideimages' => 'Ferwisangen tu datein $1',
'whatlinkshere-filters' => 'Filtere',

# Block/unblock
'autoblockid' => 'Automaatisk sper #$1',
'block' => 'Brüker spere',
'unblock' => 'Brüker ei muar spere',
'blockip' => 'IP-adres/brüker spere',
'blockip-title' => 'Brüker spere',
'blockip-legend' => 'IP-adres/brüker spere',
'blockiptext' => 'Mä detdiar formulaar sperest dü en IP-adres of en brükernööm, so dat faan diar nian feranrangen muar maaget wurd kön. 
Det skul bluas föörnimen wurd, am jin wandaalen föörtugungen an uun auerianstemang mä a [[{{MediaWiki:Policy-url}}|brükerreegeln]].
Skriiw en guden grünj för det sper ap.',
'ipadressorusername' => 'IP-adres of brükernööm:',
'ipbexpiry' => 'Sperdüür:',
'ipbreason' => 'Grünj:',
'ipbreasonotherlist' => 'Ööder grünj',
'ipbreason-dropdown' => '* Mist brükt spergrünjer
** Skraft wat ferkiards
** Maaget sidjen leesag
** Maaget tuföl ferwisangen üüb frääm sidjen
** Maaget dom tschüch
** Koon ham ei skake
** Masbrükt brükerkontos
** Hää en brükernööm, diar ei tuläät as',
'ipb-hardblock' => 'Ferhanre, dat en uunmeldeten brüker mä detdiar IP-adres sidjen feranre koon.',
'ipbcreateaccount' => 'Ferhanre, dat en brükerkonto iinracht woort.',
'ipbemailban' => 'Ferhanre, dat e-mails ferschüürd wurd',
'ipbenableautoblock' => 'Spere det IP-adres faan di brüker, an automaatisk uk aal a öödern, huar di brüker mä werket.',
'ipbsubmit' => 'IP-adres/brüker spere',
'ipbother' => 'Ööder sperdüür (ingelsk):',
'ipboptions' => '2 stünj:2 hours,1 dai:1 day,3 daar:3 days,1 weg:1 week,2 weg:2 weeks,1 muun:1 month,3 muuner:3 months,6 muuner:6 months,1 juar:1 year,saner aanj:infinite',
'ipbotheroption' => 'Ööder sperdüür',
'ipbotherreason' => 'Ööder/noch en grünj:',
'ipbhidename' => 'Brükernööm uun feranrangen an listen fersteeg',
'ipbwatchuser' => "Hual di brüker sin brüker- an diskusjuunssidj uun't uug",
'ipb-disableusertalk' => 'Ferhanre, dat di brüker sin diskusjuunssidj bewerket, so loong hi speret as.',
'ipb-change-block' => 'Mä jodiar iinstelangen widjer spere',
'ipb-confirm' => 'Sper gudkään',
'badipaddress' => 'Det IP-adres as ferkiard.',
'blockipsuccesssub' => 'Det sper hää loket.',
'blockipsuccesstext' => "Di brüker/det IP-adres [[Special:Contributions/$1|$1]] as speret wurden.<br />
Am det aptuheewen, gung tu't [[Special:BlockList|sperlist]].",
'ipb-blockingself' => 'Wel dü würelk di salew spere?',
'ipb-confirmhideuser' => 'Dü beest diarbi, en brüker uun det muude „brüker fersteeg“ tu sperin. Do woort di brükernööm uun aal a logbuken an listen ferbürgen. Wel dü det würelk du?',
'ipb-edit-dropdown' => "Grünjer för't sperin bewerke",
'ipb-unblock-addr' => '„$1“ ei muar spere',
'ipb-unblock' => 'IP-adres/brüker ei muar spere',
'ipb-blocklist' => 'Speren uunwise',
'ipb-blocklist-contribs' => 'Bidracher faan „$1“',
'unblockip' => 'Brüker ei muar spere',
'unblockiptext' => 'Mä detdiar formulaar könst dü det sper faan en IP-adres of en brüker apheew.',
'ipusubmit' => 'Ei muar spere',
'unblocked' => '[[User:$1|$1]] woort ei muar speret.',
'unblocked-range' => 'Sper för $1 as apheewen wurden.',
'unblocked-id' => 'Sperang $1 as apheewen',
'blocklist' => 'Speret brükern',
'ipblocklist' => 'Speret brükern',
'ipblocklist-legend' => 'Speret brüker finj',
'blocklist-userblocks' => 'Brükersperen ei uunwise',
'blocklist-tempblocks' => 'Tidjwiis speren ei uunwise',
'blocklist-addressblocks' => 'Speren faan enkelt IP-adresen ei uunwise',
'blocklist-rangeblocks' => 'Widjloftag speren ei uunwise',
'blocklist-timestamp' => 'Tidjstempel',
'blocklist-target' => 'IP of brüker',
'blocklist-expiry' => 'Sperdüür bit',
'blocklist-by' => 'Speret faan',
'blocklist-params' => 'Speriinstelangen',
'blocklist-reason' => 'Grünj',
'ipblocklist-submit' => 'Schük',
'ipblocklist-localblock' => 'Lokaal sper',
'ipblocklist-otherblocks' => 'Ööder {{PLURAL:$1|sper|speren}}',
'infiniteblock' => 'saner aanj',
'expiringblock' => 'lääpt di $1 am a klook $2 uf',
'anononlyblock' => 'bluas anonüümen',
'noautoblockblock' => 'autoblock ei aktiif',
'createaccountblock' => 'brükerkontos kön ei iinracht wurd.',
'emailblock' => 'e-mail fersjüüren ufsteld',
'blocklist-nousertalk' => 'koon sin aanj diskusjuunssidj ei bewerke',
'ipblocklist-empty' => 'Det sperlist as leesag',
'ipblocklist-no-results' => 'Detdiar IP-adres/di brükernööm as ei speret.',
'blocklink' => 'Spere',
'unblocklink' => 'Ei muar spere',
'change-blocklink' => 'Sper feranre',
'contribslink' => 'Bidracher',
'emaillink' => 'E-mail schüür',
'autoblocker' => 'Automaatisk speret, auer dü en gemiansoom IP-adres mä [[User:$1|brüker:$1]] brükst. Grünj för det brükersper: „$2“.',
'blocklogpage' => 'Brükersper-logbuk',
'blocklog-showlog' => "Didiar brüker as al ans speret wurden.
Uun't sperlogbuk stäänt:",
'blocklog-showsuppresslog' => "Didiar brüker as al ans speret an ferbürgen wurden.
Uun't logbuk stäänt:",
'blocklogentry' => 'hää „[[$1]]“ speret för di tidjrüm: $2 $3',
'reblock-logentry' => 'hää det sper för „[[$1]]“ anert för di tidjrüm: $2 $3',
'blocklogtext' => "Detdiar as det logbuk auer sperangen an apheewen sperangen faan brükernöömer an IP-adresen.
Automaatisk sperd IP-adresen wurd ei uunwiset.
Luke bi't [[Special:BlockList|sperlist]] för aal jo aktuel speren.",
'unblocklogentry' => 'hää det sper faan „$1“ apheewen',
'block-log-flags-anononly' => 'bluas IPs/anonüümen',
'block-log-flags-nocreate' => 'brükerkontos kön ei iinracht wurd.',
'block-log-flags-noautoblock' => 'autoblock ei aktiif',
'block-log-flags-noemail' => 'e-mail fersjüüren ufsteld',
'block-log-flags-nousertalk' => 'koon sin aanj diskusjuunssidj ei bewerke',
'block-log-flags-angry-autoblock' => 'ütjwidjet autoblock aktiwiaret',
'block-log-flags-hiddenname' => 'brükernööm ferbürgen',
'range_block_disabled' => 'Det mögelkhaid, hialer adresrümer tu sperin, as ei aktiif.',
'ipb_expiry_invalid' => 'Didiar tidjrüm gongt ei.',
'ipb_expiry_temp' => 'Ferbürgen brükernööm-speren skel permanent wees.',
'ipb_hide_invalid' => 'Detdiar brükerkonto koon ei ferbürgen wurd, auer diar tuföl feranrangen uun a ferluup stun.',
'ipb_already_blocked' => '„$1“ as al speret',
'ipb-needreblock' => '$1 as al speret. Wel dü a speriinstelangen feranre?',
'ipb-otherblocks-header' => 'Ööder {{PLURAL:$1|sper|speren}}',
'unblock-hideuser' => 'Det sper faan didiar brüker koon ei apheewen wurd, auer san brükernööm ferbürgen wurden as.',
'ipb_cant_unblock' => 'Feeler: Sper-ID $1 küd ei fünjen wurd. Det sper as al apheewen.',
'ipb_blocked_as_range' => 'Feeler: Det IP-adres $1 as auer det widjloftag sper $2 speret. Det sper faan $1 alian koon ei apheewen wurd.',
'ip_range_invalid' => 'Ferkiard IP-adresrüm',
'ip_range_toolarge' => 'Adresrümen mut ei grater üs /$1 wees.',
'proxyblocker' => 'Proxy blocker',
'proxyblockreason' => 'Din IP-adres as speret wurden, auer det tu en eebenen proxy hiart.
Fertel det dan ISP of dan süsteemsiinst. Eeben proxys stel det seekerhaid uun fraag.',
'sorbsreason' => 'Din IP-adres as uun det DNSBL faan {{SITENAME}} üs eeben proxy apfeerd.',
'sorbs_create_account_reason' => 'Din IP-adres as uun det DNSBL faan {{SITENAME}} üs eeben proxy apfeerd. Dü könst nian brükerkonto maage.',
'xffblockreason' => 'En IP-adres uun di X-Forwarded-For-Header as speret wurden, det as din aanj of det faan dan proxy server. Di spergrünj as: $1',
'cant-block-while-blocked' => 'Dü könst nian ööder brükern spere, so loong dü salew speret beest.',
'cant-see-hidden-user' => 'Di brüker, diar dü spere wel, as al speret an ferbürgen. Dü heest oober ei det "hideuser"-rocht an könst det sper ei bewerke.',
'ipbblocked' => 'Dü könst ööder brükern ei spere an uk nian speren apheew, auer dü salew speret beest.',
'ipbnounblockself' => 'Dü könst din aanj sper ei apheew.',

# Developer tools
'lockdb' => 'Dootenbeenk spere',
'unlockdb' => 'Dootenbeenk ei muar spere',
'lockdbtext' => 'Wan det dootenbeenk speret as, koon rian goor niks muar maaget wurd. Wees so gud an kään det sper gud.',
'unlockdbtext' => 'Wan det sper faan det dootenbeenk apheewen woort, koon weder ales bewerket wurd. Wees so gud an kään det apheewen gud.',
'lockconfirm' => 'Ja, ik wal det dootenbeenk würelk spere.',
'unlockconfirm' => 'Ja, det dootenbeenk skal ei muar speret wees.',
'lockbtn' => 'Dootenbeenk spere',
'unlockbtn' => 'Dootenbeenk ei muar spere',
'locknoconfirm' => 'Dü heest det ei gudkäänd.',
'lockdbsuccesssub' => 'Det dootenbeenk as nü speret.',
'unlockdbsuccesssub' => 'Det dootenbeenk as nü ei muar speret.',
'lockdbsuccesstext' => 'Det {{SITENAME}}-dootenbeenk as speret wurden.<br />Heew det sper [[Special:UnlockDB|weder ap]], wan dü mä din werk klaar beest.',
'unlockdbsuccesstext' => 'Det {{SITENAME}}-dootenbeenk as ei muar speret.',
'lockfilenotwritable' => 'Uun det dootenbeenk-sperdatei koon ei skrewen wurd. Am en dootenbeenk tu sperin of en sper aptuheewen, skal det sperdatei för di webserver tu beskriiwen wees.',
'databasenotlocked' => 'Det dootenbeenk as ei speret.',
'lockedbyandtime' => '(faan $1 di $2 am a klook $3)',

# Move page
'move-page' => 'Fersküüw $1',
'move-page-legend' => 'Sid ferschüwe',
'movepagetext' => "Mä detdiar formulaar könst dü en sidj mä aal sin werjuunen amnääm.
Di ual tiitel woort üüb di nei widjerfeerd.
Dü könst widjerfeerangen, diar üüb di ual tiitel wise, automaatisk üüb di nei tiitel widjerfeer läät.
Wan dü det oober ei dääst, paase üüb, dat dü aal a [[Special:DoubleRedirects|dobelt]] of [[Special:BrokenRedirects|breegen]] widjerfeerangen noch ans efterlukest.
Bluas dü könst diarför surge, dat ferwisangen widjerhen rocht werke.

Det sidj woort '''ei''' fersköwen, wan't al en sidj mä di nei nööm jaft. Det loket bluas do, wan di nei nööm salew en widjerfeerang as. Det ment, dat dü det amnäämen turagsaat könst, wan dü niks ferkiard maaget heest. Dü könst oober nian sidj, diar't al jaft, auerskriiw.

'''Paase üüb!'''
Det fersküüwen hää widjloftag fulgen för ööder sidjen. Dü skulst begreben haa, wat dü diar maage wel.",
'movepagetext-noredirectfixer' => "Mä detdiar formulaar könst dü en sidj mä aal sin werjuunen amnääm.
Di ual tiitel woort üüb di nei widjerfeerd.
Dü könst widjerfeerangen, diar üüb di ual tiitel wise, automaatisk üüb di nei tiitel widjer feer läät.
Wan dü det oober ei dääst, paase üüb, dat dü aal a [[Special:DoubleRedirects|dobelt]] of [[Special:BrokenRedirects|breegen]] widjerfeerangen noch ans efterlukest.
Bluas dü könst diarför surge, dat ferwisangen widjerhen rocht werke.

Det sidj woort '''ei''' fersköwen, wan't al en sidj mä di nei nööm jaft. Det loket bluas do, wan di nei nööm salew en widjerfeerang as. Det ment, dat dü det amnäämen turagsaat könst, wan dü niks ferkiard maaget heest. Dü könst oober nian sidj, diar't al jaft, auerskriiw.

'''Paase üüb!'''
Det fersküüwen hää widjloftag fulgen för ööder sidjen. Dü skulst begreben haa, wat dü diar maage wel.",
'movepagetalktext' => "Uk det diskusjuunssidj woort fersköwen, wan det diar as, '''oober ei, wan:'''
*Diar al en diskusjuunssidj mä didiar nööm as, of
*Dü detdiar mögelkhaid ütjslotst.

Uun didiar faal skel dü a diskusjuunssidjen faan hun tuupfeer.

Dreeg di '''nei''' tiitel bi '''ööder sidj''' iin, an diaroner '''en grünj''' för't amnäämen.",
'movearticle' => 'Sidj fersküüw:',
'moveuserpage-warning' => "'''Paase üüb:''' Dü wel en brükersidj fersküüw. Seenk diaram, dat bluas det brükersidj amnäämd woort, oober '''ei''' di brüker. Hi behäält san ual nööm.",
'movenologin' => 'Ei uunmeldet',
'movenologintext' => 'Dü skel registriaret an [[Special:UserLogin|uunmeldet]] wees, am en sidj tu fersküüwen.',
'movenotallowed' => 'Dü mutst nian sidjen fersküüw.',
'movenotallowedfile' => 'Dü mutst nian datein fersküüw.',
'cant-move-user-page' => 'Dü mutst nian brükersidjen fersküüw (bluas onersidjen).',
'cant-move-to-user-page' => 'Dü mutst nian sidjen üüb en brükersidj fersküüw (bluas üüb onersidjen).',
'newtitle' => 'Müülj:',
'move-watch' => "Jodiar sidjen uun't uug behual",
'movepagebtn' => 'Sidj fersküüw',
'pagemovedsub' => 'Ferschüwing luket',
'movepage-moved' => "'''Det sidj „$1“ as efter „$2“ fersköwen wurden.'''",
'movepage-moved-redirect' => 'En widjerfeerang as iinracht wurden.',
'movepage-moved-noredirect' => 'Det maagin faan en widjerfeerang as ferhanert wurden.',
'articleexists' => 'En sidj mä didiar nööm jaft at al. Wees so gud an nem en öödern nööm.',
'cantmove-titleprotected' => 'Dü könst det sidj ei so fersküüw, auer di nei nööm speret as.',
'talkexists' => 'Detdiar sidj as fersköwen wurden, oober det diskusjuunssidj ei, auer diar al son diskusjuunssidj wiar. Fal det salew mä bidracher faan det ual sidj ap.',
'movedto' => 'fersköwen efter',
'movetalk' => "Uk det diskusjuunssidj fersküüw, wan't gongt",
'move-subpages' => 'Onersidjen fersküüw (bit $1)',
'move-talk-subpages' => "Onersidjen faan't diskusjuunssidj fersküüw (bit $1)",
'movepage-page-exists' => 'Det sidj „$1“ as al diar an koon ei automaatisk auerskrewen wurd.',
'movepage-page-moved' => 'Det sidj $1 as efter $2 fersköwen wurden.',
'movepage-page-unmoved' => 'Det sidj $1 küd ei efter $2 fersköwen wurd.',
'movepage-max-pages' => 'Diar kön ei muar üs {{PLURAL:$1|sidj|sidjen}} fersköwen wurd. Muar sidjen kön ei automaatisk fersköwen wurd.',
'movelogpage' => 'Fersküüw-logbuk',
'movelogpagetext' => 'Det as en list mä fersköwen sidjen.',
'movesubpage' => '{{PLURAL:$1|Onersidj|Onersidjen}}',
'movesubpagetext' => 'Det sidj hää {{PLURAL:$1|detdiar $1 onersidj|jodiar $1 onersidjen}}.',
'movenosubpage' => 'Det sidj hää nian onersidjen.',
'movereason' => 'Grünj:',
'revertmove' => 'turag fersküüw',
'delete_and_move' => 'Strik an fersküüw',
'delete_and_move_text' => '== Striken nuadag  ==

Det sidj „[[:$1]]“ as al diar. Wel dü det strik, am det sidj tu fersküüwen?',
'delete_and_move_confirm' => 'Ja, sidj strik',
'delete_and_move_reason' => 'Stregen, am steeds för det fersküüwen faan „[[$1]]“ tu maagin.',
'selfmove' => 'A nöömer san likedenang. Dü könst nian sidj üüb ham salew fersküüw.',
'immobile-source-namespace' => 'Sidjen uun di nöömrüm "$1" kön ei fersköwen wurd.',
'immobile-target-namespace' => 'Sidjen kön ei iin uun di nöömrüm "$1" fersköwen wurd.',
'immobile-target-namespace-iw' => 'Dü könst nian sidj üüb en interwiki-link fersküüw.',
'immobile-source-page' => 'Detdiar sidj koon ei fersköwen wurd.',
'immobile-target-page' => 'Üüb detdiar sidj koon ei fersköwen wurd.',
'bad-target-model' => 'Det nei sidj hää en ööder münster üs det ual. Det münster faan $1 koon ei tu det münster faan $2 feranert wurd.',
'imagenocrossnamespace' => 'Datein kön ei ütj di {{ns:file}}-nöömrüm ütj fersköwen wurd.',
'nonfile-cannot-move-to-file' => 'Det as nian datei, wat dü iin uun di {{ns:file}}-nöönmrüm fersküüw wel. Det gongt ei.',
'imagetypemismatch' => 'Det nei dateiaanj as ei detsalew üs det ual.',
'imageinvalidfilename' => 'Didiar dateinööm gongt ei.',
'fix-double-redirects' => "Efter't fersküüwen aal a widjerfeerangen hen tu det ual sidj ferbeedre",
'move-leave-redirect' => 'Widjerfeerang iinracht',
'protectedpagemovewarning' => "'''Paase üüb: Detdiar sidj as speret wurden. Bluas administratooren kön det fersküüw.'''
Uun't logbuk stäänt muar diartu:",
'semiprotectedpagemovewarning' => "'''Paase üüb:''' Detdiar sidj as dialwiis tu't bewerkin speret wurden. Bluas gudkäänd brükern kön det fersküüw.
Uun't logbuk stäänt muar diartu:",
'move-over-sharedrepo' => '== Datei as al diar ==
[[:$1]] stäänt uun en gemiansoom brükt archiif. Det fersküüwen üüb didiar nööm auerskraft det gemiansoom brükt datei.',
'file-exists-sharedrepo' => 'Didiar dateinööm woort al uun en gemiansoom archiif brükt. Wees so gud, an nem en öödern nööm.',

# Export
'export' => 'Sidjen eksportiare',
'exporttext' => 'Mä detdiar spezial-sidj könst dü di tekst mä aal sin werjuunen tu en XML-datei eksportiare. Det nei datei koon do faan en ööder MediaWiki-Wiki [[Special:Import|importiaret]] wurd.

Skriiw a sidjennöömer iin uun det tekstfial (man bluas ään noom uun arke rä).

Di eksport as uk mä [[{{#Special:Export}}/{{MediaWiki:Mainpage}}]] mögelk, tun bispal för det [[{{MediaWiki:Mainpage}}]].',
'exportall' => 'Aal a sidjen eksportiare',
'exportcuronly' => 'Bluas det aktuel werjuun eksportiare, ei jo ual werjuunen',
'exportnohistory' => "----
'''Paase üüb:''' Di eksport faan di hial ferluup as uun uugenblak ei mögelk.",
'exportlistauthors' => 'För arke sidj det hial list faan bewerkern mänem',
'export-submit' => 'Eksport',
'export-addcattext' => 'Sidjen faan detdiar kategorii diartunem:',
'export-addcat' => 'Diartunem',
'export-addnstext' => 'Sidjen faan didiar nöömrüm diartunem:',
'export-addns' => 'Diartunem',
'export-download' => 'Üs XML-datei seekre',
'export-templates' => 'Mä föörlaagen',
'export-pagelinks' => 'Ferwiset sidjen mänem bit tu en jipde faan:',

# Namespace 8 related
'allmessages' => 'MediaWiki-Süsteemnoorachten',
'allmessagesname' => 'Nööm',
'allmessagesdefault' => 'Standard tekst',
'allmessagescurrent' => 'Aktuel tekst',
'allmessagestext' => "Det as en list mä MediaWiki-süsteemteksten.
Wees so gud an beschük a sidjen [//www.mediawiki.org/wiki/Localisation MediaWiki-auersaatang] an [//translatewiki.net translatewiki.net], wan dü bi't auersaaten mähalep meest.",
'allmessagesnotsupportedDB' => 'Detdiar spezial-sidj koon ei brükt wurd, auer <tt>$wgUseDatabaseMessages</tt> ei aktiif as.',
'allmessages-filter-legend' => 'Filter',
'allmessages-filter' => 'Filter för di uunpaaset stant:',
'allmessages-filter-unmodified' => 'Ünferanert',
'allmessages-filter-all' => 'Aaltumaal',
'allmessages-filter-modified' => 'Feranert',
'allmessages-prefix' => 'Filter mä prefix:',
'allmessages-language' => 'Spriak:',
'allmessages-filter-submit' => 'Widjer',

# Thumbnails
'thumbnail-more' => 'Fergratre',
'filemissing' => 'Datei ei diar',
'thumbnail_error' => "Bi't skriiwen faan det föörskaubil as wat skiaf gingen: $1",
'thumbnail_error_remote' => 'Feeler faan $1:
$2',
'djvu_page_error' => 'DjVu-sidj as bütjen faan a sidjenrüm',
'djvu_no_xml' => 'XML-dooten för det DjVu-datei kön ei ufrepen wurd',
'thumbnail-temp-create' => 'Det datei för det tidjwiis sümnaielbil küd ei skrewen wurd',
'thumbnail-dest-create' => 'Det föörskaubil küd diar ei seekert wurd.',
'thumbnail_invalid_params' => 'Sümnaieldooten steme ei',
'thumbnail_dest_directory' => 'Det fertiaknis koon ei skrewen wurd.',
'thumbnail_image-type' => 'Sok bilen kön ei brükt wurd',
'thumbnail_gd-library' => 'GD-bibleteek ei gans diar: Det funktjuun $1 waant',
'thumbnail_image-missing' => 'Det datei as wel ei diar: $1',

# Special:Import
'import' => 'Sidjen importiare',
'importinterwiki' => 'Transwiki import',
'import-interwiki-text' => "Schük en Wiki an en sidj tu importiarin ütj. A werjuunen an brükernöömer bliiw erhäälen.
Transwiki-import-aktjuunen wurd uun't [[Special:Log/import|Import-logbuk]] fäästhäälen.",
'import-interwiki-source' => 'Faan hün Wiki/sidj:',
'import-interwiki-history' => 'Aal a werjuunen faan det sidj importiare',
'import-interwiki-templates' => 'Mä aal a föörlaagen',
'import-interwiki-submit' => 'Import',
'import-interwiki-namespace' => 'Tu hün nöömrüm:',
'import-interwiki-rootpage' => 'Tu hün sidj (optional):',
'import-upload-filename' => 'Dateinööm:',
'import-comment' => 'Komentaar:',
'importtext' => 'Wees so gud an eksportiare det datei mä det spezial-sidj [[Special:Export|Eksport]] ütj det ööder Wiki. Det seekerst dü üüb dan reegner an schüürst det do heer huuch.',
'importstart' => 'Importiare sidjen ...',
'import-revision-count' => '$1 {{PLURAL:$1|werjuun|werjuunen}}',
'importnopages' => 'Diar san nian sidjen tu importiarin.',
'imported-log-entries' => '$1 {{PLURAL:$1|logbukiindrach|logbukiindracher}} importiaret.',
'importfailed' => 'Import as skiaf gingen: <nowiki>$1</nowiki>',
'importunknownsource' => 'Ünbekäänd importkwel',
'importcantopen' => 'Det import-datei küd ei eeben maaget wurd.',
'importbadinterwiki' => 'Ferkiard interwiki-link',
'importnotext' => 'Leesag of nään tekst',
'importsuccess' => 'Import klaar!',
'importhistoryconflict' => 'Diar san al ääler werjuunen diar. Ferlicht as det sidj al ans importiaret wurden.',
'importnosources' => 'För di transwiki-import san nian kwelen uunden. Dü könst werjuunen ei direkt huuchschüür.',
'importnofile' => 'Diar as nian importdatei bestemet wurden.',
'importuploaderrorsize' => "Bi't huuchschüüren faan det importdatei as wat skiaf gingen. Det datei as tu grat.",
'importuploaderrorpartial' => "Bi't huuchschüüren faan det importdatei as wat skiaf gingen. Det datei as bluas dialwiis huuchschüürd wurden.",
'importuploaderrortemp' => "Bi't huuchschüüren faan det importdatei as wat skiaf gingen. Diar as nian tidjwiis fertiaknis.",
'import-parse-failure' => "Bi't importiarin faan det XML-datei as wat skiaf gingen.",
'import-noarticle' => 'Diar as nian sidj tu importiarin bestemet wurden.',
'import-nonewrevisions' => 'Aal jodiar werjuunen san al ans importiaret wurden.',
'xml-error-string' => '$1 uun rä $2, türn $3 (byte $4): $5',
'import-upload' => 'XML-datein importiare',
'import-token-mismatch' => 'Session dooten san wech. Ferschük det noch ans weder.',
'import-invalid-interwiki' => 'Faan detdiar Wiki koon ik ei importiare.',
'import-error-edit' => 'Det sidj „$1“ as ei importiaret wurden, auer dü det ei bewerke mutst.',
'import-error-create' => 'Det sidj „$1“ as ei importiaret wurden, auer dü det ei maage mutst.',
'import-error-interwiki' => 'Det sidj „$1“ as ei importiaret wurden, auer di nööm för ferwisangen (interwiki) föörsen as.',
'import-error-special' => 'Det sidj „$1“ as ei importiaret wurden, auer hat tu en nöömrüm hiart, huar nian sidjen mögelk san.',
'import-error-invalid' => 'Det sidj „$1“ as ei importiaret wurden, auer di nööm ei stemet.',
'import-error-unserialize' => 'Det werjuun $2 faan det sidj „$1“ küd ei deserialisiaret wurd. Det werjuun woort mä det münster $3 brükt, an det as mä $4 serialisiaret.',
'import-options-wrong' => 'Ferkiard {{PLURAL:$2|iinstelang|iinstelangen}}: <nowiki>$1</nowiki>',
'import-rootpage-invalid' => 'Didiar sidjennööm as ferkiard.',
'import-rootpage-nosubpage' => 'Uun di nöömrüm „$1“ jaft at nian onersidjen.',

# Import log
'importlogpage' => 'Import-logbuk',
'importlogpagetext' => 'Administratiif import faan sidjen mä aal a werjuunen faan ööder Wikis.',
'import-logentry-upload' => '„[[$1]]“ faan en datei importiaret',
'import-logentry-upload-detail' => '$1 {{PLURAL:$1|werjuun|werjuunen}}',
'import-logentry-interwiki' => '„$1“ mä transwiki importiaret',
'import-logentry-interwiki-detail' => '$1 {{PLURAL:$1|werjuun|werjuunen}} faan $2',

# JavaScriptTest
'javascripttest' => 'JavaScript-test',
'javascripttest-title' => '$1-tests wurd ütjfeerd.',
'javascripttest-pagetext-noframework' => 'Detdiar sidj as för JavaScript-tests föörsen.',
'javascripttest-pagetext-unknownframework' => 'Ünbekäänd test-framework „$1“.',
'javascripttest-pagetext-frameworks' => 'Schük ian faan jodiar test-frameworks ütj: $1',
'javascripttest-pagetext-skins' => 'Schük en brüker-skak ütj, am di test ütjtufeeren:',
'javascripttest-qunit-intro' => 'Luke efter bi [$1 test dokumentatjuun] üüb mediawiki.org',
'javascripttest-qunit-heading' => 'JavaScript-QUnit-tester faan MediaWiki',

# Tooltip help for the actions
'tooltip-pt-userpage' => 'Din brükersidj',
'tooltip-pt-anonuserpage' => 'Brükersidj faan det IP-adres, faan huar ütj dü werkest',
'tooltip-pt-mytalk' => 'Din diskusjuunssidj',
'tooltip-pt-anontalk' => 'Diskusjuun auer feranrangen faan detdiar IP-adres',
'tooltip-pt-preferences' => 'Min iinstelangen',
'tooltip-pt-watchlist' => "Sidjen, diar dü uun't uug behual wel",
'tooltip-pt-mycontris' => 'List mä aanj bidracher',
'tooltip-pt-login' => 'Wan dü di uunmeldest, heest dü muar mögelkhaiden. Dü säärst det oober ei.',
'tooltip-pt-anonlogin' => 'Wan dü di uunmeldest, heest dü muar mögelkhaiden. Dü säärst det oober ei.',
'tooltip-pt-logout' => 'Ufmelde',
'tooltip-ca-talk' => 'Diskusjuun auer di artiikel',
'tooltip-ca-edit' => 'Sidj bewerke. Luke di det iarst ans uun, iar dü det seekerst.',
'tooltip-ca-addsection' => 'Nei kirew began',
'tooltip-ca-viewsource' => 'Detdiar sidj as seekert wurden.
Dü könst di kweltekst uunluke.',
'tooltip-ca-history' => 'Ääler werjuunen faan detdiar sidj',
'tooltip-ca-protect' => 'Detdiar sidj seekre',
'tooltip-ca-unprotect' => 'Seekerang feranere',
'tooltip-ca-delete' => 'Detdiar sidj strik',
'tooltip-ca-undelete' => 'Iindracher faan det sidj turaghaale, iar det stregen wurden as.',
'tooltip-ca-move' => 'Detdiar sidj fersküüw',
'tooltip-ca-watch' => "Detdiar sidj uk uun't uug behual",
'tooltip-ca-unwatch' => "Detdiar sidj ei muar uun't uug behual",
'tooltip-search' => 'Schük uun {{SITENAME}}',
'tooltip-search-go' => 'Gung tu det sidj, diar jüst so het.',
'tooltip-search-fulltext' => 'Schük efter sidjen mä didiar tekst',
'tooltip-p-logo' => 'Hoodsidj beschük',
'tooltip-n-mainpage' => 'Hoodsidj wise',
'tooltip-n-mainpage-description' => 'Hoodsidj beschük',
'tooltip-n-portal' => 'Auer det projekt, wat dü maage könst, an huar dü wat fanjst.',
'tooltip-n-currentevents' => 'Muar auer a "miilstianer", diar det wurden an waaksen faan\'t Nordfriisk Wikipedia eftertiakne',
'tooltip-n-recentchanges' => 'Leetst feranrangen faan {{SITENAME}}',
'tooltip-n-randompage' => 'Tufelag sidj',
'tooltip-n-help' => 'Halepsidj uunwise',
'tooltip-t-whatlinkshere' => 'Aal a sidjen, diar heerhen ferwise',
'tooltip-t-recentchangeslinked' => 'Leetst feranrangen faan sidjen, huar faan heer üüb ferwiset woort',
'tooltip-feed-rss' => 'RSS-feed för detdiar sidj',
'tooltip-feed-atom' => 'Atom-feed för detdiar sidj',
'tooltip-t-contributions' => 'List mä bidracher faan didiar brüker uunluke',
'tooltip-t-emailuser' => 'En e-mail tu didiar brüker schüür',
'tooltip-t-upload' => 'Datein huuchschüür',
'tooltip-t-specialpages' => 'Auersicht auer aal a spezial-sidjen',
'tooltip-t-print' => 'Drükföörskau',
'tooltip-t-permalink' => 'Permanent ferwisang tu detdiar werjuun faan det sidj.',
'tooltip-ca-nstab-main' => 'Sidj uunluke',
'tooltip-ca-nstab-user' => 'Brükersidj uunluke',
'tooltip-ca-nstab-media' => 'Mediendateisidj uunwise',
'tooltip-ca-nstab-special' => 'Det as en spezial-sidj. Hat koon ei bewerket wurd.',
'tooltip-ca-nstab-project' => 'Projektsidj uunluke',
'tooltip-ca-nstab-image' => 'Dateisidj uunluke',
'tooltip-ca-nstab-mediawiki' => 'MediaWiki-süsteemtekst uunwise',
'tooltip-ca-nstab-template' => 'Föörlaag uunluke',
'tooltip-ca-nstab-help' => 'Heelpsid wise',
'tooltip-ca-nstab-category' => 'Kategoriisidj uunluke',
'tooltip-minoredit' => 'Detdiar feranrang üs letj kääntiakne.',
'tooltip-save' => 'Feranrangen seekre',
'tooltip-preview' => 'Föörskau faan feranrangen üüb detdiar sidj. Iarst noch ans luke, iar dü det sidj seekerst!',
'tooltip-diff' => 'Feranrangen bi a tekst wise',
'tooltip-compareselectedversions' => 'Ferskeel tesken tau werjuunen faan detdiar sidj uunwise.',
'tooltip-watch' => "Detdiar sidj uk uun't uug behual",
'tooltip-watchlistedit-normal-submit' => 'Iindracher wechnem',
'tooltip-watchlistedit-raw-submit' => "List mä sidjen, diar dü uun't uug behual wel, aktualisiare",
'tooltip-recreate' => 'Sidj nei maage, likes dat det al ans stregen wurden as',
'tooltip-upload' => 'Huuchschüüren began',
'tooltip-rollback' => 'Saat aal a leetst feranrangen faan disalew brüker mä ään klik turag.',
'tooltip-undo' => 'Saat bluas det leetst feranrang turag an wiset det resultoot uun en föörskau uun. Uun det tuupfaadet beskriiwang skul en grünj för det turagsaaten uunden wurd.',
'tooltip-preferences-save' => 'Iinstelangen seekre',
'tooltip-summary' => 'Faade det kurt tuup',

# Metadata
'notacceptable' => 'Di Wiki-server koon a dooten ei för dan aperoot apwerke.',

# Attribution
'anonymous' => '{{PLURAL:$1|anonüümen brüker|anonüüm brükern}} üüb {{SITENAME}}',
'siteuser' => '{{SITENAME}}-brüker $1',
'anonuser' => 'Anonüüm {{SITENAME}}-brüker $1',
'lastmodifiedatby' => 'Det sidj as tuleetst di $1 am a klook $2 faan $3 feranert wurden.',
'othercontribs' => 'Üüb grünjlaag faan det werk faan $1.',
'others' => 'öödern',
'siteusers' => '{{SITENAME}} {{PLURAL:$2|brüker|brükern}} $1',
'anonusers' => '{{PLURAL:$2|anonüümen|anonüüm}} {{SITENAME}}-{{PLURAL:$2|brüker|brükern}} $1',
'creditspage' => 'Sidjeninformatsjuunen',
'nocredits' => 'Diar san nian sidjeninformatsjuunen',

# Spam protection
'spamprotectiontitle' => 'Spam-filter',
'spamprotectiontext' => 'Di tekst, diar dü seekre wulst, as ei troch a spam-filter kimen. Det leit was uun en ferwisang üüb en sidj efter bütjen.',
'spamprotectionmatch' => "'''Didiar tekst as faan a spam-filter fünjen wurden: ''$1'''''",
'spambot_username' => 'MediaWiki-spam apklaarin',
'spam_reverting' => 'Leetst werjuun saner ferwisangen tu $1 weder iinsteld.',
'spam_blanking' => 'Aal a werjuunen mä en ferwisang tu $1 san apklaaret wurden.',
'spam_deleting' => 'Aal a werjuunen mä en ferwisung tu $1 san stregen wurden.',

# Info page
'pageinfo-title' => 'Informatjuun tu „$1“',
'pageinfo-not-current' => 'Det informatjuun jaft at ei för ual werjuunen.',
'pageinfo-header-basic' => 'Grünjdooten',
'pageinfo-header-edits' => 'Ferluup bewerke',
'pageinfo-header-restrictions' => 'Sidjenseekerhaid',
'pageinfo-header-properties' => 'Sidjeniinstelangen',
'pageinfo-display-title' => 'Uunwiset sidjennööm',
'pageinfo-default-sort' => 'Normool sortiariinstelang',
'pageinfo-length' => 'Sidjenlengde (uun bytes)',
'pageinfo-article-id' => 'Sidjenkäännumer (ID)',
'pageinfo-language' => 'Sidjenspriak',
'pageinfo-robot-policy' => 'Faan bots indisiaret',
'pageinfo-robot-index' => 'Tuläät',
'pageinfo-robot-noindex' => 'Ei tuläät',
'pageinfo-views' => 'Taal faan kliks üüb det sidj',
'pageinfo-watchers' => "Taal faan brükern, diar det sidj uun't uug haa",
'pageinfo-few-watchers' => "Maner üs {{PLURAL:$1|ään brüker|$1 brükern}}, diar det sidj uun't uug haa",
'pageinfo-redirects-name' => 'Taal faan widjerfeerangen tu detdiar sidj',
'pageinfo-subpages-name' => 'Onersidjen faan detdiar sidj',
'pageinfo-subpages-value' => '$1 ($2 {{PLURAL:$2|widjerfeerang|widjerfeerangen}}; $3 {{PLURAL:$3|onersidj|onersidjen}})',
'pageinfo-firstuser' => 'Hoker det sidj maaget hää',
'pageinfo-firsttime' => 'Wan det sidj maaget wurden as',
'pageinfo-lastuser' => 'Leetst skriiwer',
'pageinfo-lasttime' => "Dootem faan't leetst feranrang",
'pageinfo-edits' => 'Taal faan feranrangen',
'pageinfo-authors' => 'Taal faan skriiwern',
'pageinfo-recent-edits' => 'Taal faan a leetst feranrangen (uun a leetst $1)',
'pageinfo-recent-authors' => 'Taal faan skriiwern',
'pageinfo-magic-words' => 'Maagisk {{PLURAL:$1|wurd|wurden}} ($1)',
'pageinfo-hidden-categories' => 'Ferbürgen {{PLURAL:$1|kategorii|kategoriin}} ($1)',
'pageinfo-templates' => 'Iinbünjen {{PLURAL:$1|föörlaag|föörlaagen}} ($1)',
'pageinfo-transclusions' => 'Iinbünjen uun {{PLURAL:$1|1 sidj|$1 sidjen}}',
'pageinfo-toolboxlink' => 'Sidjendooten',
'pageinfo-redirectsto' => 'Widjerfeerangen tu',
'pageinfo-redirectsto-info' => 'Informatjuun',
'pageinfo-contentpage' => 'Üs artiikel tääld',
'pageinfo-contentpage-yes' => 'Ja',
'pageinfo-protect-cascading' => 'Sidjen mä kaskaadenseekerhaid faan heer',
'pageinfo-protect-cascading-yes' => 'Ja',
'pageinfo-protect-cascading-from' => 'Sidjen mä kaskaadenseekerhaid faan',
'pageinfo-category-info' => 'Kategorii-informatjuun',
'pageinfo-category-pages' => 'Taal faan sidjen',
'pageinfo-category-subcats' => 'Taal faan onerkategoriin',
'pageinfo-category-files' => 'Taal faan datein',

# Patrolling
'markaspatrolleddiff' => 'Üs kontroliaret kääntiakne',
'markaspatrolledtext' => 'Sidj üs kontroliaret kääntiakne',
'markedaspatrolled' => 'Üs kontroliaret kääntiakne',
'markedaspatrolledtext' => 'Detdiar werjuun faan [[:$1]] as üs kontroliaret kääntiakent wurden.',
'rcpatroldisabled' => 'A leetst feranrangen kön ei kontroliaret wurd.',
'rcpatroldisabledtext' => 'A leetst feranrangen kön tu tidj ei kontroliaret wurd.',
'markedaspatrollederror' => "Koon ei üs '''kontroliaret''' kääntiakent wurd.",
'markedaspatrollederrortext' => 'Dü mutst en werjuun besteme, diar dü üs köntroliaret kääntiakne wel.',
'markedaspatrollederror-noautopatrol' => 'Dü könst ei din aanj feranrangen üs kontroliaret kääntiakne.',
'markedaspatrollednotify' => 'Det feranrang faan $1 as üs kontroliaret kääntiakent wurden.',
'markedaspatrollederrornotify' => 'Det werjuun küd ei üs kontroliaret kääntiakent wurd.',

# Patrol log
'patrol-log-page' => 'Kontrol-logbuk',
'patrol-log-header' => 'Det as det kontrol-logbuk.',
'log-show-hide-patrol' => 'Kontrol-logbuk $1',

# Image deletion
'deletedrevision' => 'Ual werjuun $1 stregen',
'filedeleteerror-short' => "Bi't striken faan det datei $1 as wat skiaf gingen.",
'filedeleteerror-long' => "Bi't striken faan det datei as wat skiaf gingen:

$1",
'filedelete-missing' => 'Det datei „$1“ koon ei stregen wurd, auer hat goorei diar as.',
'filedelete-old-unregistered' => 'Det datei-werjuun „$1“ as ei diar uun a dootenbeenk.',
'filedelete-current-unregistered' => 'Det datei „$1“ as ei diar uun a dootenbeenk.',
'filedelete-archive-read-only' => 'Det archiif-fertiaknis "$1" koon faan a webserver ei beskrewen wurd.',

# Browsing diffs
'previousdiff' => '← Leetst feranrang',
'nextdiff' => 'Naist werjuunsferskeel →',

# Media information
'mediawarning' => "'''Paase üüb:''' Son datei koon fülk programcode haa. Bi't deelloosin an eeben maagin koon dan reegner komer fu.",
'imagemaxsize' => "Bil mut ei grater wees üs:<br />''(för datei-beskriiwangen)''",
'thumbsize' => 'Grate faan sümnaielbilen:',
'widthheightpage' => '$1 × $2, {{PLURAL:$3|1 sidj|$3 sidjen}}',
'file-info' => 'Dateigrate: $1, MIME-typ: $2',
'file-info-size' => '$1 × $2 pixels, dateigrate: $3, MIME-typ: $4',
'file-info-size-pages' => '$1 × $2 pixel, dateigrate: $3, MIME-typ: $4, $5 {{PLURAL:$5|sidj|sidjen}}',
'file-nohires' => 'Diar as nian huuger apliasang diar.',
'svg-long-desc' => 'SVG-datei, grate: $1 × $2 pixel, dateigrate: $3',
'svg-long-desc-animated' => 'Animiaret SVG-datei, grate $1 × $2 pixel, dateigrate: $3',
'svg-long-error' => 'Ferkiard SVG-datei: $1',
'show-big-image' => 'Huuger apliasang',
'show-big-image-preview' => 'Grate faan detdiar föörskaubil: $1.',
'show-big-image-other' => 'Ööder {{PLURAL:$2|apliasang|apliasangen}}: $1.',
'show-big-image-size' => '$1 × $2 pixel',
'file-info-gif-looped' => 'sleuf saner aanj',
'file-info-gif-frames' => '$1 {{PLURAL:$1|bil|bilen}}',
'file-info-png-looped' => 'sleuf saner aanj',
'file-info-png-repeat' => '$1 {{PLURAL:$1|-sis}} ufspelet',
'file-info-png-frames' => '$1 {{PLURAL:$1|bil|bilen}}',
'file-no-thumb-animation' => "'''Paase üüb: Ütj technisk grünjer wurd sümnaielbilen ei animiaret uunwiset.'''",
'file-no-thumb-animation-gif' => "'''Paase üüb: Ütj technisk grünjer wurd sümnaielbilen faan huuchapliasin GIF-datein ei animiaret uunwiset.'''",

# Special:NewFiles
'newimages' => 'Nei datein',
'imagelisttext' => "Diar as en list faan '''$1''' {{PLURAL:$1|datei|datein}}, sortiaret $2.",
'newimages-summary' => 'Detdiar spezial-sidj wiset a tuleetst huuchsjüürd datein uun.',
'newimages-legend' => 'Filter',
'newimages-label' => 'Dateinööm (of en dial diarfaan):',
'showhidebots' => '(Bots $1)',
'noimages' => 'Niks tu sen.',
'ilsubmit' => 'Schük',
'bydate' => 'efter dootem',
'sp-newimages-showfrom' => 'Wise nei datein efter $1, klook $2',

# Video information, used by Language::formatTimePeriod() to format lengths in the above messages
'seconds' => '{{PLURAL:$1|$1 sekund|$1 sekunden}}',
'minutes' => '{{PLURAL:$1|$1 minüüt|$1 minüüten}}',
'hours' => '{{PLURAL:$1|$1 stünj|$1 stünjen}}',
'days' => '{{PLURAL:$1|$1 dai|$1 daar}}',
'weeks' => '{{PLURAL:$1|$1 weg|$1 wegen}}',
'months' => '{{PLURAL:$1|$1 muun|$1 muuner}}',
'years' => '{{PLURAL:$1|$1 juar|$1 juaren}}',
'ago' => 'föör $1',
'just-now' => 'jüst nü',

# Human-readable timestamps
'hours-ago' => 'föör {{PLURAL:$1|ian stünj|$1 stünjen}}',
'minutes-ago' => 'föör {{PLURAL:$1|ian minüüt|$1 minüüten}}',
'seconds-ago' => 'föör {{PLURAL:$1|ian sekund|$1 sekunden}}',
'monday-at' => 'Mundai am a klook $1',
'tuesday-at' => 'Teisdai am a klook $1',
'wednesday-at' => 'Wäärnsdai am a klook $1',
'thursday-at' => 'Süürsdai am a klook $1',
'friday-at' => 'Freidai am a klook $1',
'saturday-at' => 'Saninj am a klook $1',
'sunday-at' => 'Söndai am a klook $1',
'yesterday-at' => 'Jister am a klook $1',

# Bad image list
'bad_image_list' => 'Formaat:

Bluas räen, diar mä en * began, wurd mätääld.
Det skal bääft di * began mä en ferwisang üüb en ferkiard datei. 
Ferwisangen uun det salew rä wurd üs ütjnoomen uunsen, huar det datei dach uunwiset wurd mut.',

# Metadata
'metadata' => 'Metadooten',
'metadata-help' => 'Uun detdiar datei stun muar dooten, jo kem miast faan en digitaal knipskasche of faan en scanner. Ferlicht san hög dooten uk leederhen feranert wurden.',
'metadata-expand' => 'Ütjwidjet dooten wise',
'metadata-collapse' => 'Ütjwidjet dooten fersteeg',
'metadata-fields' => 'Jodiar EXIF-metadooten wurd uunwiset, wan det metadootentabel ferbürgen as. Jo öödern san iarst ans ferbürgen.
* make
* model
* datetimeoriginal
* exposuretime
* fnumber
* isospeedratings
* focallength
* artist
* copyright
* imagedescription
* gpslatitude
* gpslongitude
* gpsaltitude',

# Exif tags
'exif-imagewidth' => 'Breetje',
'exif-imagelength' => 'Hööchde',
'exif-bitspersample' => 'Bits per klöör',
'exif-compression' => 'Komprimiarang',
'exif-photometricinterpretation' => 'Pixel bonk',
'exif-orientation' => 'Perspektiiw',
'exif-samplesperpixel' => 'Taal faan komponenten',
'exif-planarconfiguration' => 'Dooten skak',
'exif-ycbcrsubsampling' => 'subsampling rate faan Y bit C',
'exif-ycbcrpositioning' => 'Y an C positjuun',
'exif-xresolution' => 'Wairocht apliasang',
'exif-yresolution' => 'Luadrocht apliasang',
'exif-stripoffsets' => 'Image data location',
'exif-rowsperstrip' => 'Taal faan rän per strimel',
'exif-stripbytecounts' => 'Bytes per komprimiaret strimel',
'exif-jpeginterchangeformat' => 'Offset tu JPEG SOI',
'exif-jpeginterchangeformatlength' => 'Bytes faan JPEG-dooten',
'exif-whitepoint' => 'White point chromaticity',
'exif-primarychromaticities' => 'Chromaticities of primarities',
'exif-ycbcrcoefficients' => 'Color space transformation matrix coefficients',
'exif-referenceblackwhite' => 'Suart/witj referens ponkter',
'exif-datetime' => "Dootem an klooktidj faan't seekrin",
'exif-imagedescription' => "Nööm faan't bil",
'exif-make' => 'Knipser onernemen',
'exif-model' => 'Knipser marke/model',
'exif-software' => 'Software',
'exif-artist' => 'Fotogroof',
'exif-copyright' => 'Bilrochten',
'exif-exifversion' => 'Stant faan Exif',
'exif-flashpixversion' => 'Flashpix-werjuun',
'exif-colorspace' => 'Klöörenrüm',
'exif-componentsconfiguration' => 'Enkelt komponenten',
'exif-compressedbitsperpixel' => 'Komprimiaret bits per pixel',
'exif-pixelydimension' => 'Bilbreetje',
'exif-pixelxdimension' => 'Bilhööchde',
'exif-usercomment' => 'Brüker komentaaren',
'exif-relatedsoundfile' => 'Ferbünjen tuundatei',
'exif-datetimeoriginal' => "Dootem an klooktidj faan't knipsin",
'exif-datetimedigitized' => "Dootem an klooktidj faan't digitalisiarin",
'exif-subsectime' => 'Tidjponkt faan seekrin (1/100 s)',
'exif-subsectimeoriginal' => "Tidjponkt faan't knipsin (1/100 s)",
'exif-subsectimedigitized' => "Tidjponkt faan't digitalisiarin (1/100 s)",
'exif-exposuretime' => 'Belaachtangstidj',
'exif-exposuretime-format' => '$1 sekunden ($2)',
'exif-fnumber' => 'F numer (blend)',
'exif-exposureprogram' => 'Belaachtangsprogram',
'exif-spectralsensitivity' => 'Spectral sensitivity',
'exif-isospeedratings' => 'ISO emfintelkhaid',
'exif-shutterspeedvalue' => 'APEX shutter speed',
'exif-aperturevalue' => 'APEX aperture',
'exif-brightnessvalue' => 'APEX brightness',
'exif-exposurebiasvalue' => 'APEX exposure bias',
'exif-maxaperturevalue' => 'Gratst blend',
'exif-subjectdistance' => "Wai tu't subjekt",
'exif-meteringmode' => 'Meed muude',
'exif-lightsource' => 'Laachtkwel',
'exif-flash' => 'Laid',
'exif-focallength' => 'Braanwidjens',
'exif-subjectarea' => 'Rüm',
'exif-flashenergy' => 'Laidmäächt',
'exif-focalplanexresolution' => 'Focal plane X resolution',
'exif-focalplaneyresolution' => 'Focal plane Y resolution',
'exif-focalplaneresolutionunit' => 'Focal plane resolution unit',
'exif-subjectlocation' => "Steed faan't motiif",
'exif-exposureindex' => 'Belaachtangsindex',
'exif-sensingmethod' => 'Meed muude',
'exif-filesource' => 'Dateikwel',
'exif-scenetype' => 'Scene type',
'exif-customrendered' => 'Custom image processing',
'exif-exposuremode' => 'Belaachtangsmuude',
'exif-whitebalance' => 'Witjufglik',
'exif-digitalzoomratio' => 'Digital zoom ratio',
'exif-focallengthin35mmfilm' => 'Braanwidjens bi en 35 mm film',
'exif-scenecapturetype' => 'Scene capture type',
'exif-gaincontrol' => 'Scene control',
'exif-contrast' => 'Kontrast',
'exif-saturation' => 'Intensiteet faan klöören',
'exif-sharpness' => 'Skarepens',
'exif-devicesettingdescription' => 'Iinstelangen',
'exif-subjectdistancerange' => "Wai uf faan't motiif",
'exif-imageuniqueid' => 'Bil-ID',
'exif-gpsversionid' => 'GPS tag werjuun',
'exif-gpslatituderef' => 'Nuurdelk of süüdelk breetje',
'exif-gpslatitude' => 'Geograafisk Breetje',
'exif-gpslongituderef' => 'Uastelk of waastelk lengde',
'exif-gpslongitude' => 'Geograafisk lengde',
'exif-gpsaltituderef' => 'Hööchde uun ferglik mä',
'exif-gpsaltitude' => 'Hööchde',
'exif-gpstimestamp' => 'GPS-tidj',
'exif-gpssatellites' => "För't meeden brükt sateliten",
'exif-gpsstatus' => 'Receiver status',
'exif-gpsmeasuremode' => "Muude för't meeden",
'exif-gpsdop' => "Nauhaid faan't meeden",
'exif-gpsspeedref' => "Ianhaid faan't faard",
'exif-gpsspeed' => 'Faard faan a GPS-aperoot',
'exif-gpstrackref' => "Referens för di kurs faan't faard",
'exif-gpstrack' => "Kurs faan't faard",
'exif-gpsimgdirectionref' => "Referens för't ütjrachtang",
'exif-gpsimgdirection' => "Ütjrachtang faan't bil",
'exif-gpsmapdatum' => 'Geodeetisk referens-süsteem',
'exif-gpsdestlatituderef' => "Referens för't geograafisk breetje",
'exif-gpsdestlatitude' => "Geograafisk breetje faan't aanj",
'exif-gpsdestlongituderef' => "Referens för't geograafisk lengde",
'exif-gpsdestlongitude' => "Geograafisk lengde faan't aanj",
'exif-gpsdestbearingref' => "Referens för di kurs faan't aanj",
'exif-gpsdestbearing' => "Kurs faan't aanj",
'exif-gpsdestdistanceref' => "Referens för di wai tu't motiif",
'exif-gpsdestdistance' => "Wai tu't motiif",
'exif-gpsprocessingmethod' => 'GPS muude',
'exif-gpsareainformation' => 'GPS rüm',
'exif-gpsdatestamp' => 'GPS dootem',
'exif-gpsdifferential' => 'GPS diferential korektuur',
'exif-jpegfilecomment' => 'JPEG dateikomentaar',
'exif-keywords' => 'Steegwurden',
'exif-worldregioncreated' => 'Weltregiuun, huar det bil apnimen wurden as',
'exif-countrycreated' => 'Lun, huar det bil apnimen wurden as',
'exif-countrycodecreated' => 'ISO-code faan det lun',
'exif-provinceorstatecreated' => 'Prowins of federaalstoot, huar det bil aonimen wurden as',
'exif-citycreated' => 'Stääd, huar det bil apnimen wurden as',
'exif-sublocationcreated' => 'Stäädregiuun, huar det bil apnimen wurden as',
'exif-worldregiondest' => 'Uunwiset weltregiuun',
'exif-countrydest' => 'Uunwiset lun',
'exif-countrycodedest' => 'ISO-code för det uunwiset lun',
'exif-provinceorstatedest' => 'Prowins of federaalstoot',
'exif-citydest' => 'Uunwiset stääd',
'exif-sublocationdest' => 'Uunwiset stäädregiuun',
'exif-objectname' => 'Kurt tiitel',
'exif-specialinstructions' => 'Ekstra uunwisangen',
'exif-headline' => 'Auerskraft',
'exif-credit' => 'Faan hoker',
'exif-source' => 'Faan huar',
'exif-editstatus' => 'Hüwidj bewerket',
'exif-urgency' => 'Hü nuadag',
'exif-fixtureidentifier' => 'Ööders wat',
'exif-locationdest' => 'Steed üüb det bil',
'exif-locationdestcode' => "ISO-code faan det steed üüb't bil",
'exif-objectcycle' => "Tidj üüb a dai för't iinstelen",
'exif-contact' => 'Kontaktdooten',
'exif-writer' => 'Skriiwer',
'exif-languagecode' => 'Spriak',
'exif-iimversion' => 'IIM werjuun',
'exif-iimcategory' => 'Kategorii',
'exif-iimsupplementalcategory' => 'Muar kategooriin',
'exif-datetimeexpires' => 'Ei muar tu brüken efter',
'exif-datetimereleased' => 'Ütjden di',
'exif-originaltransmissionref' => 'ISO-code faan det steed, huar det bil auerdraanj wurden as',
'exif-identifier' => 'Käänang',
'exif-lens' => 'Hün objektiif',
'exif-serialnumber' => 'Luupen numer faan a knipser',
'exif-cameraownername' => 'Hoker di knipser hiart',
'exif-label' => 'Betiaknang',
'exif-datetimemetadata' => 'Leetst feranrang faan meta-dooten',
'exif-nickname' => 'Nööm för det bil',
'exif-rating' => 'Wäärdaghaid (1 tu 5, 5 as best)',
'exif-rightscertificate' => 'Rights management certificate',
'exif-copyrighted' => 'Copyright-Status:',
'exif-copyrightowner' => 'Bilrochten lei bi',
'exif-usageterms' => 'Brükerreegeln',
'exif-webstatement' => 'Online copyright statement',
'exif-originaldocumentid' => "Iandüüdag käänang (ID) faan't dokument",
'exif-licenseurl' => 'URL for copyright license',
'exif-morepermissionsurl' => 'Muar lisensen',
'exif-attributionurl' => 'Wan dü det bil brük wel, saat en ferwisang üüb:',
'exif-preferredattributionname' => 'Wan dü det bil brük wel, nääm:',
'exif-pngfilecomment' => 'PNG dateikomentaar',
'exif-disclaimer' => 'Disclaimer',
'exif-contentwarning' => 'Wäärnang',
'exif-giffilecomment' => 'GIF dateikomentaar',
'exif-intellectualgenre' => 'Slach faan bil',
'exif-subjectnewscode' => 'Motiif-code',
'exif-scenecode' => 'IPTC-code',
'exif-event' => 'Begeebenhaid',
'exif-organisationinimage' => 'Organisatjuun',
'exif-personinimage' => 'Persuun',
'exif-originalimageheight' => "Hööchde faan't bil föör't beklapen",
'exif-originalimagewidth' => "Breetje faan't bil föör't beklapen",

# Exif attributes
'exif-compression-1' => 'Ünkomprimiaret',
'exif-compression-2' => 'CCITT Group 3 1-Dimensional Modified Huffman run length encoding',
'exif-compression-3' => 'CCITT Group 3 fax encoding',
'exif-compression-4' => 'CCITT Group 4 fax encoding',

'exif-copyrighted-true' => 'Mä kopiarrocht',
'exif-copyrighted-false' => 'Kopiarrochten noch ei fäästlaanj',

'exif-unknowndate' => 'Ünbekäänd dootem',

'exif-orientation-1' => 'Normool',
'exif-orientation-2' => 'Wairocht speegelt',
'exif-orientation-3' => 'Am 180° dreid',
'exif-orientation-4' => 'Luadrocht speegelt',
'exif-orientation-5' => 'Jin a klook am 90° dreid an luadrocht speegelt.',
'exif-orientation-6' => 'Jin a klook am 90° dreid',
'exif-orientation-7' => 'Mä a klook am 90° dreid an luadrocht speegelt.',
'exif-orientation-8' => 'Mä a klook am 90° dreid',

'exif-planarconfiguration-1' => 'Grööw formaat',
'exif-planarconfiguration-2' => 'Planaar formaat',

'exif-colorspace-65535' => 'Ei kalibriaret',

'exif-componentsconfiguration-0' => 'as ei diar',

'exif-exposureprogram-0' => 'ei bekäänd',
'exif-exposureprogram-1' => 'Manuel',
'exif-exposureprogram-2' => 'Normool program',
'exif-exposureprogram-3' => 'Tidjautomaatik',
'exif-exposureprogram-4' => 'Blendenautomaatik',
'exif-exposureprogram-5' => 'Kreatiifprogram mä jip skarepens',
'exif-exposureprogram-6' => 'Aktjuunsprogram mä kurt belaachtangstidj',
'exif-exposureprogram-7' => 'Portree-muude mä skarepen föörgrünj',
'exif-exposureprogram-8' => 'Loonskap-muude mä skarepen bääftgrünj',

'exif-subjectdistance-value' => '$1 meetern',

'exif-meteringmode-0' => 'Ünbekäänd',
'exif-meteringmode-1' => 'Madel',
'exif-meteringmode-2' => 'Skarep maden',
'exif-meteringmode-3' => 'Spot',
'exif-meteringmode-4' => 'Multi-Spot',
'exif-meteringmode-5' => 'Münster',
'exif-meteringmode-6' => 'Bil-dial',
'exif-meteringmode-255' => 'Ööder',

'exif-lightsource-0' => 'Ünbekäänd',
'exif-lightsource-1' => 'Dailaacht',
'exif-lightsource-2' => 'Fluorescent',
'exif-lightsource-3' => 'Konstlaacht',
'exif-lightsource-4' => 'Laid',
'exif-lightsource-9' => 'Smok weder',
'exif-lightsource-10' => 'Betaanj',
'exif-lightsource-11' => 'Skaad',
'exif-lightsource-12' => 'Daylight fluorescent (D 5700 – 7100K)',
'exif-lightsource-13' => 'Day white fluorescent (N 4600 – 5400K)',
'exif-lightsource-14' => 'Cool white fluorescent (W 3900 – 4500K)',
'exif-lightsource-15' => 'White fluorescent (WW 3200 – 3700K)',
'exif-lightsource-17' => 'Standard light A',
'exif-lightsource-18' => 'Standard light B',
'exif-lightsource-19' => 'Standard light C',
'exif-lightsource-24' => 'ISO studio konstlaacht',
'exif-lightsource-255' => 'Ööder laacht',

# Flash modes
'exif-flash-fired-0' => 'Nään laid',
'exif-flash-fired-1' => 'Laid ütjliaset',
'exif-flash-return-0' => 'Laid schüürt nian dooten',
'exif-flash-return-2' => 'Nään laid tu sen',
'exif-flash-return-3' => 'Laid wiar tu sen',
'exif-flash-mode-1' => 'Mä twüngen laid',
'exif-flash-mode-2' => 'Laid ufsteld',
'exif-flash-mode-3' => 'Automaatik',
'exif-flash-function-1' => 'Nään laid mögelk',
'exif-flash-redeye-1' => 'Nian ruad uugen muude',

'exif-focalplaneresolutionunit-2' => 'tol',

'exif-sensingmethod-1' => 'Ei bekäänd',
'exif-sensingmethod-2' => 'One-chip color area sensor',
'exif-sensingmethod-3' => 'Two-chip color area sensor',
'exif-sensingmethod-4' => 'Three-chip color area sensor',
'exif-sensingmethod-5' => 'Color sequential area sensor',
'exif-sensingmethod-7' => 'Trilinear sensor',
'exif-sensingmethod-8' => 'Color sequential linear sensor',

'exif-filesource-3' => 'Digitaal stunbilknipser',

'exif-scenetype-1' => 'Normool',

'exif-customrendered-0' => 'Normool',
'exif-customrendered-1' => 'Brüker-iinsteld',

'exif-exposuremode-0' => 'Automaatisk belaachtang',
'exif-exposuremode-1' => 'Manuel belaachtang',
'exif-exposuremode-2' => 'Belaachtangsrä',

'exif-whitebalance-0' => 'Automaatisk',
'exif-whitebalance-1' => 'Manuel',

'exif-scenecapturetype-0' => 'Normool',
'exif-scenecapturetype-1' => 'Loonskap',
'exif-scenecapturetype-2' => 'Portree',
'exif-scenecapturetype-3' => 'Naacht',

'exif-gaincontrol-0' => 'Nian',
'exif-gaincontrol-1' => 'Letjet ap',
'exif-gaincontrol-2' => 'Föl ap',
'exif-gaincontrol-3' => 'Letjet deel',
'exif-gaincontrol-4' => 'Föl deel',

'exif-contrast-0' => 'Normool',
'exif-contrast-1' => 'Swaak',
'exif-contrast-2' => 'Stark',

'exif-saturation-0' => 'Normool',
'exif-saturation-1' => 'Letjet',
'exif-saturation-2' => 'Huuch',

'exif-sharpness-0' => 'Normool',
'exif-sharpness-1' => 'Swaak',
'exif-sharpness-2' => 'Stark',

'exif-subjectdistancerange-0' => 'Ünbekäänd',
'exif-subjectdistancerange-1' => 'Makro',
'exif-subjectdistancerange-2' => 'Nai bi',
'exif-subjectdistancerange-3' => 'Widj wech',

# Pseudotags used for GPSLatitudeRef and GPSDestLatitudeRef
'exif-gpslatitude-n' => 'Nuurdelk breetje',
'exif-gpslatitude-s' => 'Süüdelk breetje',

# Pseudotags used for GPSLongitudeRef and GPSDestLongitudeRef
'exif-gpslongitude-e' => 'Uastelk lengde',
'exif-gpslongitude-w' => 'Waastelk lengde',

# Pseudotags used for GPSAltitudeRef
'exif-gpsaltitude-above-sealevel' => '{{PLURAL:$1|Ään meeter|$1 meetern}} auer siapeegel',
'exif-gpsaltitude-below-sealevel' => '{{PLURAL:$1|Ään meeter|$1 meetern}} oner siapeegel',

'exif-gpsstatus-a' => 'Measurement in progress',
'exif-gpsstatus-v' => 'Measurement interoperability',

'exif-gpsmeasuremode-2' => '2-dimensional measurement',
'exif-gpsmeasuremode-3' => '3-dimensional measurement',

# Pseudotags used for GPSSpeedRef
'exif-gpsspeed-k' => 'km/h',
'exif-gpsspeed-m' => 'mph',
'exif-gpsspeed-n' => 'kn',

# Pseudotags used for GPSDestDistanceRef
'exif-gpsdestdistance-k' => 'Kilomeetern',
'exif-gpsdestdistance-m' => 'Miilen',
'exif-gpsdestdistance-n' => 'Siamiilen',

'exif-gpsdop-excellent' => 'Auer a miaten ($1)',
'exif-gpsdop-good' => 'Gud ($1)',
'exif-gpsdop-moderate' => 'Madel ($1)',
'exif-gpsdop-fair' => 'Gongt so ($1)',
'exif-gpsdop-poor' => 'Ei so dol ($1)',

'exif-objectcycle-a' => 'Bluas am maarlem',
'exif-objectcycle-p' => 'Bluas am injem',
'exif-objectcycle-b' => 'Eder am maarlam an am injem',

# Pseudotags used for GPSTrackRef, GPSImgDirectionRef and GPSDestBearingRef
'exif-gpsdirection-t' => 'Rochtwisin kurs',
'exif-gpsdirection-m' => 'Magneetisk kurs',

'exif-ycbcrpositioning-1' => 'Sentriaret',
'exif-ycbcrpositioning-2' => 'Uun naiberskap',

'exif-dc-contributor' => 'Bidracher faan',
'exif-dc-coverage' => 'Spatial or temporal scope of media',
'exif-dc-date' => 'Dootem',
'exif-dc-publisher' => 'Ütjden faan',
'exif-dc-relation' => 'Ferbünjen meedien',
'exif-dc-rights' => 'Rochten',
'exif-dc-source' => 'Meeedienkwel',
'exif-dc-type' => 'Meedienslach',

'exif-rating-rejected' => 'Turagwiset',

'exif-isospeedratings-overflow' => 'Grater üs 65535',

'exif-iimcategory-ace' => 'Konst, kultüür an onerhualang',
'exif-iimcategory-clj' => 'Rocht an ferbreegen',
'exif-iimcategory-dis' => 'Katastroofen an ünfaaler',
'exif-iimcategory-fin' => 'Wiartskap an bedriiwer',
'exif-iimcategory-edu' => 'Onerracht',
'exif-iimcategory-evn' => 'Natüür an amwelt',
'exif-iimcategory-hth' => 'Sünjhaid',
'exif-iimcategory-hum' => 'Persöönelk intresen',
'exif-iimcategory-lab' => 'Werk',
'exif-iimcategory-lif' => 'Freitidj an muude',
'exif-iimcategory-pol' => 'Politik',
'exif-iimcategory-rel' => 'Religioon an gluuw',
'exif-iimcategory-sci' => 'Wedenskap an technologii',
'exif-iimcategory-soi' => 'Mäenööder',
'exif-iimcategory-spo' => 'Sport',
'exif-iimcategory-war' => 'Kriich, stridj an ünrau',
'exif-iimcategory-wea' => 'Weder',

'exif-urgency-normal' => 'Normool ($1)',
'exif-urgency-low' => 'Liach ($1)',
'exif-urgency-high' => 'Huuch ($1)',
'exif-urgency-other' => 'Faan a brüker fäästlaanj prioriteet ($1)',

# External editor support
'edit-externally' => 'Detdiar datei mä en ekstern program bewerke',
'edit-externally-help' => "(Luk efter uun't [//www.mediawiki.org/wiki/Manual:External_editors hoonbuk] am muar diartu)",

# 'all' in various places, this might be different for inflected languages
'watchlistall2' => 'aaltumaal',
'namespacesall' => 'aaltumaal',
'monthsall' => 'aaltumaal',
'limitall' => 'åle',

# Email address confirmation
'confirmemail' => 'E-mail-adres gudkään',
'confirmemail_noemail' => 'Dü heest nian gud e-mail-adres uun din [[Special:Preferences|persöönelk iinstelangen]] iindraanj.',
'confirmemail_text' => '{{SITENAME}} ferlangt, dat dü din e-mail-adres gudkäänst, iar dü a ütjwidjet e-mail-funktjuunen brük könst. Trak üüb det fial „E-mail-code tusjüür“, am dat dü en e-mail tuschüürd feist, huar di code uun stäänt an en URL, am din adres gudtukäänen.',
'confirmemail_pending' => 'Dü heest al en e-mail mä di e-mail-code tuschüürd füngen. Teew noch en uugenblak, det komt wel noch. Bluas wan det goorei loket, ferlang efter en neien code.',
'confirmemail_send' => 'E-mail-code tuschüür',
'confirmemail_sent' => 'E-mail-code as wechschüürd wurden.',
'confirmemail_oncreate' => "En e-mail mä di e-mail-code as tu din e-mail-adres schüürd wurden. Hi as ei nuadag tu uunmeldin, oober hi woort brükt för ütjwidjet e-mail-funktjuunen uun't Wiki.",
'confirmemail_sendfailed' => '{{SITENAME}} küd det e-mail mä di e-mail-code ei wechschüür.
Luke noch ans, of dü det e-mail-adres rocht apskrewen heest.

Di mail-server swaaret: $1',
'confirmemail_invalid' => 'Di e-mail-code as ei gud. Ferlicht as hi tu ual.
Ferschük det man noch ans.',
'confirmemail_needlogin' => 'Dü skel di $1, am din e-mail-adres gudtukäänen.',
'confirmemail_success' => 'Din e-mail-adres as gudkäänd wurden.
Dü könst di nü [[Special:UserLogin|uunmelde]].',
'confirmemail_loggedin' => 'Din e-mail-adres as gudkäänd wurden.',
'confirmemail_error' => "Bi't gudkäänen faan din e-mail-adres as wat skiaf gingen.",
'confirmemail_subject' => '[{{SITENAME}}] E-mail-adres gudkään',
'confirmemail_body' => 'Gud dai,

hoker mä det IP-adres $1 (woorskiinelk dü salew) hää det brükerkonto „$2“ bi {{SITENAME}} iinracht.

Am a e-mail-funktjuunen faan {{SITENAME}} (weder) aktiif tu fun, an am seeker tu stelen, dat det brükerkonto uk würelk mä din e-mail-adres tuuphiart, gung tu detdiar ferwisang:

$3

Wan dü det brükerkonto *ei* iinracht hast, do gung tu detdiar ferwisang, am det gudkäänen uftubreegen:

$5

Didiar code täält bit $6, am a klook $7.',
'confirmemail_body_changed' => 'Hoker mä det IP-adres $1 (woorskiinelk dü salew) hää det e-mail-adres faan det brükerkonto „$2“ bi {{SITENAME}} feranert.

Am seeker tu stelen, dat det brükerkonto uk würelk di hiart, an am a e-mail-funktjuunen bi {{SITENAME}} weder uun a gang tu fun, gung tu detdiar ferwisang:

$3

Wan det *ei* din brükerkonto as, do gung tu detdiar ferwisang, am det gudkäänen uftubreegen:

$5

Didiar code täält bit $4.',
'confirmemail_body_set' => "Hoker mä det IP-adres $1 (woorskiinelk dü salew) hää det e-mail-adres faan't brükerkonto „$2“ üüb {{SITENAME}} tu detdiar e-mail-adres amanert.

Am seeker tu stelen, dat det brükerkonto würelk di hiart, an am a e-mail-funktjuunen üüb {{SITENAME}} weder uun a gang tu fun, gung tu detdiar ferwisang:

$3

Wan det *ei* din konto as, do gung tu detdiar ferwisang, am det gudkäänen uftubreegen:

$5

Didiar code täält bit $4.",
'confirmemail_invalidated' => "Det gudkäänen faan't e-mail-adres as ufbreegen wurden.",
'invalidateemail' => "Breeg gudkäänen faan't e-mail-adres uf",

# Scary transclusion
'scarytranscludedisabled' => '[Iinbinjen faan interwikis as ei aktiif]',
'scarytranscludefailed' => '[Iinbinjen faan föörlaagen för $1 as skiaf gingen]',
'scarytranscludefailed-httpstatus' => '[Ufrepen faan föörlaagen för $1 as skiaf gingen: HTTP  $2]',
'scarytranscludetoolong' => '[URL as tu lung]',

# Delete conflict
'deletedwhileediting' => "'''Paase üüb:''' Det sidj as stregen wurden, üs dü diar jüst bi werket heest!
Uun't [{{fullurl:{{#special:Log}}|type=delete&page={{FULLPAGENAMEE}}}} Strik-logbuk] fanjst dü di grünj för't striken. Wan dü det sidj seekerst, woort det nei uunlaanj.",
'confirmrecreate' => "Di brüker [[User:$1|$1]] ([[User talk:$1|Diskusjuun]]) hää det sidj stregen, üs dü diar jüst bi werket heest. Di grünj wiar:
:''$2''
Ferseekre, dat dü det sidj würelk nei maage wel.",
'confirmrecreate-noreason' => 'Di brüker [[User:$1|$1 ]] ([[User talk:$1|Diskusjuun]]) hää det sidj stregen, huar dü jüst bi werket heest. Ferseekre, dat dü det sidj würelk nei maage wel.',
'recreate' => 'Nei maage',

# action=purge
'confirm_purge_button' => 'OK',
'confirm-purge-top' => 'Det sidj ütj a cache strik?',
'confirm-purge-bottom' => 'Maaget di cache leesag an wiset det neist werjuun uun.',

# action=watch/unwatch
'confirm-watch-button' => 'OK',
'confirm-watch-top' => "Wel dü detdiar sidj uun't uug behual?",
'confirm-unwatch-button' => 'OK',
'confirm-unwatch-top' => "Wel dü detdiar sidj ei muar uun't uug behual?",

# Multipage image navigation
'imgmultipageprev' => '← leetst sidj (turag)',
'imgmultipagenext' => 'naist sidj →',
'imgmultigo' => 'Widjer',
'imgmultigoto' => 'Gung tu sidj $1',

# Table pager
'ascending_abbrev' => 'ap',
'descending_abbrev' => 'deel',
'table_pager_next' => 'Naist sidj',
'table_pager_prev' => 'Leetst sidj (turag)',
'table_pager_first' => 'Iarst sidj',
'table_pager_last' => 'Leetst sidj',
'table_pager_limit' => 'Wise $1 iindracher per sidj',
'table_pager_limit_label' => 'Iindracher per sidj:',
'table_pager_limit_submit' => 'Widjer',
'table_pager_empty' => 'Diar wiar niks',

# Auto-summaries
'autosumm-blank' => 'Det sidj as leesag maaget wurden.',
'autosumm-replace' => 'Di tekst as ütjbütjet wurden mä "$1"',
'autoredircomment' => 'Sidj tu [[$1]] widjerfeerd',
'autosumm-new' => 'Det sidj as nei uunlaanj wurden: "$1"',

# Live preview
'livepreview-loading' => 'Loose ...',
'livepreview-ready' => 'Loosin ... Klaar!',
'livepreview-failed' => 'Live-preview wul ei!
Ferschük det üüb di normool wai.',
'livepreview-error' => 'Küd ei ferbinj: $1 "$2".
Ferschük det üüb di normool wai.',

# Friendlier slave lag warnings
'lag-warn-normal' => 'Feranrangen faan {{PLURAL:$1|at leetst sekund|a leetst $1 sekunden}} kön noch ei uunwiset wurd.',
'lag-warn-high' => 'Auer det huuch dootenbeenklääst kön a feranrangen faan {{PLURAL:$1|at leetst sekund|a leetst $1 sekunden}} noch ei uunwiset wurd.',

# Watchlist editor
'watchlistedit-numitems' => "Dü heest {{PLURAL:$1|ian sidj|$1 sidjen}} uun't uug. A diskusjuunssidjen wurd ei mätääld.",
'watchlistedit-noitems' => "Dü heest nian sidjen, diar dü uun't uug behual wel.",
'watchlistedit-normal-title' => "List mä sidjen, diar dü uun't uug behual wel, bewerke",
'watchlistedit-normal-legend' => "Ei muar uun't uug behual",
'watchlistedit-normal-explain' => "Jodiar sidjen wel dü uun't uug behual. Am iindracher tu striken, kääntiakne a kaschin üüb sidj faan di iindrach an trak oner üüb „{{int:Watchlistedit-normal-submit}}“. Dü könst det list uk uun't [[Special:EditWatchlist/raw|listenformoot]] bewerke.",
'watchlistedit-normal-submit' => 'Iindracher wechnem',
'watchlistedit-normal-done' => '{{PLURAL:$1|Ään iindrach as|$1 iindracher san}} faan det list wechnimen wurden:',
'watchlistedit-raw-title' => "Uun't listenformoot bewerke",
'watchlistedit-raw-legend' => "Uun't listenformoot bewerke",
'watchlistedit-raw-explain' => "Jodiar sidjen, diar dü uun't uug behual wel, san uun't listenformoot apskrewen. A iindracher kön räwiis stregen of ütjwidjet wurd.
Uun arke rä mut ään iindrach stun. Wan dü klaar beest, trak oner üüb „{{int:Watchlistedit-raw-submit}}“.
Dü könst uk det [[Special:EditWatchlist|normool sidj]] tu bewerkin nem.",
'watchlistedit-raw-titles' => 'Iindracher:',
'watchlistedit-raw-submit' => "List mä sidjen, diar dü uun't uug behual wel, aktualisiare",
'watchlistedit-raw-done' => "Det list mä sidjen, diar dü uun't uug behual wel, as nü üüb di neist stant.",
'watchlistedit-raw-added' => '{{PLURAL:$1|Ään iindrach as|$1 iindracher san}} diartu skrewen wurden:',
'watchlistedit-raw-removed' => '{{PLURAL:$1|Ään iindrach as|$1 iindracher san}} wechnimen wurden:',

# Watchlist editing tools
'watchlisttools-view' => "Uun't uug behual: Feranrangen",
'watchlisttools-edit' => 'Normool bewerke',
'watchlisttools-raw' => "Uun't listenformoot bewerke",

# Signatures
'signature' => '[[{{ns:user}}:$1|$2]] ([[{{ns:user_talk}}:$1|Diskusjuun]])',

# Core parser functions
'unknown_extension_tag' => "Ünbekäänd ''tag'' „$1“",
'duplicate-defaultsort' => '\'\'\'Paase üüb:\'\'\' Di sortiarkai "$2" auerskraft di ual sortiarkai "$1"',

# Special:Version
'version' => 'Werjuun',
'version-extensions' => 'Instaliaret ütjwidjangen',
'version-specialpages' => 'Spezial-sidjen',
'version-parserhooks' => 'Ütjwidjet parserfunktjuunen',
'version-variables' => 'Wariaabeln',
'version-antispam' => "''Spam''seekerangen",
'version-skins' => 'Brükerskaker',
'version-other' => 'Ööders wat',
'version-mediahandlers' => 'Ütjwidjet medien-funktjuunen',
'version-hooks' => 'Hooks',
'version-parser-extensiontags' => 'Parser extension tags',
'version-parser-function-hooks' => 'Parser function hooks',
'version-hook-name' => 'Hook nööm',
'version-hook-subscribedby' => 'Aprepen faan',
'version-version' => '(Werjuun $1)',
'version-license' => 'Lisens',
'version-poweredby-credits' => "Detheer wääbsteed werket mä '''[//www.mediawiki.org/wiki/MediaWiki/de MediaWiki]''', Copyright © 2001–$1 $2.",
'version-poweredby-others' => 'öödern',
'version-poweredby-translators' => 'Auersaatern faan translatewiki.net',
'version-credits-summary' => 'Wi besoonke üs bi jodiar persuunen för hör bidracher tu [[Special:Version|MediaWiki]].',
'version-license-info' => 'MediaWiki is free software; you can redistribute it and/or modify it under the terms of the GNU General Public License as published by the Free Software Foundation; either version 2 of the License, or (at your option) any later version.

MediaWiki is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for more details.

You should have received [{{SERVER}}{{SCRIPTPATH}}/COPYING a copy of the GNU General Public License] along with this program; if not, write to the Free Software Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301, USA or [//www.gnu.org/licenses/old-licenses/gpl-2.0.html read it online].',
'version-software' => 'Instaliird software',
'version-software-product' => 'Produkt',
'version-software-version' => 'Werjuun',
'version-entrypoints' => 'URLs faan hüsdörsidjen',
'version-entrypoints-header-entrypoint' => 'Hüsdörsidj',
'version-entrypoints-header-url' => 'URL',

# Special:Redirect
'redirect' => 'Widjerfeerang üüb en brükersidj, sidjenwerjuun of datei.',
'redirect-legend' => 'Widjerfeerang üüb en sidjenwerjuun of datei.',
'redirect-summary' => 'Det spezial-sidj feert widjer üüb en brükersidj, sidjenwerjuun of datei.',
'redirect-submit' => 'Widjer',
'redirect-lookup' => 'Schük:',
'redirect-value' => 'Käänang of dateinööm:',
'redirect-user' => 'Brüker-ID',
'redirect-revision' => 'Sidjenwerjuun',
'redirect-file' => 'Dateinööm',
'redirect-not-exists' => 'Wäärs ei fünjen',

# Special:FileDuplicateSearch
'fileduplicatesearch' => 'Schük dobelt datein',
'fileduplicatesearch-summary' => 'Dobelt datein schük üüb grünjlaag faan hör hash-wäärs',
'fileduplicatesearch-legend' => 'Dobelt datein schük',
'fileduplicatesearch-filename' => 'Dateinööm:',
'fileduplicatesearch-submit' => 'Schük',
'fileduplicatesearch-info' => '$1 × $2 pixel<br />Dateigrate: $3<br />MIME-typ: $4',
'fileduplicatesearch-result-1' => 'Diar san nian dobelt datein faan „$1“.',
'fileduplicatesearch-result-n' => 'Det datei „$1“ hää {{PLURAL:$2|1 dobelt ütjfeerang|$2 dobelt ütjfeerangen}}.',
'fileduplicatesearch-noresults' => 'Nian datei mä di nööm „$1“ fünjen.',

# Special:SpecialPages
'specialpages' => 'Spezial-sidjen',
'specialpages-note' => '----
* Normool spezial-sidjen
* <span class="mw-specialpagerestricted">Spezial-sidjen mä tugripsrochten</span>
* <span class="mw-specialpagecached">Spezial-sidjen uun a cache (As ferlicht ei muar aktuel.)</span>',
'specialpages-group-maintenance' => 'Werksteedsidjen',
'specialpages-group-other' => 'Ööder spezial-sidjen',
'specialpages-group-login' => 'Melde di uun of skriiw di iin',
'specialpages-group-changes' => 'Leetst feranrangen an logbuken',
'specialpages-group-media' => 'Medien',
'specialpages-group-users' => 'Brükern an rochten',
'specialpages-group-highuse' => 'Flooksis brükt sidjen',
'specialpages-group-pages' => 'Sidjen',
'specialpages-group-pagetools' => 'Sidjenwerktjüch',
'specialpages-group-wiki' => 'Dooten an werktjüch',
'specialpages-group-redirects' => 'Spezial-sidjen, diar widjer feer',
'specialpages-group-spam' => "''Spam'' werktjüch",

# Special:BlankPage
'blankpage' => 'Leesag sidj',
'intentionallyblankpage' => 'Det sidj as mä walem leesag. Hat woort för benchmarks brükt.',

# External image whitelist
'external_image_whitelist' => " #Feranere detheer rä ei<pre>
#Dialen faan reguleer ütjdrüker (tesken a tiakens //) kön oner iinden wurd.
#Jo wurd do mä URLs faan ekstern bilen ferglikt.
#Huar't auerianstemet, woort det bil uunwiset, ööders bluas en ferwis üüb det bil.
#Räen mä en # bi a began san komentaaren.
#Grat- an letjskriiwang woort ei onerskääst.

#Skriiw dialen faan reguleer ütjdrüker auer detheer rä. Feranere detheer rä ei</pre>",

# Special:Tags
'tags' => 'Feranrangskääntiaken',
'tag-filter' => '[[Special:Tags|Kääntiaken]] filter:',
'tag-filter-submit' => 'Filter',
'tag-list-wrapper' => '([[Special:Tags|{{PLURAL:$1|Kääntiaken|Kääntiakens}}]]: $2)',
'tags-title' => 'Kääntiaken',
'tags-intro' => "Det sidj wiset kääntiaken, diar för't bewerkin brükt wurd, an wat jo men.",
'tags-tag' => 'Kääntiaken-nööm',
'tags-display-header' => 'Nööm üüb feranrangslisten',
'tags-description-header' => 'Widjloftag beskriiwang',
'tags-hitcount-header' => 'Kääntiakent feranrangen',
'tags-edit' => 'bewerke',
'tags-hitcount' => '$1 {{PLURAL:$1|feranrang|feranrangen}}',

# Special:ComparePages
'comparepages' => 'Sidjen ferglik',
'compare-selector' => 'Sidjenwerjuunen ferglik',
'compare-page1' => 'Sidj 1',
'compare-page2' => 'Sidj 2',
'compare-rev1' => 'Werjuun 1',
'compare-rev2' => 'Werjuun 2',
'compare-submit' => 'Ferglik',
'compare-invalid-title' => 'Didiar sidjennööm gongt ei.',
'compare-title-not-exists' => 'Son sidjennööm as diar ei.',
'compare-revision-not-exists' => 'Son werjuun as diar ei.',

# Database error messages
'dberr-header' => 'Det Wiki hää komer.',
'dberr-problems' => 'Dää mi iarag! Det sidj hää technisk komer.',
'dberr-again' => 'Teew en uugenblak an ferschük det noch ans.',
'dberr-info' => '(Koon ei mä a dootenbeenk-server ferbinj: $1)',
'dberr-info-hidden' => '(Ferbinjang mä a dootenbeenk-server as skiaf gingen)',
'dberr-usegoogle' => 'Uun a teskentidj küdst dü det mä Google ferschük.',
'dberr-outofdate' => 'Seenk diaram, dat Google ferlicht ual dooten uunwiset.',
'dberr-cachederror' => 'Detheer komt ütj en cache an as ferlicht ei muar aktuel.',

# HTML forms
'htmlform-invalid-input' => 'Diar as wat skiaf gingen mä din uunfraag.',
'htmlform-select-badoption' => 'Didiar wäärs as ei tuläät.',
'htmlform-int-invalid' => 'Didiar wäärs as nian hial taal.',
'htmlform-float-invalid' => 'Didiar wäärs as nian taal.',
'htmlform-int-toolow' => 'Didiar wäärs as letjer üs det minimum faan $1.',
'htmlform-int-toohigh' => 'Didiar wäärs as grater üs det maximum faan $1.',
'htmlform-required' => 'Di wäärs woort brükt.',
'htmlform-submit' => 'Auerdreeg',
'htmlform-reset' => 'Feranrangen turagsaat.',
'htmlform-selectorother-other' => 'Öödern',
'htmlform-no' => 'Naan',
'htmlform-yes' => 'Ja',
'htmlform-chosen-placeholder' => 'Schük ütj',

# SQLite database support
'sqlite-has-fts' => "Werjuun $1 mä halep för't schüken uun di hialer tekst.",
'sqlite-no-fts' => "Werjuun $1 saner halep för't schüken uun di hialer tekst.",

# New logging system
'logentry-delete-delete' => '$1 {{Gender:$2}} hää det sidj $3 stregen',
'logentry-delete-restore' => '$1 {{GENDER:$2}} hää det sidj $3 weder iinsteld',
'logentry-delete-event' => '$1 {{GENDER:$2}} hää det uunsicht feranert faan {{PLURAL:$5|en logbuk iindrach|$5 logbuk iindracher}} üüb $3: $4',
'logentry-delete-revision' => '$1 {{GENDER:$2}} hää det uunsicht feranert faan {{PLURAL:$5|ian werjuun|$5 werjuunen}} faan det sidj $3: $4',
'logentry-delete-event-legacy' => '$1 {{GENDER:$2}} hää det uunsicht feranert faan logbuk iindracher üüb $3',
'logentry-delete-revision-legacy' => '$1 {{GENDER:$2}} hää det uunsicht feranert faan werjuunen faan det sidj $3',
'logentry-suppress-delete' => '$1 {{GENDER:$2}} hää det sidj $3 wechtrakt',
'logentry-suppress-event' => '$1 {{GENDER:$2}} hää stalswigin det uunsicht feranert faan {{PLURAL:$5|en logbuk iindrach|$5 logbuk iindracher}} üüb $3: $4',
'logentry-suppress-revision' => '$1 {{GENDER:$2}} hää stalswigin det uunsicht feranert faan {{PLURAL:$5|ian werjuun|$5 werjuunen}} faan det sidj $3: $4',
'logentry-suppress-event-legacy' => '$1 {{GENDER:$2}} hää stalswigin det uunsicht feranert faan logbuk iindracher üüb $3',
'logentry-suppress-revision-legacy' => '$1 {{GENDER:$2}} hää stalswigin det uunlukin feranert faan werjuunen faan det sidj $3',
'revdelete-content-hid' => 'Ferbürgen',
'revdelete-summary-hid' => 'Ferbürgen tuupfaadang',
'revdelete-uname-hid' => 'brükernoome ferstäägen',
'revdelete-content-unhid' => 'Ei muar ferberag',
'revdelete-summary-unhid' => 'Tuupfaadang ei muar ferberag',
'revdelete-uname-unhid' => 'brükernoome frijääwen',
'revdelete-restricted' => 'mögelkhaiden för administratooren wechnimen',
'revdelete-unrestricted' => 'mögelkhaiden för administratooren ütjwidjet',
'logentry-move-move' => '$1 {{GENDER:$2}} hää det sidj $3 efter $4 fersköwen.',
'logentry-move-move-noredirect' => '$1 {{GENDER:$2}} hää det sidj $3 efter $4 saner widjerfeerang fersköwen.',
'logentry-move-move_redir' => '$1 {{GENDER:$2}} hää det sidj $3 efter $4 fersköwen an diarbi en widjerfeerang auerskrewen.',
'logentry-move-move_redir-noredirect' => '$1 {{GENDER:$2}} hää det sidj $3 efter $4 fersköwen an diarbi en widjerfeerang auerskrewen saner salew en widjerfeerang uuntuleien.',
'logentry-patrol-patrol' => '$1 {{GENDER:$2|hää}} det werjuun $4 faan sidj $3 üs kontroliaret kääntiakent.',
'logentry-patrol-patrol-auto' => '$1 {{GENDER:$2|hää}} det werjuun $4 faan sidj $3 automaatisk üs kontroliaret kääntiakent.',
'logentry-newusers-newusers' => 'Brükerkonto $1 as {{GENDER:$2|iinracht}} wurden',
'logentry-newusers-create' => 'Brükerkonto as faan $1 {{GENDER:$2|iinracht}} wurden.',
'logentry-newusers-create2' => 'Brükerkonto $3 as faan $1 {{GENDER:$2|iinracht}} wurden',
'logentry-newusers-byemail' => 'Brükerkonto $3 as faan $1 {{GENDER:$2|iinracht}} wurden, an det paaswurd as per e-mail tuschüürd wurden.',
'logentry-newusers-autocreate' => 'Brükerkonto $1 as automaatisk {{GENDER:$2|iinracht}} wurden',
'logentry-rights-rights' => '$1 {{GENDER:$2|hää}} det brükerskööl för $3 faan $4 tu $5 feranert.',
'logentry-rights-rights-legacy' => '$1 {{GENDER:$2|hää}} det brükerskööl för $3 feranert.',
'logentry-rights-autopromote' => '$1 as automaatisk faan $4 tu $5 {{GENDER:$2|tuwiset}} wurden.',
'rightsnone' => '(-)',

# Feedback
'feedback-bugornote' => 'Wan dü en technisk probleem beskriiw wel, wees so gud an skriiw [$1 am di feeler].
Ööders könst dü uk det formulaar oner brük. Dan komentaar woort tuup mä dan brükernööm an det werjuun faan dan browser üüb det sidj „[$3 $2]“ skrewen.',
'feedback-subject' => 'Teemo:',
'feedback-message' => 'Mädialang:',
'feedback-cancel' => 'Ufbreeg',
'feedback-submit' => 'Komentaar ufsjüür',
'feedback-adding' => 'Komentaar woort tu det sidj skrewen ...',
'feedback-error1' => 'Feeler: Ünbekäänd API-bööd',
'feedback-error2' => 'Feeler: Bewerkin as skiaf gingen.',
'feedback-error3' => 'Feeler: Nian API-oonswaar',
'feedback-thanks' => 'Föl soonk. Dan komentaar as üüb det sidj „[$2 $1]“ skrewen wurden.',
'feedback-close' => 'Klaar',
'feedback-bugcheck' => 'Gud! Luke noch ans efter, of det ei ferlicht en [$1 bekäänden feeler] as.',
'feedback-bugnew' => 'Haa ik efterluket. Nei feeler melde.',

# Search suggestions
'searchsuggest-search' => 'Schük',
'searchsuggest-containing' => 'diar banen as ...',

# API errors
'api-error-badaccess-groups' => 'Dü mutst nian datein tu detdiar Wiki huuchschüür.',
'api-error-badtoken' => 'Intern feeler: Token as ferkiard.',
'api-error-copyuploaddisabled' => 'Det huuchschüüren auer URL as üüb didiar server ei aktiif.',
'api-error-duplicate' => 'Uun det Wiki {{PLURAL:$1|as al [$2 en ööder datei]|san al [$2 muar datein]}} mä detsalew banen.',
'api-error-duplicate-archive' => 'Diar wiar al {{PLURAL:$1|[$2 ööder datei]|[$2 ööder datein]}} mä detsalew banen. {{PLURAL:$1|Hat as |Jo san}} oober stregen wurden.',
'api-error-duplicate-archive-popup-title' => 'Dobelt {{PLURAL:$1|datei, diar al stregen wurden as|datein, diar al stregen wurden san}}.',
'api-error-duplicate-popup-title' => 'Dobelt {{PLURAL:$1|datei|datein}}',
'api-error-empty-file' => 'Det datei, wat dü huuchsjüürd heest, as leesag.',
'api-error-emptypage' => 'Dü mutst nian leesag sidjen nei iinstel.',
'api-error-fetchfileerror' => "Intern feeler: Bi't ufrepen faan det datei as wat skiaf gingen.",
'api-error-fileexists-forbidden' => 'En datei mä di nööm „$1“ as al diar. Hat koon ei auerskrewen wurd.',
'api-error-fileexists-shared-forbidden' => "En date mä di nööm „$1“ as al uun't gemiansoom archiif an koon ei auerskrewen wurd.",
'api-error-file-too-large' => 'Det datei, wat dü huuchsjüürd heest, as tu grat.',
'api-error-filename-tooshort' => 'Di dateinööm as tu kurt.',
'api-error-filetype-banned' => 'Son slach faan datei as ei tuläät.',
'api-error-filetype-banned-type' => '$1 {{PLURAL:$4|as nään tuläät slach faan datein|san nian tuläät slacher faan datein}}.
{{PLURAL:$3|En tuläät slach as|Tuläät slacher san}} $2.',
'api-error-filetype-missing' => 'Det datei, wat dü huuchschüür wel, hää nian dateiaanj.',
'api-error-hookaborted' => 'Det feranrang, wat dü maage wulst, as faan en ütjwidjet software-funktjuun ufbreegen wurden.',
'api-error-http' => 'Intern feeler: Ferbinjang tu a server as skiaf gingen.',
'api-error-illegal-filename' => 'Didiar dateinööm as ei tuläät.',
'api-error-internal-error' => "Intern feeler: diar as wat skiaf gingen bi't huuchschüüren faan det datei tu det Wiki.",
'api-error-invalid-file-key' => 'Intern feeler: Det datei as uun det tidjwiis archiif ei fünjen wurden.',
'api-error-missingparam' => 'Intern feeler: Det uunfraag as ei hial uunkimen.',
'api-error-missingresult' => 'Intern feeler: Küd ei luke, of det kopiarin loket hää.',
'api-error-mustbeloggedin' => 'Dü skel di uunmelde, am datein huuchtuschüüren.',
'api-error-mustbeposted' => 'Intern feeler: Ferkiard HTTP-muude.',
'api-error-noimageinfo' => 'Det huuchschüüren hää loket, oober di server hää nian datei-dooten.',
'api-error-nomodule' => 'Intern feeler: Diar as nian modul tu huuchschüüren fäästlaanj wurden.',
'api-error-ok-but-empty' => 'Intern feeler: Di server sait niks.',
'api-error-overwrite' => 'Dü könst nian datei auerskriiw, wat al diar as.',
'api-error-stashfailed' => 'Intern feeler: Di server küd nian tidjwiis datei seekre.',
'api-error-publishfailed' => 'Intern feeler: Di server küd det tidjwiis datei ei widjer schüür.',
'api-error-timeout' => 'Di server hää ei rochttidjag swaaret (time-out).',
'api-error-unclassified' => 'Diar as irgentwat skiaf gingen.',
'api-error-unknown-code' => 'Ünbekäänd feeler: „$1“',
'api-error-unknown-error' => "Intern feeler: Bi't huuchschüüren faan det datei as wat skiaf gingen.",
'api-error-unknown-warning' => 'Ünbekäänd wäärnang: $1',
'api-error-unknownerror' => 'Ünbekäänd feeler: „$1“',
'api-error-uploaddisabled' => 'Uun detdiar Wiki könst dü niks huuchschüür.',
'api-error-verification-error' => 'Det datei, wat dü huuchschüür wel, as uunstaken of hää en ferkiard dateiaanj.',

# Durations
'duration-seconds' => '$1 {{PLURAL:$1|sekund|sekunden}}',
'duration-minutes' => '$1 {{PLURAL:$1|minüüt|minüüten}}',
'duration-hours' => '$1 {{PLURAL:$1|stünj|stünjen}}',
'duration-days' => '$1 {{PLURAL:$1|dai|daar}}',
'duration-weeks' => '$1 {{PLURAL:$1|weg|wegen}}',
'duration-years' => '$1 {{PLURAL:$1|juar|juaren}}',
'duration-decades' => '$1 {{PLURAL:$1|juartjiint|juartjiinten}}',
'duration-centuries' => '$1 {{PLURAL:$1|juarhunert|juarhunerten}}',
'duration-millennia' => '$1 {{PLURAL:$1|juardüüsen|juardüüsenen}}',

# Image rotation
'rotate-comment' => 'Bil am $1 {{PLURAL:$1|graad}} mä a klook dreid.',

# Limit report
'limitreport-title' => 'Parser-profiling dooten:',
'limitreport-cputime' => 'CPU-tidj',
'limitreport-cputime-value' => '$1 {{PLURAL:$1|sekund|sekunden}}',
'limitreport-walltime' => 'Würelk tidj',
'limitreport-walltime-value' => '$1 {{PLURAL:$1|sekund|sekunden}}',
'limitreport-ppvisitednodes' => 'Taal faan ferbinjangsknooter för di föörproseser',
'limitreport-ppgeneratednodes' => 'Faan di föörproseser bereegent ferbinjangsknooter',
'limitreport-postexpandincludesize' => "Grate faan iinbinjangen efter't ütjwidjin",
'limitreport-postexpandincludesize-value' => '$1/$2 bytes',
'limitreport-templateargumentsize' => "Grate faan't föörlaagenargument",
'limitreport-templateargumentsize-value' => '$1/$2 bytes',
'limitreport-expansiondepth' => 'Maksimaal ütjwidjangsjipde',
'limitreport-expensivefunctioncount' => 'Taal faan apwendag parser-funktjuunen',

);
